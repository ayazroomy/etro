const fs = require('fs');
const path = require('path');
const { suite, test, assertTrue, assertFalse, assertEqual } = require('./testHarness');
const { writeConfig } = require('../electron/configBuilder');

function buildAndLoad(settings, label) {
  const configPath = path.resolve(__dirname, `.tmp-configBuilder-${label}.js`);
  writeConfig({ settings, reportDir: '/tmp/electron-tests-reportdir', configPath });
  delete require.cache[configPath];
  const cfg = require(configPath);
  fs.unlinkSync(configPath);
  return cfg;
}

const baseViewport = { width: 1280, height: 720 };
const baseSettings = {
  browsers: ['chromium', 'firefox', 'webkit'],
  viewport: baseViewport,
  screenshot: 'off',
  stepScreenshots: 'off',
  video: 'off',
  trace: 'off',
  timeoutMs: 30000,
  retries: 0,
  workers: 1,
};

suite('configBuilder: REGRESSION GUARD — browser-specific window-size args, headed mode', () => {
  const cfg = buildAndLoad({ ...baseSettings, headless: false }, 'headed-all-browsers');
  const byName = Object.fromEntries(cfg.projects.map((p) => [p.name, p.use]));

  test('chromium gets Chromium-syntax --window-size', () => {
    assertTrue(Array.isArray(byName.chromium.launchOptions?.args), 'expected chromium launchOptions.args');
    assertTrue(
      byName.chromium.launchOptions.args.includes('--window-size=1280,720'),
      'expected --window-size=1280,720 in chromium args'
    );
  });

  test('firefox gets NO custom launch args at all (two separate attempts at sizing its window via CLI flags both proved broken — see the doc comment on windowSizeArgsFor in configBuilder.js)', () => {
    // Attempt 1: Chromium's own --window-size=W,H syntax, applied globally —
    // Firefox's parser didn't recognize it and opened a bogus window at
    // "http://1280,720/". Attempt 2: Mozilla's own documented -width/-height
    // flags, applied Firefox-specifically — STILL produced a bogus window,
    // this time at "https://0.0.5.0/" with a real 1280x720 headed Firefox
    // run. With no real Firefox binary available to verify CLI behavior
    // against directly, guessing a third time isn't worth the risk — Firefox
    // gets no custom sizing args at all now, same treatment as WebKit.
    assertTrue(byName.firefox.launchOptions === undefined, 'firefox should have no launchOptions — no custom args of any kind');
  });

  test('webkit gets no custom sizing args at all (no real WebKit binary to verify safe flags against)', () => {
    assertTrue(byName.webkit.launchOptions === undefined, 'webkit should have no launchOptions in this scenario');
  });
});

suite('configBuilder: headless mode never sets launchOptions on any browser', () => {
  const cfg = buildAndLoad({ ...baseSettings, headless: true }, 'headless-all-browsers');
  test('no project has launchOptions when headless', () => {
    for (const p of cfg.projects) {
      assertTrue(p.use.launchOptions === undefined, `${p.name} should have no launchOptions in headless mode`);
    }
  });
});

suite('configBuilder: device emulation still resolves the correct viewport for window sizing', () => {
  const cfg = buildAndLoad(
    { ...baseSettings, browsers: ['chromium'], headless: false, device: 'Galaxy S9+' },
    'chromium-device'
  );
  test('chromium window-size arg matches the device viewport, not the manual settings.viewport', () => {
    // Firefox no longer gets custom sizing args at all (see the suite above),
    // so this is verified against chromium — the only browser where a
    // device's viewport still visibly affects the generated launch args.
    const args = cfg.projects[0].use.launchOptions.args;
    assertTrue(args.includes('--window-size=320,658'), 'expected Galaxy S9+ viewport (320x658), not the manual 1280x720 setting');
  });
});

suite('configBuilder: PWD_BROWSER_EXECUTABLE_PATH override still works alongside per-browser args', () => {
  test('executablePath is present together with the browser-specific args', () => {
    process.env.PWD_BROWSER_EXECUTABLE_PATH = '/fake/path/to/chrome';
    const cfg = buildAndLoad({ ...baseSettings, browsers: ['chromium'], headless: false }, 'executable-override');
    delete process.env.PWD_BROWSER_EXECUTABLE_PATH;

    const launchOptions = cfg.projects[0].use.launchOptions;
    assertEqual(launchOptions.executablePath, '/fake/path/to/chrome');
    assertTrue(launchOptions.args.includes('--window-size=1280,720'), 'args should still be present alongside executablePath');
  });
});
