const fs = require('fs');
const path = require('path');
const { devices } = require('@playwright/test');

const RUNNER_DIR = path.join(__dirname, '..', 'runner');

/**
 * Resolves the viewport that will actually be in effect: a selected device's
 * own viewport takes priority (matching how the device-merge below applies
 * it per-project), falling back to the manually configured one.
 */
function effectiveViewport(settings) {
  if (settings.device && devices[settings.device] && devices[settings.device].viewport) {
    return devices[settings.device].viewport;
  }
  return settings.viewport || { width: 1280, height: 720 };
}

/**
 * Headed-mode-only OS window sizing, matching the emulated viewport so a
 * mobile-device-emulated (or otherwise non-default) viewport doesn't sit
 * inside a mostly-blank, much larger window (see effectiveViewport above).
 *
 * Chromium only. Two separate attempts at sizing Firefox's window via CLI
 * flags both caused it to open a bogus second window navigated to a garbled
 * URL instead — first `--window-size=W,H` (Chromium's own syntax, produced
 * "http://1280,720/"), then Mozilla's own documented `-width`/`-height`
 * flags (produced "https://0.0.5.0/" with a real-world 1280×720 Firefox
 * headed run). Since there's no real Firefox binary available to verify
 * against directly — only documentation, which has now proven an unreliable
 * guide to Playwright's specific (patched, Juggler-protocol) Firefox build's
 * actual CLI argument handling — this stops guessing rather than risk a
 * third broken attempt. Firefox (and WebKit, for the same underlying
 * reason: no real binary to verify against) get NO custom sizing args at
 * all. The cost is purely cosmetic (extra blank space around a
 * non-default-sized viewport in headed mode); the alternative was an
 * actively disruptive bogus window appearing during every headed Firefox run.
 */
function windowSizeArgsFor(browserName, viewport) {
  if (browserName === 'chromium') {
    return [`--window-size=${viewport.width},${viewport.height}`];
  }
  // Firefox and WebKit: intentionally no custom sizing args — see the doc
  // comment above for why.
  return null;
}

/**
 * Turns app settings into a plain Playwright config object.
 * Nothing here is per-test-case — it is purely global run configuration,
 * exactly matching what the Settings modal exposes.
 */
function buildConfigObject(settings, opts) {
  const viewport = effectiveViewport(settings);
  const headed = settings.headless === false;
  // Optional, opt-in-only override for the browser binary Playwright
  // launches — useful in CI environments or with a custom Chromium build
  // where the standard `playwright install` browsers aren't what should run.
  // No effect at all unless this env var is explicitly set.
  const executablePathOverride = process.env.PWD_BROWSER_EXECUTABLE_PATH || undefined;

  const useBlock = {
    headless: settings.headless !== false,
    screenshot: settings.screenshot || 'only-on-failure',
    video: settings.video || 'retain-on-failure',
    trace: settings.trace || 'retain-on-failure',
    viewport: settings.viewport || { width: 1280, height: 720 },
  };

  const browsers = settings.browsers && settings.browsers.length ? settings.browsers : ['chromium'];

  return {
    testDir: RUNNER_DIR,
    testMatch: 'generic-runner.spec.js',
    timeout: settings.timeoutMs || 30000,
    retries: settings.retries || 0,
    workers: settings.workers || 1,
    reportSlowTests: null,
    reporter: [
      ['list'],
      ['json', { outputFile: path.join(opts.reportDir, 'results.json') }],
      ['html', { outputFolder: path.join(opts.reportDir, 'html'), open: 'never' }],
      [path.join(RUNNER_DIR, 'electron-reporter.js')],
    ],
    use: useBlock,
    projects: browsers.map((browserName) => {
      const projectUse = { browserName };
      const args = headed ? windowSizeArgsFor(browserName, viewport) : null;
      // Built explicitly per-project (rather than relying on the global
      // `use.launchOptions` merging down) so a Chromium-specific arg never
      // ends up applied to a Firefox/WebKit project just because it happened
      // to be set at the top level.
      if (args || executablePathOverride) {
        projectUse.launchOptions = {
          ...(args ? { args } : {}),
          ...(executablePathOverride ? { executablePath: executablePathOverride } : {}),
        };
      }
      return { name: browserName, use: projectUse };
    }),
  };
}

/**
 * Writes a real playwright.config.js to disk and returns its path.
 * We serialize with JSON + a small header instead of hand-building JS strings
 * for the bulk of the config, only special-casing `devices` when a device is set.
 */
function writeConfig({ settings, reportDir, configPath }) {
  const cfg = buildConfigObject(settings, { reportDir });

  const useDevice = !!settings.device;
  // Resolved here (inside the running app, where node_modules is guaranteed
  // reachable) rather than left as a bare `require('@playwright/test')` in
  // the generated file — that bare form only resolves if the config happens
  // to sit inside/under the project's own node_modules tree. Embedding the
  // absolute path lets the generated config live anywhere, including a
  // writable per-user temp folder outside the (read-only, once packaged) app directory.
  const playwrightTestPath = require.resolve('@playwright/test');

  const fileContents = `// AUTO-GENERATED by the app's Settings modal. Do not edit by hand — it is
// regenerated before every run from data/settings.json.
const { defineConfig, devices } = require(${JSON.stringify(playwrightTestPath)});

const config = ${JSON.stringify(cfg, null, 2)};

${
  useDevice
    ? `// Apply the selected device profile on top of each browser project
config.projects = config.projects.map((p) => ({
  ...p,
  use: { ...devices[${JSON.stringify(settings.device)}], ...p.use },
}));`
    : ''
}

module.exports = defineConfig(config);
`;

  fs.mkdirSync(path.dirname(configPath), { recursive: true });
  fs.writeFileSync(configPath, fileContents);
  return configPath;
}

module.exports = { writeConfig, RUNNER_DIR };
