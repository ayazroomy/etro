const { chromium, firefox, webkit } = require('@playwright/test');

const BROWSER_LAUNCHERS = { chromium, firefox, webkit };

let currentSession = null; // { browser, context, page, steps, onClosed }

/**
 * Runs INSIDE the recorded page (via context.addInitScript). It has no access
 * to the Node/Electron world directly — it only talks back out through the
 * `window.__pwd_record` function that Playwright's `exposeFunction` installs
 * on every frame in the context before this init script runs.
 *
 * Locator preference mirrors runner/locatorResolver.js so recorded steps are
 * already compatible with the app's own DSL without any translation step.
 */
function injectedRecorderScript() {
  function cssPath(el) {
    if (el.id) return '#' + CSS.escape(el.id);
    const parts = [];
    let node = el;
    while (node && node.nodeType === 1 && parts.length < 6) {
      let selector = node.tagName.toLowerCase();
      if (node.classList && node.classList.length) {
        selector += '.' + Array.from(node.classList).slice(0, 2).map((c) => CSS.escape(c)).join('.');
      }
      const parent = node.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter((s) => s.tagName === node.tagName);
        if (siblings.length > 1) {
          selector += `:nth-of-type(${siblings.indexOf(node) + 1})`;
        }
      }
      parts.unshift(selector);
      node = parent;
    }
    return parts.join(' > ');
  }

  function getLocator(el) {
    if (!el || el.nodeType !== 1) return null;
    if (el.dataset && el.dataset.testid) {
      return { type: 'testid', value: el.dataset.testid };
    }
    if (el.id) {
      return { type: 'css', value: '#' + CSS.escape(el.id) };
    }
    const ariaLabel = el.getAttribute('aria-label');
    if (ariaLabel) {
      return { type: 'label', value: ariaLabel };
    }
    const role = el.getAttribute('role');
    const tag = el.tagName;
    if (tag === 'BUTTON' || role === 'button') {
      const text = (el.innerText || '').trim().slice(0, 60);
      if (text) return { type: 'role', role: 'button', name: text };
    }
    if (tag === 'A') {
      const text = (el.innerText || '').trim().slice(0, 60);
      if (text) return { type: 'role', role: 'link', name: text };
    }
    if (el.placeholder) {
      return { type: 'placeholder', value: el.placeholder };
    }
    return { type: 'css', value: cssPath(el) };
  }

  document.addEventListener(
    'click',
    (e) => {
      const el = e.target && e.target.closest ? e.target.closest('button, a, [role], input, select, label, *') : e.target;
      const locator = getLocator(el);
      if (!locator || !window.__pwd_record) return;
      // Clicks on inputs/selects are usually just focusing before typing/choosing —
      // let the 'change' handler below record the meaningful action instead.
      const tag = el.tagName;
      if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
      window.__pwd_record({ action: 'click', locator });
    },
    true
  );

  // ---- Text entry (fill) ----
  // Deliberately NOT relying on 'change' alone (fires only on blur/commit
  // within the SAME page) — when the user finishes typing and then switches
  // to a totally different OS window (this app's own "Stop & Review" button)
  // rather than clicking elsewhere on the page, that cross-window focus
  // switch doesn't reliably fire 'change' before the browser gets closed,
  // silently dropping the typed text. Instead: debounce on 'input' (fires on
  // every keystroke) and flush the pending value after a short pause in
  // typing, PLUS flush immediately on blur, PLUS expose a flush function
  // externally so stopRecording() can force one last flush right before
  // closing the browser, covering the "typed and immediately clicked Stop"
  // case with no pause at all.
  let pendingInputEl = null;
  let pendingInputTimer = null;

  function flushPendingInput() {
    if (pendingInputTimer) {
      clearTimeout(pendingInputTimer);
      pendingInputTimer = null;
    }
    if (!pendingInputEl || !window.__pwd_record) {
      pendingInputEl = null;
      return;
    }
    const el = pendingInputEl;
    pendingInputEl = null;
    const locator = getLocator(el);
    if (!locator) return;
    window.__pwd_record({ action: 'fill', locator, value: el.value });
  }
  // Exposed so recorder.js can force a flush (via page.evaluate) right
  // before closing the browser, catching text with no pause before Stop.
  window.__pwd_flushPendingInput = flushPendingInput;

  document.addEventListener(
    'input',
    (e) => {
      const el = e.target;
      if (!el) return;
      const tag = el.tagName;
      const type = (el.type || '').toLowerCase();
      if (tag !== 'INPUT' && tag !== 'TEXTAREA') return;
      if (type === 'checkbox' || type === 'radio') return; // handled by 'change' below

      if (pendingInputEl && pendingInputEl !== el) {
        flushPendingInput(); // switched fields — commit the previous one now
      }
      pendingInputEl = el;
      if (pendingInputTimer) clearTimeout(pendingInputTimer);
      pendingInputTimer = setTimeout(flushPendingInput, 600);
    },
    true
  );

  document.addEventListener(
    'blur',
    (e) => {
      if (e.target === pendingInputEl) flushPendingInput();
    },
    true
  );

  window.addEventListener('beforeunload', () => flushPendingInput());

  document.addEventListener(
    'change',
    (e) => {
      const el = e.target;
      if (!el || !window.__pwd_record) return;
      const tag = el.tagName;
      const type = (el.type || '').toLowerCase();
      const locator = getLocator(el);
      if (!locator) return;
      if (tag === 'SELECT') {
        window.__pwd_record({ action: 'selectOption', locator, value: el.value });
      } else if (type === 'checkbox' || type === 'radio') {
        window.__pwd_record({ action: el.checked ? 'check' : 'uncheck', locator });
      }
      // Plain text INPUT/TEXTAREA is handled by the debounced 'input'
      // listener above instead, not here — avoids double-recording and
      // works reliably even when blur never fires within the page.
    },
    true
  );

  // ---- Keyboard-driven actions (Tab navigation, Enter/Escape, arrow-key
  // menu navigation, keyboard shortcuts) — recorded as page-level `pressKey`
  // steps with NO locator, since replaying the same key sequence naturally
  // reproduces whatever focus movement happened during recording, exactly
  // like a real user tabbing through the page.
  const NAV_KEYS = new Set([
    'Tab', 'Enter', 'Escape',
    'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight',
    'Home', 'End', 'PageUp', 'PageDown', ' ',
  ]);
  const MODIFIER_KEYS = new Set(['Control', 'Meta', 'Alt', 'Shift']);

  function normalizeKeyName(key) {
    if (key === ' ') return 'Space';
    if (key.length === 1) return key.toUpperCase();
    return key; // Tab, Enter, Escape, ArrowUp, etc. already match Playwright's key names
  }

  function buildKeyCombo(e) {
    const parts = [];
    if (e.ctrlKey) parts.push('Control');
    if (e.metaKey) parts.push('Meta');
    if (e.altKey) parts.push('Alt');
    if (e.shiftKey) parts.push('Shift');
    const mainKey = normalizeKeyName(e.key);
    if (!MODIFIER_KEYS.has(mainKey)) parts.push(mainKey);
    return parts.join('+');
  }

  document.addEventListener(
    'keydown',
    (e) => {
      if (!window.__pwd_record) return;
      if (MODIFIER_KEYS.has(e.key)) return; // a lone modifier keydown isn't an action by itself

      const hasModifier = e.ctrlKey || e.metaKey || e.altKey || e.shiftKey;
      const isNavKey = NAV_KEYS.has(e.key);
      if (!hasModifier && !isNavKey) return; // plain character typing — already captured via 'change' on commit

      const el = e.target;
      const tag = el && el.tagName;
      const editableTypes = ['checkbox', 'radio', 'button', 'submit', 'reset', 'range', 'file', 'color'];
      const isTextEditable =
        el &&
        (tag === 'TEXTAREA' ||
          el.isContentEditable ||
          (tag === 'INPUT' && !editableTypes.includes((el.type || 'text').toLowerCase())));

      // Inside a plain text field, unmodified arrow keys / Home / End / PageUp/Down / Space
      // just move the caret or insert a literal space — not meaningful for replay. Tab,
      // Enter, and Escape are always meaningful (leave the field / submit / cancel) even
      // inside a text field, so they're excluded from this skip.
      const isPureCaretMovement = !hasModifier && isTextEditable && !['Tab', 'Enter', 'Escape'].includes(e.key);
      if (isPureCaretMovement) return;

      window.__pwd_record({ action: 'pressKey', value: buildKeyCombo(e) });
    },
    true
  );
}

async function startRecording({ browserName, baseUrl, onStep, onClosed }) {
  if (currentSession) {
    throw new Error('A recording session is already in progress');
  }

  const launcher = BROWSER_LAUNCHERS[browserName] || chromium;
  const browser = await launcher.launch({ headless: false });
  const context = await browser.newContext({ viewport: null });
  const page = await context.newPage();

  const steps = [];
  const record = (event) => {
    steps.push(event);
    if (onStep) onStep(event);
  };

  await context.exposeFunction('__pwd_record', record);
  await context.addInitScript(injectedRecorderScript);

  page.on('framenavigated', (frame) => {
    if (frame !== page.mainFrame()) return;
    const url = frame.url();
    if (!url || url === 'about:blank') return;
    const last = steps[steps.length - 1];
    if (last && last.action === 'goto' && last.value === url) return;
    record({ action: 'goto', value: url });
  });

  browser.on('disconnected', () => {
    if (currentSession) {
      currentSession = null;
      if (onClosed) onClosed();
    }
  });

  currentSession = { browser, context, page, steps };

  if (baseUrl) {
    await page.goto(baseUrl);
  }

  return { steps };
}

async function stopRecording() {
  if (!currentSession) return { steps: [] };
  const { browser, page, steps } = currentSession;
  currentSession = null;
  try {
    if (page && !page.isClosed()) {
      await page
        .evaluate(() => {
          if (window.__pwd_flushPendingInput) window.__pwd_flushPendingInput();
        })
        .catch(() => {});
    }
  } catch (err) {
    // page may already be gone if the user closed the window manually
  }
  try {
    await browser.close();
  } catch (err) {
    // browser may already be closed if the user closed the window manually
  }
  return { steps };
}

function isRecording() {
  return !!currentSession;
}

module.exports = { startRecording, stopRecording, isRecording };
