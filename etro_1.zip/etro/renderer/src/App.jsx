import React, { useEffect, useState, useCallback, useRef } from 'react';
import Toolbar from './components/Toolbar.jsx';
import CollectionTree from './components/CollectionTree.jsx';
import SpecEditor from './components/SpecEditor.jsx';
import SettingsModal from './components/SettingsModal.jsx';
import LogPanel from './components/LogPanel.jsx';
import PromptModal from './components/PromptModal.jsx';
import RecorderModal from './components/RecorderModal.jsx';
import JsonEditorModal from './components/JsonEditorModal.jsx';
import AboutModal from './components/AboutModal.jsx';
import ConfirmModal from './components/ConfirmModal.jsx';
import PanelDivider from './components/PanelDivider.jsx';
import { emptySpec } from './actionMeta.js';
import { copyrightLine } from './appInfo.js';
import appIcon from './assets/icon.png';

export default function App() {
  const [collections, setCollections] = useState([]);
  const [specsByCollection, setSpecsByCollection] = useState({});
  const [activeSpec, setActiveSpec] = useState(null);
  const [dirty, setDirty] = useState(false);
  const [selectedIds, setSelectedIds] = useState({}); // id -> spec (for run selection)
  const [settings, setSettings] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [showSettings, setShowSettings] = useState(false);
  const [showNewCollection, setShowNewCollection] = useState(false);
  const [showRecorder, setShowRecorder] = useState(false);
  const [showJsonEditor, setShowJsonEditor] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  const [confirmState, setConfirmState] = useState(null); // { title, message, showCancel, resolve }
  const [logEntries, setLogEntries] = useState([]);
  const [running, setRunning] = useState(false);
  const [lastHtmlReportPath, setLastHtmlReportPath] = useState(null);
  const [leftWidth, setLeftWidth] = useState(260);
  const [centerWidth, setCenterWidth] = useState(560);

  const [platform, setPlatform] = useState('');

  function clamp(v, min, max) {
    return Math.min(max, Math.max(min, v));
  }

  const refreshAll = useCallback(async () => {
    const cols = await window.api.listCollections();
    setCollections(cols);
    const byCol = {};
    for (const c of cols) {
      byCol[c.id] = await window.api.listSpecs(c.id);
    }
    setSpecsByCollection(byCol);
  }, []);

  useEffect(() => {
    window.api.getPlatform().then(setPlatform);
  }, []);

  useEffect(() => {
    const theme = settings?.theme || 'default';
    document.documentElement.setAttribute('data-theme', theme);
    window.api.setTitleBarTheme(theme);
  }, [settings?.theme]);

  // Defense-in-depth for the native-dialog focus bug: reclaim OS-level
  // keyboard focus the instant a Settings/Recorder/JSON-editor/About modal
  // closes. NOT applied to confirmState (the new ConfirmModal) — a pure
  // React modal was directly verified (by comparing against PromptModal,
  // which never showed the issue when opened/closed repeatedly) not to need
  // this treatment at all; adding it anyway would be needless complexity.
  const anyModalWasOpen = useRef(false);
  useEffect(() => {
    const anyModalOpen = showSettings || showNewCollection || showRecorder || showJsonEditor || showAbout;
    if (anyModalWasOpen.current && !anyModalOpen) {
      window.api.reclaimFocus();
    }
    anyModalWasOpen.current = anyModalOpen;
  }, [showSettings, showNewCollection, showRecorder, showJsonEditor, showAbout]);

  useEffect(() => {
    refreshAll();
    window.api.getSettings().then(setSettings);
    window.api.isRunning().then(setRunning);
    window.api.listSessions().then(setSessions);

    const offEvent = window.api.onRunEvent((event) => {
      setLogEntries((prev) => {
        if (event.type === 'step-end') {
          return [...prev, { kind: 'step', title: event.title, error: event.error }];
        }
        if (event.type === 'test-start') {
          return [...prev, { kind: 'test-start', title: event.title }];
        }
        if (event.type === 'test-end') {
          return [
            ...prev,
            {
              kind: 'test-end',
              title: event.title,
              status: event.status,
              durationMs: event.durationMs,
              error: event.error,
            },
          ];
        }
        if (event.type === 'run-start') {
          return [...prev, { kind: 'run-start', total: event.total }];
        }
        if (event.type === 'run-end') {
          return [...prev, { kind: 'run-end', status: event.status }];
        }
        if (event.type === 'process-exit') {
          setLastHtmlReportPath(event.htmlReportPath);
          return prev;
        }
        if (event.type === 'stderr') {
          return [...prev, { kind: 'stderr', message: event.message }];
        }
        if (event.type === 'raw' && event.message.trim()) {
          return [...prev, { kind: 'raw', message: event.message }];
        }
        return prev;
      });
    });

    const offExit = window.api.onRunExit(() => {
      setRunning(false);
      window.api.listSessions().then(setSessions);
    });

    return () => {
      offEvent();
      offExit();
    };
  }, [refreshAll]);

  // Replacements for window.confirm()/window.alert(). Those are Chromium-
  // native blocking dialogs with a well-documented class of Electron focus-
  // return bugs; a pure React modal (ConfirmModal) doesn't have that problem
  // — confirmed by direct comparison against PromptModal, which never showed
  // the issue across repeated open/close cycles. Since a React modal can't
  // return a value synchronously the way window.confirm() does, both
  // wrappers now return a Promise that resolves once the user clicks a
  // button, and every call site below awaits it.
  function confirmDialog(message, title) {
    return new Promise((resolve) => {
      setConfirmState({ message, title, showCancel: true, resolve });
    });
  }
  function alertDialog(message, title) {
    return new Promise((resolve) => {
      setConfirmState({ message, title, showCancel: false, resolve });
    });
  }
  function handleConfirmAccept() {
    confirmState.resolve(true);
    setConfirmState(null);
  }
  function handleConfirmDecline() {
    confirmState.resolve(false);
    setConfirmState(null);
  }

  // ---------- Spec CRUD ----------
  // Confirms with the user before any action that would silently discard
  // unsaved edits to the currently open spec (switching specs, starting a
  // new one, importing, or recording). OK -> proceed and discard. Cancel ->
  // stay exactly where the user is, nothing changes.
  function confirmDiscardIfDirty(message) {
    if (!dirty) return Promise.resolve(true);
    return confirmDialog(
      message ||
        `You have unsaved changes to "${activeSpec?.name || 'this spec'}". Continuing will discard them. Continue?`
    );
  }

  async function handleNewSpec() {
    if (!(await confirmDiscardIfDirty())) return;
    const collectionId = collections[0]?.id || 'default';
    setActiveSpec(emptySpec(collectionId));
    setDirty(true);
  }

  async function handleSelectSpec(spec) {
    if (activeSpec && spec.id === activeSpec.id) return; // already open, nothing to discard
    if (!(await confirmDiscardIfDirty())) return;
    setActiveSpec(spec);
    setDirty(false);
  }

  function handleChangeSpec(next) {
    setActiveSpec(next);
    setDirty(true);
  }

  // "Cancel" in the editor — always visible; clears the editor back to
  // empty, asking for confirmation first only when there are actual
  // unsaved changes to lose.
  async function handleCancelEdit() {
    if (!activeSpec) return;
    if (dirty && !(await confirmDialog('Discard your unsaved changes to this spec?'))) return;
    setActiveSpec(null);
    setDirty(false);
  }

  async function handleSaveSpec() {
    if (!activeSpec) return;
    const saved = await window.api.saveSpec(activeSpec);
    setActiveSpec(saved);
    setDirty(false);
    await refreshAll();
  }

  // Used by the JSON editor modal: saves the freshly-parsed object directly
  // (rather than relying on activeSpec state, which wouldn't have updated
  // yet if we just called onChange() and then handleSaveSpec() back to back).
  async function handleSaveSpecFromJson(parsedSpec) {
    const saved = await window.api.saveSpec(parsedSpec);
    setActiveSpec(saved);
    setDirty(false);
    setShowJsonEditor(false);
    await refreshAll();
  }

  async function handleDeleteSpec(spec) {
    if (!(await confirmDialog(`Delete "${spec.name}"?`))) return;
    await window.api.deleteSpec(spec);
    if (activeSpec && activeSpec.id === spec.id) setActiveSpec(null);
    setSelectedIds((prev) => {
      const next = { ...prev };
      delete next[spec.id];
      return next;
    });
    await refreshAll();
  }

  async function handleExportSpec() {
    if (!activeSpec) return;
    const savedPath = await window.api.exportSpec(activeSpec);
    if (savedPath) await alertDialog(`Exported to:\n${savedPath}`);
  }

  async function handleImportSpec() {
    if (!(await confirmDiscardIfDirty('You have unsaved changes. Importing will replace the spec currently open in the editor. Continue?'))) return;
    const collectionId = activeSpec?.collectionId || collections[0]?.id || 'default';
    const imported = await window.api.importSpecs(collectionId);
    if (!imported || imported.length === 0) return;
    setActiveSpec(imported[imported.length - 1]);
    setDirty(false);
    await refreshAll();
    if (imported.length > 1) {
      await alertDialog(`Imported ${imported.length} specs.`);
    }
  }

  function handleRecordingFinish(steps) {
    setShowRecorder(false);
    const collectionId = activeSpec?.collectionId || collections[0]?.id || 'default';
    setActiveSpec({
      id: null,
      collectionId,
      name: 'Recorded test',
      baseUrl: '',
      steps: steps && steps.length ? steps : [],
    });
    setDirty(true);
  }

  function handleNewCollection() {
    setShowNewCollection(true);
  }

  async function handleCreateCollection(name) {
    await window.api.createCollection(name);
    setShowNewCollection(false);
    await refreshAll();
  }

  async function handleDeleteCollection(id) {
    if (!(await confirmDialog('Delete this collection and all specs inside it?'))) return;
    await window.api.deleteCollection(id);
    await refreshAll();
  }

  async function handleExportCollection(id) {
    const savedPath = await window.api.exportCollection(id);
    if (savedPath) await alertDialog(`Exported collection to:\n${savedPath}`);
  }

  async function handleImportCollection() {
    const result = await window.api.importCollection();
    if (!result) return;
    await refreshAll();
    await alertDialog(`Imported collection "${result.collection.name}" with ${result.specs.length} spec(s).`);
  }

  function toggleChecked(spec) {
    setSelectedIds((prev) => {
      const next = { ...prev };
      if (next[spec.id]) delete next[spec.id];
      else next[spec.id] = spec;
      return next;
    });
  }

  // ---------- Settings ----------
  async function handleSaveSettings(newSettings) {
    const saved = await window.api.saveSettings(newSettings);
    setSettings(saved);
    setShowSettings(false);
  }

  // ---------- Run ----------
  function collectSpecFilePaths() {
    const chosen = Object.values(selectedIds);
    if (chosen.length > 0) return chosen.map((s) => s.__filePath).filter(Boolean);
    if (activeSpec && activeSpec.__filePath) return [activeSpec.__filePath];
    return null; // signal: run everything
  }

  async function handleRun() {
    setLogEntries([]);
    setRunning(true);
    let specFilePaths = collectSpecFilePaths();
    if (!specFilePaths) {
      const all = await window.api.listAllSpecs();
      specFilePaths = all.map((s) => s.__filePath).filter(Boolean);
    }
    if (specFilePaths.length === 0) {
      await alertDialog('No saved specs to run yet. Create and save a spec first.');
      setRunning(false);
      return;
    }
    try {
      await window.api.startRun(specFilePaths);
    } catch (err) {
      await alertDialog(err.message);
      setRunning(false);
    }
  }

  async function handleStop() {
    await window.api.stopRun();
    setRunning(false);
  }

  function handleOpenHtmlReport() {
    if (lastHtmlReportPath) window.api.openPath(lastHtmlReportPath);
  }

  const runDisabled = !settings;

  return (
    <div className="app">
      <Toolbar
        appIcon={appIcon}
        platform={platform}
        onRun={handleRun}
        onStop={handleStop}
        running={running}
        runDisabled={runDisabled}
        onOpenSettings={() => setShowSettings(true)}
        onOpenAbout={() => setShowAbout(true)}
        onNewSpec={handleNewSpec}
        onNewCollection={handleNewCollection}
        onOpenRecorder={async () => {
          if (!(await confirmDiscardIfDirty('You have unsaved changes. Recording a new test will replace the spec currently open in the editor once finished. Continue?'))) return;
          setShowRecorder(true);
        }}
        onOpenHtmlReport={handleOpenHtmlReport}
        htmlReportPath={lastHtmlReportPath}
      />

      <div className="main">
        <div className="left-panel" style={{ width: leftWidth }}>
          <CollectionTree
            collections={collections}
            specsByCollection={specsByCollection}
            activeSpecId={activeSpec?.id}
            selectedIds={selectedIds}
            onSelectSpec={handleSelectSpec}
            onToggleChecked={toggleChecked}
            onDeleteSpec={handleDeleteSpec}
            onDeleteCollection={handleDeleteCollection}
            onImportSpec={handleImportSpec}
            onExportCollection={handleExportCollection}
            onImportCollection={handleImportCollection}
          />
        </div>

        <PanelDivider onResize={(dx) => setLeftWidth((w) => clamp(w + dx, 180, 480))} />

        <div className="center-panel" style={{ width: centerWidth }}>
          <SpecEditor
            spec={activeSpec}
            collections={collections}
            sessions={sessions}
            onChange={handleChangeSpec}
            onSave={handleSaveSpec}
            onCancel={handleCancelEdit}
            onExport={handleExportSpec}
            onOpenJson={() => setShowJsonEditor(true)}
            dirty={dirty}
          />
        </div>

        <PanelDivider onResize={(dx) => setCenterWidth((w) => clamp(w + dx, 320, 900))} />

        <div className="right-panel">
          <LogPanel entries={logEntries} running={running} onClear={() => setLogEntries([])} />
        </div>
      </div>

      <div className="app-footer">
        <span>{copyrightLine()}</span>
        <a onClick={() => setShowAbout(true)} style={{ cursor: 'pointer' }}>About & Support</a>
      </div>

      {confirmState && (
        <ConfirmModal
          title={confirmState.title}
          message={confirmState.message}
          showCancel={confirmState.showCancel}
          onConfirm={handleConfirmAccept}
          onCancel={handleConfirmDecline}
        />
      )}

      {showAbout && <AboutModal onClose={() => setShowAbout(false)} />}

      {showJsonEditor && activeSpec && (
        <JsonEditorModal
          spec={activeSpec}
          onSave={handleSaveSpecFromJson}
          onClose={() => setShowJsonEditor(false)}
        />
      )}

      {showRecorder && (
        <RecorderModal
          onFinish={handleRecordingFinish}
          onClose={() => setShowRecorder(false)}
        />
      )}

      {showNewCollection && (
        <PromptModal
          title="New Collection"
          placeholder="Collection name"
          confirmLabel="Create"
          onSubmit={handleCreateCollection}
          onClose={() => setShowNewCollection(false)}
        />
      )}

      {showSettings && settings && (
        <SettingsModal
          initialSettings={settings}
          onSave={handleSaveSettings}
          onClose={() => setShowSettings(false)}
        />
      )}
    </div>
  );
}
