// Kept in sync with runner/actionRegistry.js and runner/locatorResolver.js.
// Only used to build editor dropdowns / hints — the runtime source of truth
// is always the runner package.

export const ACTIONS = [
  { name: 'goto', needsLocator: false, needsValue: true, valueLabel: 'URL / path' },
  { name: 'goBack', needsLocator: false, needsValue: false },
  { name: 'goForward', needsLocator: false, needsValue: false },
  { name: 'reload', needsLocator: false, needsValue: false },
  { name: 'click', needsLocator: true, needsValue: false },
  { name: 'dblclick', needsLocator: true, needsValue: false },
  { name: 'fill', needsLocator: true, needsValue: true, valueLabel: 'Text to enter' },
  { name: 'type', needsLocator: true, needsValue: true, valueLabel: 'Text to type' },
  { name: 'press', needsLocator: true, needsValue: true, valueLabel: 'Key (e.g. Enter)' },
  { name: 'pressKey', needsLocator: false, needsValue: true, valueLabel: 'Key or combo on whatever has focus (e.g. Tab, Shift+Tab, Control+A)' },
  { name: 'check', needsLocator: true, needsValue: false },
  { name: 'uncheck', needsLocator: true, needsValue: false },
  { name: 'selectOption', needsLocator: true, needsValue: true, valueLabel: 'Option value' },
  { name: 'hover', needsLocator: true, needsValue: false },
  { name: 'focus', needsLocator: true, needsValue: false },
  { name: 'setInputFiles', needsLocator: true, needsValue: true, valueLabel: 'File path' },
  { name: 'scrollIntoView', needsLocator: true, needsValue: false },
  { name: 'waitForSelector', needsLocator: true, needsValue: false },
  { name: 'waitForTimeout', needsLocator: false, needsValue: true, valueLabel: 'Milliseconds' },
  {
    name: 'waitForUrl',
    needsLocator: false,
    needsValue: true,
    valueLabel: 'URL (exact match by default — see "Treat as regex" below for partial matching)',
    extraFields: [
      {
        key: 'valueIsRegex',
        label: 'Treat value as a regex pattern (recommended for partial URL matching — plain wildcard/glob patterns are unreliable)',
        type: 'select',
        options: ['false', 'true'],
      },
    ],
  },
  { name: 'waitForLoadState', needsLocator: false, needsValue: true, valueLabel: 'load|domcontentloaded|networkidle' },
  { name: 'assertVisible', needsLocator: true, needsValue: false },
  { name: 'assertHidden', needsLocator: true, needsValue: false },
  { name: 'assertText', needsLocator: true, needsValue: true, valueLabel: 'Expected text' },
  { name: 'assertContainsText', needsLocator: true, needsValue: true, valueLabel: 'Expected substring' },
  { name: 'assertValue', needsLocator: true, needsValue: true, valueLabel: 'Expected value' },
  { name: 'assertCount', needsLocator: true, needsValue: true, valueLabel: 'Expected count' },
  { name: 'assertEnabled', needsLocator: true, needsValue: false },
  { name: 'assertDisabled', needsLocator: true, needsValue: false },
  { name: 'assertChecked', needsLocator: true, needsValue: false },
  {
    name: 'assertUrl',
    needsLocator: false,
    needsValue: true,
    valueLabel: 'Expected URL (exact match by default — see "Treat as regex" below for partial matching)',
    extraFields: [
      {
        key: 'valueIsRegex',
        label: 'Treat value as a regex pattern (recommended for partial URL matching — plain wildcard/glob patterns are unreliable)',
        type: 'select',
        options: ['false', 'true'],
      },
    ],
  },
  { name: 'assertTitle', needsLocator: false, needsValue: true, valueLabel: 'Expected title' },
  { name: 'screenshot', needsLocator: false, needsValue: true, valueLabel: 'Output file path' },

  // ---- Data flow: variables, external API calls, sessions ----
  // `extraFields` describes inputs beyond the standard locator/value columns;
  // the step editor renders them in an expandable row under the step.
  {
    name: 'apiRequest',
    needsLocator: false,
    needsValue: false,
    extraFields: [
      { key: 'method', label: 'HTTP method', type: 'select', options: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'] },
      { key: 'url', label: 'URL (supports {{variables}})', type: 'text', placeholder: 'https://api.example.com/login' },
      { key: 'headers', label: 'Headers (JSON object, optional)', type: 'textarea', placeholder: '{ "Content-Type": "application/json" }' },
      { key: 'body', label: 'Body (optional, supports {{variables}})', type: 'textarea', placeholder: '{ "username": "{{username}}" }' },
      { key: 'extractPath', label: 'Extract path from JSON response (e.g. data.collections)', type: 'text', placeholder: 'data.collections' },
      { key: 'extractRegex', label: 'Then apply regex within that field (optional — or on the whole response body if no path above)', type: 'text', placeholder: 'id=(\\w+)' },
      { key: 'extractRegexFlags', label: 'Regex flags (optional)', type: 'text', placeholder: 'i, g, s' },
      { key: 'saveAs', label: 'Save extracted value as variable', type: 'text', placeholder: 'authToken' },
      { key: 'expectStatus', label: 'On non-2xx response', type: 'select', options: ['fail', 'ignore'] },
    ],
  },
  {
    name: 'extractText',
    needsLocator: true,
    needsValue: false,
    extraFields: [{ key: 'saveAs', label: 'Save text as variable', type: 'text', placeholder: 'headingText' }],
  },
  {
    name: 'extractLocalStorage',
    needsLocator: false,
    needsValue: true,
    valueLabel: 'localStorage key',
    extraFields: [{ key: 'saveAs', label: 'Save value as variable', type: 'text', placeholder: 'authToken' }],
  },
  {
    name: 'setVariable',
    needsLocator: false,
    needsValue: true,
    valueLabel: 'Value (supports {{variables}})',
    extraFields: [{ key: 'saveAs', label: 'Variable name', type: 'text', placeholder: 'username' }],
  },
  {
    name: 'saveSession',
    needsLocator: false,
    needsValue: true,
    valueLabel: 'Session name to save as',
  },
  {
    name: 'conditional',
    needsLocator: false,
    needsValue: false,
    extraFields: [
      {
        key: 'conditionType',
        label: 'Condition',
        type: 'select',
        options: [
          'visible', 'hidden', 'exists', 'notExists',
          'checked', 'unchecked', 'enabled', 'disabled',
          'containsText', 'textEquals',
          'variableEquals', 'variableTruthy',
        ],
      },
      {
        key: 'conditionLocatorType',
        label: 'Locator type (for element-based conditions)',
        type: 'select',
        options: ['testid', 'role', 'text', 'label', 'placeholder', 'css', 'xpath', 'altText', 'title'],
      },
      { key: 'conditionLocatorValue', label: 'Locator value', type: 'text', placeholder: '#banner or selector' },
      { key: 'conditionVariableName', label: 'Variable name (for variableEquals / variableTruthy)', type: 'text', placeholder: 'authToken' },
      { key: 'conditionValue', label: 'Expected text/value (for containsText / textEquals / variableEquals)', type: 'text', placeholder: 'Welcome back' },
      // Note: thenSteps/elseSteps are NOT listed here — StepList.jsx renders
      // them as full nested, clickable step editors (not a flat field),
      // since they hold arrays of steps rather than a single value.
    ],
  },
];

export const LOCATOR_TYPES = [
  { value: 'testid', label: 'Test ID' },
  { value: 'role', label: 'Role' },
  { value: 'text', label: 'Text' },
  { value: 'label', label: 'Label' },
  { value: 'placeholder', label: 'Placeholder' },
  { value: 'altText', label: 'Alt text' },
  { value: 'title', label: 'Title attr' },
  { value: 'css', label: 'CSS selector' },
  { value: 'xpath', label: 'XPath' },
];

export const BROWSERS = ['chromium', 'firefox', 'webkit'];

export const COMMON_DEVICES = [
  '',
  'iPhone 13',
  'iPhone 14 Pro',
  'Pixel 7',
  'iPad Mini',
  'Galaxy S9+',
];

export function emptyStep() {
  return { action: 'click', locator: { type: 'testid', value: '' }, value: '' };
}

export function emptySpec(collectionId) {
  return {
    id: null,
    collectionId: collectionId || 'default',
    name: 'New test case',
    baseUrl: '',
    sessionKey: '',
    testDataFile: '',
    variables: [],
    steps: [emptyStep()],
  };
}

export function emptyVariable() {
  return { name: '', value: '' };
}

export function actionMeta(name) {
  return ACTIONS.find((a) => a.name === name) || ACTIONS[0];
}
