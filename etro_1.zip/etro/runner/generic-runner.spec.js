// This is the ONLY Playwright spec file in the whole app.
// It never changes when the user adds/edits test cases — it just interprets
// whatever generic JSON test-case files are selected for the current run.
const { test, expect } = require('@playwright/test');
const fs = require('fs');
const { loadSpecs } = require('./specLoader');
const { interpolateDeep } = require('./interpolate');
const { loadSession } = require('./sessionStore');
const { runStepList } = require('./stepRunner');

const specs = loadSpecs();

// off | on | only-on-failure — independent of Playwright's own end-of-test `screenshot` option.
// 'on' attaches a screenshot after every step; 'only-on-failure' attaches one only for the step
// that threw. Both are visible per-step in the HTML report's attachments.
const STEP_SCREENSHOT_MODE = process.env.PWD_STEP_SCREENSHOTS || 'off';

function buildRunFn(spec) {
  return async function runFn({ page }, testInfo) {
    if (spec.__error) {
      throw new Error(`Could not parse spec JSON: ${spec.__error}`);
    }

    // Seed variables:
    //  1. testData — read FRESH from disk on every run (not embedded in the
    //     spec at save time), so editing the JSON file directly is picked up
    //     immediately without needing to re-save the spec. Nested access
    //     like {{testData.details.myName}} works because runner/interpolate.js's
    //     getPath() already walks dotted paths through nested objects.
    //  2. the spec's own "Variables" table, applied after — lets a seeded
    //     variable override something from testData if the names collide.
    // Then apiRequest / extractText / extractLocalStorage / setVariable steps
    // add to (or overwrite) all of this as the test runs. {{name}} anywhere in
    // a later step's fields is replaced from this object before that step executes.
    const variables = {};
    if (spec.testDataFile) {
      let raw;
      try {
        raw = fs.readFileSync(spec.testDataFile, 'utf-8');
      } catch (err) {
        throw new Error(`Could not read test data file "${spec.testDataFile}": ${err.message}`);
      }
      try {
        variables.testData = JSON.parse(raw);
      } catch (err) {
        throw new Error(`Test data file "${spec.testDataFile}" is not valid JSON: ${err.message}`);
      }
    }
    for (const v of spec.variables || []) {
      if (v && v.name) variables[v.name] = v.value;
    }
    const ctx = { variables, testInfo };

    if (spec.baseUrl) {
      const url = interpolateDeep(spec.baseUrl, variables);
      await test.step(`goto ${url}`, async () => {
        await page.goto(url);
      });
    }

    await runStepList({
      page,
      steps: spec.steps,
      variables,
      ctx,
      testInfo,
      test,
      expect,
      stepScreenshotMode: STEP_SCREENSHOT_MODE,
    });
  };
}

for (const spec of specs) {
  const title = spec.name || spec.id || 'Untitled test';
  const runFn = buildRunFn(spec);

  if (spec.sessionKey) {
    // A saved session can only be applied when the browser context is created,
    // so a spec that wants one gets its own describe block with `test.use`.
    test.describe(title, () => {
      const storageState = loadSession(spec.sessionKey);
      if (storageState) {
        test.use({ storageState });
      }
      test(title, runFn);
    });
  } else {
    test(title, runFn);
  }
}
