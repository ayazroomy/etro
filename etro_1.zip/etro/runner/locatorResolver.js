/**
 * Maps a generic, UI-authored locator definition into a real Playwright Locator.
 * This is the single place that knows about Playwright's locator API, so the
 * rest of the app (UI, storage, action registry) can stay Playwright-agnostic.
 *
 * Locator def shape:
 *   { type: 'testid'|'role'|'text'|'label'|'placeholder'|'css'|'xpath'|'altText'|'title', value, role, name, exact }
 */

function resolveLocator(scope, locator) {
  if (!locator || !locator.type) {
    throw new Error('Step is missing a "locator" definition');
  }

  const { type, value, role, name, exact } = locator;

  switch (type) {
    case 'testid':
      return scope.getByTestId(value);

    case 'role':
      return scope.getByRole(role || value, {
        name: name || undefined,
        exact: exact || false,
      });

    case 'text':
      return scope.getByText(value, { exact: exact || false });

    case 'label':
      return scope.getByLabel(value, { exact: exact || false });

    case 'placeholder':
      return scope.getByPlaceholder(value, { exact: exact || false });

    case 'altText':
      return scope.getByAltText(value, { exact: exact || false });

    case 'title':
      return scope.getByTitle(value, { exact: exact || false });

    case 'css':
      return scope.locator(value);

    case 'xpath':
      return scope.locator(`xpath=${value}`);

    default:
      throw new Error(`Unknown locator type: "${type}"`);
  }
}

module.exports = { resolveLocator };
