# ETRO

A visual, config-driven Playwright test studio: author **generic, data-driven test
cases** (not raw Playwright code) and run them through Playwright, with a live
log/results panel.

## Architecture in one paragraph

Test cases are plain JSON files (`{ name, baseUrl, steps: [{ action, locator, value }] }`).
There is exactly **one** real Playwright spec file, `runner/generic-runner.spec.js`,
which never changes — at run time it loads whichever JSON specs were selected and
interprets each step through `runner/actionRegistry.js` (the action → Playwright-call
lookup table) and `runner/locatorResolver.js` (the locator-definition → Playwright
`Locator` lookup table). All Playwright *configuration* (browsers, viewport, video,
screenshots, trace, report folder, timeouts, retries) comes from the Settings modal
and is serialized into a real `playwright.config.js` before every run by
`electron/configBuilder.js` — no test logic is code-generated, only config.

```
electron/        Electron main process (window, IPC, data storage, spawns Playwright)
  main.js
  preload.js          contextBridge-exposed API for the renderer
  ipcHandlers.js       all ipcMain.handle(...) wiring
  dataStore.js         collections/specs/settings persistence (JSON files under data/)
  configBuilder.js      writes playwright.config.js from Settings
  testRunner.js         spawns `npx playwright test`, parses reporter events

runner/          The Playwright-facing package. This is what actually executes tests.
  generic-runner.spec.js   the ONE spec file; interprets JSON test cases
  actionRegistry.js         the test DSL: action name -> Playwright call
  locatorResolver.js         locator definition -> Playwright Locator
  specLoader.js               reads which spec JSON files to run for this run
  electron-reporter.js         custom reporter -> NDJSON events on stdout

renderer/        React (JS, Vite) UI
  src/App.jsx                 top-level state & wiring
  src/components/
    Toolbar.jsx                Run / Stop / Settings / New Spec / New Collection
    CollectionTree.jsx          left panel: collections + specs, checkboxes to select a run
    SpecEditor.jsx               center panel: name/baseUrl + editable step table
    SettingsModal.jsx             all Playwright settings (browsers, viewport, video, etc.)
    LogPanel.jsx                   right panel: live streamed run log

data/             Local storage (created automatically)
  specs/<collectionId>/<specId>.json
  collections.json
  settings.json
  reports/<runId>/html/index.html   (generated per run)
```

## Setup

```bash
npm install
# Downloads Playwright's browser binaries (also runs automatically via postinstall)
npx playwright install
```

## Run in development

```bash
npm run dev
```
This starts the Vite dev server for the renderer and launches Electron pointed at it,
with DevTools open.

## Run in production mode locally

```bash
npm run build      # builds renderer into dist/renderer
npm start           # launches Electron loading the built files
```

## How a run actually works

1. You select spec(s) in the left panel (checkboxes) or just have one open, and click **Run**.
2. The renderer sends the list of spec **file paths** to the main process (`run:start`).
3. `testRunner.js`:
   - reads current settings, writes a real `playwright.config.js` to a temp path via `configBuilder.js`
   - writes a temp "filter file" (JSON array of spec paths) so `generic-runner.spec.js` knows which specs to load this run
   - spawns `npx playwright test --config <that config>`
4. The custom reporter (`electron-reporter.js`) prints one JSON event per line
   (`run-start`, `test-start`, `step-start/end`, `test-end`, `run-end`) prefixed with
   `__PWD_EVENT__`.
5. `testRunner.js` parses each line and forwards it over IPC (`run:event`) to the renderer,
   which appends it to the live log panel in real time.
6. On completion, Playwright has already written the HTML report to the configured
   report directory; "Open Last HTML Report" opens `index.html` with the OS default viewer.

## Extending the test DSL

To support a new step type (e.g. a new gesture or assertion):

1. Add a handler to `runner/actionRegistry.js`:
   ```js
   dragTo: async (page, step) => {
     await resolveLocator(page, step.locator).dragTo(resolveLocator(page, step.targetLocator));
   },
   ```
2. Add its metadata to `renderer/src/actionMeta.js` so it shows up in the step editor dropdown.

Nothing else needs to change — `generic-runner.spec.js` and the config builder are
already generic over the action set.

**Security note on the `evaluate` action**: `actionRegistry.evaluate` uses
`new Function(...)` to run user-authored JS against the page — powerful, but arbitrary
code execution. Keep it or remove it depending on how trusted your users/spec sources are.

## Per-step screenshots

Playwright's own `screenshot: on/only-on-failure` setting only captures **once**, at
the end of a test — that's a Playwright limitation. To get a screenshot after every
individual step, this app has a **separate** "Screenshots (per step)" setting in the
Settings modal. When enabled, `generic-runner.spec.js` explicitly calls
`page.screenshot()` after (or on failure of) each `test.step()` and attaches it via
`testInfo.attach()`, so it shows up per-step in the HTML report's attachments —
independent of Playwright's built-in end-of-test screenshot option.

## Export / Import test cases

- **Export**: open a spec, click **Export…** in the editor. A native Save dialog lets
  you write the spec's JSON to any location, e.g. to share with a teammate or check
  into version control outside the app's own `data/` folder.
- **Import**: click **Import Spec…** above the collection tree. A native Open dialog
  lets you pick a previously exported `.json` file; it's added as a new spec (with a
  freshly generated id, so importing never collides with or overwrites an existing spec)
  into the currently active collection.

## Generating test cases by recording browser actions

Click **● Record** in the toolbar, choose a browser and a starting URL, then **Start
Recording**. A real, visible browser window opens. Clicking, typing into fields,
checking boxes, choosing `<select>` options, and navigating are all captured live and
shown as steps in the modal as you go — built on top of the same `runner/actionRegistry.js`
DSL, via `electron/recorder.js`:

- Playwright launches the browser and injects a small recorder script
  (`context.addInitScript`) into every page/frame.
- That script listens for `click` and `change` events at the document level and picks
  the best available locator for the target element, in this preference order:
  `data-testid` → `id` → `aria-label` → role+accessible-name (buttons/links) →
  `placeholder` → a best-effort CSS path fallback.
- Each detected action is sent back to the Electron main process via
  `context.exposeFunction('__pwd_record', ...)`, and from there streamed to the
  renderer over IPC (`recorder:step`) in real time.
- Page navigations are captured separately via `page.on('framenavigated', ...)` as
  `goto` steps.

Click **Stop & Review** (or just close the recorded browser window) to end the
session — the captured steps are loaded straight into the normal spec editor as a new,
unsaved "Recorded test" spec. From there you edit, rename, reorder, or delete steps
exactly like a hand-authored spec, then **Save** and **Run** it.

**Known limitations of the recorder** (reasonable to improve later, not fixed here):
- Only `click` and `change` DOM events are captured — there's no `press` (individual
  key) or `hover` capture, and text inputs are recorded on blur/commit rather than
  keystroke-by-keystroke.
- The CSS-path fallback selector can be brittle against dynamic class names; prefer
  pages that expose `data-testid`, `id`, or accessible names for durable locators.
- Only one recording session can run at a time.

## Variables, external API calls, and reusable login sessions

Three actions make step-to-step (and test-to-test) data flow possible:

- **`apiRequest`** — calls an external API (method, URL, headers, body are all
  configurable, and all support `{{variable}}` substitution). Point `extractPath` at a
  dot-path into the JSON response (e.g. `data.token`, `data.items[0].id`) and `saveAs`
  a variable name; the extracted value becomes available to every later step in the
  same test. The call goes through `page.context().request`, so it automatically shares
  the browser context's cookies with a logged-in page.
- **`extractText`** — grabs the visible text of a located element and saves it as a
  variable.
- **`extractLocalStorage`** — reads a `localStorage` key from the current page and
  saves its value as a variable.
- **`setVariable`** — sets a variable by hand (its value itself can reference other
  `{{variables}}`).

Any step's `value`, `locator.value`, `locator.name`, `baseUrl`, `url`, `headers`, or
`body` field can reference a variable with `{{variableName}}` — it's resolved right
before that step runs. A spec's **Variables** table (in the editor, above Steps) lets
you seed starting values (e.g. a username) before the run even begins.

**Reusable login sessions** — a `saveSession` step captures the current browser
context's cookies + localStorage (via Playwright's `storageState()`) under a name you
choose. Any *other* spec can then set **"Start from saved session"** in its editor to
launch already logged in, skipping repeated login steps. Note the practical limit here:
Playwright only supports loading a `storageState` when a browser context is *created*,
so a saved session applies at the very start of a test, not mid-test — this matches
Playwright's own recommended pattern (log in once, reuse the state everywhere) rather
than a general mid-test session swap.

## Building & distributing for Windows and Mac

The app is packaged with [electron-builder](https://www.electron.build/), already
configured in `package.json`'s `"build"` field.

```bash
npm install
npm run build          # builds the React renderer into dist/renderer

npm run dist:mac        # produces a .dmg and .zip under dist/ (run on a Mac)
npm run dist:win         # produces an NSIS installer .exe under dist/ (run on Windows,
                          # or on Mac/Linux with Wine installed)
npm run dist              # both, if your machine/CI can build both
```

electron-builder can cross-build Windows installers from Mac/Linux (via Wine), but
**cannot** produce a Mac build from Windows/Linux — Apple's tooling only runs on macOS.
If you need both and don't have a Mac, use a CI runner (GitHub Actions' `macos-latest`
is the common choice) or a Mac in the cloud.

### What had to change to make this actually distributable

A dev setup running via `npm run dev` on your own machine hides three problems that
only show up once someone else installs the packaged app on a clean machine. All three
are already fixed in this codebase — worth understanding *why*, in case you extend it:

1. **No npm/npx on the end user's machine.** The app used to run tests via
   `npx playwright test`, which requires npm to be installed system-wide — it won't be,
   on a machine that only has your installer. `electron/testRunner.js` now spawns
   Playwright's own `cli.js` directly through `process.execPath` with
   `ELECTRON_RUN_AS_NODE=1`, which makes the **Electron binary itself** behave as a
   plain Node.js runtime. No external Node or npm is needed at all — only the app.

2. **The installed app's own folder isn't writable.** `Program Files` on Windows and
   the `.app` bundle on Mac are effectively read-only for a standard user, but the app
   needs to write specs, settings, sessions, and reports somewhere. `electron/dataStore.js`
   now checks `app.isPackaged`: in dev it still uses the project-local `data/` folder
   (handy for inspecting), but once packaged it switches to `app.getPath('userData')` —
   the OS-standard per-user app-data folder (e.g. `%APPDATA%\ETRO` on
   Windows, `~/Library/Application Support/ETRO` on Mac).

3. **Browser binaries aren't bundled in the installer** (they're large — hundreds of MB
   each — and Playwright downloads them to a shared per-user cache, not into
   `node_modules`). A machine with no npm can't run `npx playwright install` either.
   Settings → **Install Selected Browsers** solves this: it runs Playwright's own
   `install` command through the same `process.execPath` + `ELECTRON_RUN_AS_NODE` trick,
   with live output shown in the modal (`electron/browserInstaller.js`). Tell people to
   click it once after installing the app, before their first run.

### Packaging notes

- **`asarUnpack`** in the build config extracts `runner/**` and the Playwright packages
  out of the `app.asar` archive onto real disk (as `app.asar.unpacked/`) rather than
  leaving them archived. This is required because Playwright spawns real, separate
  browser executables — those can't run from inside an archive — and it also sidesteps
  any doubt about whether a spawned child process's file reads work correctly against
  asar-archived paths.
- **Code signing / notarization**: an unsigned `.dmg` shows a Gatekeeper warning on Mac,
  and an unsigned `.exe` shows a SmartScreen warning on Windows — both still let a user
  click through, but see "Code signing & notarization" below for how to get rid of them
  properly (the project is already wired up for it, just needs real credentials).
- **App icon**: add `build/icon.icns` (Mac) and `build/icon.ico` (Windows) and
  electron-builder picks them up automatically by convention — none are included yet,
  so it'll currently ship with Electron's default icon.
- The `postinstall` script (`playwright install ...`) is only meaningful for
  **developers** running `npm install` from source — it has no effect on an end user's
  machine, since they never run `npm install` at all. That's exactly why the in-app
  Install Browsers button exists.

### Windows: "Cannot create symbolic link" during `dist:win`

electron-builder downloads a `winCodeSign` helper package that bundles both actual
code-signing tools **and** `rcedit` (used to stamp the app's icon/version info onto the
built `.exe`) into the same archive — including some macOS `.dylib` files packaged as
symlinks. Extracting those requires a privilege standard Windows accounts don't have
unless Developer Mode is on, failing with
`ERROR: Cannot create symbolic link : A required privilege is not held by the client.`

`CSC_IDENTITY_AUTO_DISCOVERY=false` (already set in the `dist:*` scripts) stops
electron-builder from trying to *sign*, but the `rcedit` icon/version-stamping step still
runs by default and still needs that same archive — so the download/extraction failure
can persist even with that env var set. The build config's `"win": { "signAndEditExecutable": false }`
turns that step off entirely, which is what actually avoids the download. The trade-off:
the built `.exe` won't have its icon/version metadata embedded via rcedit. Since no custom
icon is configured yet anyway (see "App icon" above — it currently ships with Electron's
default), this has no practical effect right now. If you add a custom `.ico` later and want
it properly embedded in the `.exe` itself (not just shown in the installer), the complete
fix is to enable **Windows Developer Mode** (Settings → Privacy & Security → For developers
→ Developer Mode) — that grants standard accounts symlink-creation rights, letting the
winCodeSign archive extract normally so rcedit can run — and re-enable
`signAndEditExecutable` at that point.

If you hit this after a previous failed attempt left a corrupted partial download behind,
also clear electron-builder's cache first: delete
`%LOCALAPPDATA%\electron-builder\Cache\winCodeSign` and re-run.

## Code signing & notarization

Unsigned builds work and install fine — Windows' SmartScreen and macOS' Gatekeeper just
show a warning first, which users can click through. Getting rid of those warnings
requires getting a real, paid credential from Microsoft/Apple; the project is already
wired up to use one the moment you have it. Signing/notarizing itself is *not* something
this project can automate — it fundamentally requires you to hold a credential tied to
your (or your company's) identity, which only Microsoft/Apple can issue.

### Windows

1. **Get a code-signing certificate.** As of June 2023, the CA/Browser Forum requires
   the private key to live on a hardware token or cloud HSM — a plain downloadable
   `.pfx` file is no longer issued for new certs. Two practical routes:
   - **Azure Trusted Signing** — Microsoft's newer, cheaper option (~$10/month), cloud-based,
     no physical token needed. Good default choice for indie/small teams.
   - **Traditional EV certificate** (DigiCert, SSL.com, GlobalSign, etc., ~$300–700/year)
     — ships as a USB hardware token; Windows SmartScreen trusts EV-signed apps
     immediately. A standard (OV) cert is cheaper but SmartScreen reputation builds up
     gradually based on install telemetry, so early users may still see warnings.
2. **Configure electron-builder with it.** For a traditional token/certificate installed
   in the Windows certificate store, set:
   ```
   set CSC_LINK=path\to\cert-or-container-reference
   set CSC_KEY_PASSWORD=your-token-password
   ```
   (or `win.certificateSubjectName` / `win.certificateSha1` in `package.json`'s `build.win`
   if referencing a cert already in the Windows cert store). For Azure Trusted Signing,
   electron-builder's `win.azureSignOptions` config points at your Azure endpoint/account
   instead — see electron-builder's docs for the exact fields, since Azure's onboarding
   flow changes fairly often.
3. **Re-enable `signAndEditExecutable`** (currently `false` in `package.json`'s `build.win`
   purely to dodge the winCodeSign download issue — see above) and enable
   **Windows Developer Mode** so that download/extraction succeeds.
4. Run `npm run dist:win` — electron-builder signs both the app `.exe` and the NSIS
   installer automatically once it detects valid signing config.

### Mac

1. **Enroll in the Apple Developer Program** ($99/year) at developer.apple.com.
2. **Create a "Developer ID Application" certificate** — via Xcode (Settings → Accounts →
   Manage Certificates → +) or the Apple Developer portal — and let it install into your
   login keychain. This is what signs the app; a *separate* "Developer ID Installer"
   certificate exists too but isn't needed for the `.dmg`/`.zip` targets configured here.
3. **Point electron-builder at it.** With the certificate in your keychain, electron-builder
   auto-discovers it — no extra config needed, as long as you *don't* set
   `CSC_IDENTITY_AUTO_DISCOVERY=false` (the `dist:mac` script here already doesn't). If you'd
   rather be explicit, set `mac.identity` in `package.json`'s `build.mac` to the certificate's
   name (e.g. `"Developer ID Application: Your Name (TEAMID)"`).
4. **Notarize.** Apple requires every distributed Mac app be notarized (submitted to
   Apple's automated malware-scanning service) since Catalina — an app can be signed but
   still get blocked by Gatekeeper if it isn't notarized too. This project already includes
   `build/notarize.js`, wired up via `package.json`'s `"afterSign"` hook, using
   `@electron/notarize`. It activates automatically once you set:
   ```bash
   export APPLE_ID="you@example.com"
   export APPLE_APP_SPECIFIC_PASSWORD="xxxx-xxxx-xxxx-xxxx"  # generate at appleid.apple.com, NOT your normal password
   export APPLE_TEAM_ID="ABCDE12345"                          # found in Apple Developer portal → Membership
   ```
   and stays a silent no-op (prints a skip message) if those aren't set — so unsigned dev
   builds keep working exactly as before.
5. Run `npm run dist:mac` — electron-builder signs, then the `afterSign` hook notarizes
   and staples the result automatically. Notarization typically takes a few minutes; the
   build won't finish until Apple responds.

## Running without paying for anything

Signing/notarization is entirely optional — it only removes a one-time OS warning
screen, it does not gate whether the app can be built, installed, or run. Everything
covered so far already works completely free with **zero setup and zero payment**:
`npm run dist:win` / `npm run dist:mac` already produce a fully working, installable app.

### Opening an unsigned build

**Windows (SmartScreen):** double-click the installer → Windows shows "Windows
protected your PC" → click **"More info"** → **"Run anyway"**. One click, one time, per
installer — after install the app itself runs normally with no further warnings.

**Mac (Gatekeeper):** since the app isn't notarized, macOS blocks a plain double-click.
Two free ways around it, no account needed:
- **Right-click (or Control-click) the app → "Open"** → confirm **"Open"** in the dialog
  that appears. This has to be done once per app, via right-click specifically — a normal
  double-click will refuse.
- If macOS doesn't offer that path (varies by version) or shows "app is damaged":
  ```bash
  xattr -cr /Applications/Playwright\ Desktop.app
  ```
  This strips the quarantine flag macOS attaches to anything downloaded from the
  internet — that flag is specifically what triggers the Gatekeeper check, so removing
  it lets the app open normally afterward.
- On Apple Silicon (M1/M2/M3+) Macs, every executable needs *at least* an ad-hoc
  signature just to run at all — this is separate from Gatekeeper and free automatically:
  electron-builder applies one on its own even with no certificate configured, no action
  needed on your part.

This is a completely standard, common way many free/open-source Electron apps are
distributed — as long as you can tell your users the one-time steps above, there's
nothing else required.

### Getting a Mac build without owning a Mac

electron-builder can only produce a `.dmg`/Mac `.zip` when actually run *on* macOS —
there's no way around that from Windows/Linux, Apple's tooling simply isn't available
elsewhere. If you don't have a Mac, the free option is **GitHub Actions**: it provides
real macOS (and Windows) runners at no cost for public repositories (private repos get a
monthly free-minutes budget too, though macOS runners use it up 10x faster than Linux
ones). This project includes `.github/workflows/build.yml`, already set up to build both
platforms and let you download the results:

1. Push this project to a GitHub repository.
2. Go to the repo's **Actions** tab → select **"Build Desktop App"** → **"Run workflow"**
   (or just push a tag like `v1.0.0` — the workflow also triggers on that).
3. Once it finishes (a few minutes), open the run and download the
   `etro-macos-latest` / `etro-windows-latest` artifacts —
   these are your unsigned `.dmg`/`.zip`/`.exe` files, built for real on each OS, ready
   to hand out with the instructions above.

## Shipping updates ("Check for Updates" under About)

The **ⓘ About** button in the toolbar shows the running version and a
**Check for Updates** flow, built on [`electron-updater`](https://www.electron.build/auto-update)
(`electron/updater.js`). Here's the full loop, end to end:

### One-time setup

1. In `package.json`'s `build.publish` block, replace `"owner"`/`"repo"` with your real
   GitHub username and repo name. Do the same for `REPO_URL` at the top of
   `renderer/src/components/AboutModal.jsx` (used for the "View Releases on GitHub" link).
2. Push the project to that GitHub repo (needed either way, per the CI section above).

### Shipping a new version

1. Bump `"version"` in `package.json` (e.g. `0.1.0` → `0.1.1`) and commit it.
2. Tag and push:
   ```bash
   git tag v0.1.1
   git push --tags
   ```
3. `.github/workflows/build.yml`'s tag-triggered job runs automatically: it builds both
   platforms **and** runs `electron-builder --publish always`, which uploads the
   installers *and* small metadata files (`latest.yml` for Windows, `latest-mac.yml` for
   Mac — these just contain the version number, file hash, and download URL) to a new
   GitHub Release matching the tag.
4. That's it — nothing else to trigger. Every already-installed copy of the app will see
   the new version the next time someone clicks Check for Updates (see below).

### What happens when a user clicks "Check for Updates"

1. The app asks GitHub for the latest release's `latest.yml`/`latest-mac.yml` and
   compares the version number in it against its own (`app.getVersion()`).
2. If newer: shows **"Update available: vX.X.X"** with a **Download** button — nothing
   downloads automatically, the user has to click it (`autoUpdater.autoDownload = false`
   in `updater.js`, deliberately — no silent background downloads).
3. Clicking Download streams live progress (`updates:status` events over IPC) until it's
   done, then shows **"Restart & Install vX.X.X"**.
4. Clicking that quits the app, applies the update, and relaunches — on Windows this
   silently runs the new NSIS installer; on Mac it swaps in the new `.app` bundle.

### The one real limitation: Mac needs a real Apple signing certificate

This is the one part of "free updates" that genuinely isn't free, and I'd rather tell
you now than have it quietly fail on you later: Squirrel.Mac (the framework
`electron-updater` uses under the hood on macOS) verifies the code signature of the new
version against the running one *before* it will apply an update, as a security measure
against a malicious update being swapped in. An unsigned or merely ad-hoc-signed build
doesn't have a real identity to verify, so **in-app download-and-install reliably fails
on an unsigned Mac build** — checking for updates and seeing the version number still
works fine (that part is just comparing a version string), but the actual apply step
needs the Apple Developer ID signing + notarization setup described earlier in this
README. Until/unless you set that up, Mac users should use the **"View Releases on
GitHub"** link in the About modal and manually download+replace the app for now — the
About modal's UI already surfaces this distinction so it doesn't look like a silent bug.
Windows updates have no such requirement and work fully unsigned.

## What's new in this pass

A quick reference for the latest round of features — full details are in the relevant
source files' comments.

- **Multi-file spec import** — the Import Spec(s) dialog now accepts selecting several
  `.json` files at once; invalid files are skipped individually rather than aborting
  the whole batch (`electron/ipcHandlers.js`'s `specs:import`).
- **Collection export/import** — export a whole collection (all its specs bundled into
  one `.etro-collection.json` file) via the ⭱ button next to each collection name;
  import it back in via **Import Collection…** above the tree. Import always creates a
  *fresh* collection with fresh spec ids, so it never collides with or overwrites
  anything already in your library.
- **Regex extraction for `apiRequest`** — a new `extractRegex` field (with optional
  `extractRegexFlags`) on the API Request step. Takes priority over `extractPath` when
  both are set — useful for non-JSON responses (HTML, headers, plain text) or pulling a
  value out of a JSON body without matching its exact shape. Uses the first capture
  group if the pattern has one, otherwise the full match.
- **Menu bar hidden** — the default File/Edit/View/Window/Help menu bar is removed via
  `Menu.setApplicationMenu(null)` (`electron/main.js`). On Mac, the OS-level app menu
  (leftmost menu, holding Quit/Cmd+Q) can't be fully removed by platform convention —
  this still strips it down to Electron's bare minimum.
- **Themes** — Default, Light, and Dark, selectable in Settings → Appearance. All
  colors in `renderer/src/styles.css` are CSS variables under `[data-theme="..."]`
  blocks; `App.jsx` applies the chosen one to `<html data-theme="...">`. Default is the
  starting theme for a fresh install.
- **App icon** — `build/icon.png` (1024×1024 master) and `build/icon.ico` (multi-size,
  for Windows) live under `build/`; electron-builder auto-converts the PNG to `.icns`
  for Mac. In-app copies live under `electron/assets/` (splash screen, main/taskbar
  icon) and `renderer/src/assets/` (About modal, toolbar brand).
- **Splash screen** — a small frameless window (`electron/splash.html`) shows the icon
  and a loading spinner immediately on launch, closing once the main window is ready.
- **Team info & copyright** — `renderer/src/appInfo.js` is the single place holding
  `APP_NAME`, `TEAM_NAME`, `TEAM_EMAILS`, and the repo URL; the About modal and the
  footer both read from it. **Update the placeholder values in that file** before
  relying on the About modal's contact info or the footer being accurate.
- **Test Data JSON file** — a "Test Data" section in the spec editor lets you point a
  spec at an external `.json` file instead of hardcoding values into steps. Only the
  file *path* is stored on the spec (`spec.testDataFile`) — its contents are read fresh
  from disk on every test run (`runner/generic-runner.spec.js`), so editing the JSON
  file directly takes effect on the next run with no need to re-save the spec. Reference
  any value, including nested ones, with `{{testData.details.myName}}` — this works
  because it's seeded into the same `variables` object every other `{{...}}`
  interpolation already reads from. A missing or invalid file fails only that one test
  (with a clear message identifying the file), not the whole run.
- **Unsaved-changes guard** — switching to a different spec, starting a new one,
  importing, or opening the recorder while the current spec has unsaved edits now asks
  for confirmation first (`App.jsx`'s `confirmDiscardIfDirty`). OK discards the edits and
  proceeds; Cancel leaves you exactly where you were.
- **Keyboard actions** — a new `pressKey` action (`runner/actionRegistry.js`) sends a
  key straight to whatever element currently has focus via `page.keyboard.press()`, with
  no locator needed — unlike `press` (which requires a locator and focuses that element
  first). This is what makes Tab-driven navigation replayable: recording a sequence of
  `pressKey: Tab` steps reproduces the same focus movement on replay, just like a real
  user tabbing through the page. Supports Playwright's combo syntax directly, e.g.
  `Shift+Tab`, `Control+A`, `ArrowDown`. Available to hand-author in the step editor too.

  The recorder (`electron/recorder.js`) now listens for `keydown` in addition to
  `click`/`change`, and captures: Tab/Enter/Escape always (even inside text fields, since
  leaving/submitting/cancelling is meaningful there); arrow keys, Home/End/PageUp/PageDown,
  and Space *only* when focus isn't in a plain text field (inside one, those just move the
  caret or insert a literal space — not meaningful for replay); and any modifier
  combination (Ctrl/Cmd/Alt/Shift + key) always, as a shortcut. Plain character typing is
  intentionally not captured here — that's still handled by the existing `change`-based
  `fill` capture, so you don't get a separate step per keystroke.

## Fixed: DevTools console noise, keyboard focus, and the title bar

Three issues found while dogfooding, all fixed in `electron/main.js` (plus a shared
`electron/themeColors.js` and small IPC additions):

- **"Request Autofill.enable failed" in the dev console** — harmless. Chromium's
  DevTools frontend calls a CDP domain ('Autofill', used for its own Elements-panel
  highlighting) that Electron's embedded Chromium doesn't implement — this is a
  long-standing, widely-reported Electron/Chromium quirk unrelated to this app, and only
  ever shows up in dev mode with DevTools open. `app.commandLine.appendSwitch('disable-features', 'Autofill')`
  quiets it in most Electron versions; if a line or two still slips through occasionally,
  it's safe to ignore.
- **Text fields not accepting input until switching focus away and back** — a real bug.
  The splash screen closing right as the main window became visible meant
  `mainWindow.show()` made the window *visible* without the OS actually handing it
  *keyboard focus* — alt-tabbing away and back was what forced the OS to reassign it.
  (This turned out to need a follow-up fix beyond the first pass — see below.)
- **Title bar showing a stark light color instead of matching the theme** — the title
  bar is native OS chrome; recoloring it needs an explicit Electron API, it doesn't
  follow in-page CSS at all. On Windows/Linux, the window now uses
  `titleBarStyle: 'hidden'` with a themed `titleBarOverlay` (same native
  minimize/maximize/close buttons, just recolored to match the current theme) instead of
  the OS-default title bar; the in-app toolbar is now the effective title bar (draggable
  via `-webkit-app-region: drag`, with its buttons opted back out via `no-drag` so they
  stay clickable), with padding reserved so its own content doesn't sit under the native
  controls. `window.api.setTitleBarTheme(theme)` is called whenever the theme changes
  (Settings, or app startup using the last-saved theme) to keep the overlay in sync. On
  Mac, the native traffic-light buttons are kept as-is (`titleBarStyle: 'hiddenInset'`) —
  Apple doesn't expose a public API to recolor them, and native-colored traffic lights
  regardless of app theme is normal, expected behavior for Mac apps generally, not a bug.

## Fixed (follow-up): focus still got lost after recording, and typed text going missing

Two more real bugs found after further dogfooding:

- **Focus lost after recording, not just at startup.** The first focus fix only covered
  app *startup* (closing the splash screen). But the recorder launches a real, separate
  Chromium process — not an Electron window — so Electron has no automatic way of
  knowing when it closes and reclaiming focus for the main window. Fixed two ways:
  `electron/windowFocus.js` centralizes a more aggressive `forceFocus()` helper (adds a
  Windows-specific `setAlwaysOnTop(true)` → `setAlwaysOnTop(false)` toggle before
  `.focus()` — a known, widely-used workaround for this exact class of focus-stealing
  bug where plain `.focus()` alone gets silently ignored by the OS), and it's now called
  after the recorder session ends, whether stopped from our own "Stop & Review" button
  or by the user closing the recorded browser window directly. The startup path also
  got a fix: focus is now asserted *after* the splash window fully closes (previously it
  was asserted first, which could race with the splash window's closure stealing focus
  right back), with a short delay to let the OS finish processing that closure.
- **Typed text sometimes missing from a recorded spec** — root cause: text capture
  relied entirely on the browser's `change` event, which only fires when a field
  *blurs*. Typing into a field and then switching straight to this app's own window to
  click "Stop & Review" is a jump to a completely different OS window — that cross-window
  focus switch doesn't reliably fire `change` within the recorded page before the browser
  gets closed, silently dropping the text. Fixed in `electron/recorder.js`'s injected
  script: text entry is now captured via a *debounced* `input` listener (fires on every
  keystroke, committed as one `fill` step 600ms after typing stops) with three flush
  triggers layered on top for reliability — immediately on blur, immediately when
  switching to a different field, and forced immediately from `stopRecording()` itself
  (via `page.evaluate()`) right before the browser closes, catching the "typed something
  and immediately clicked Stop with zero pause" case with no debounce wait at all.
  Verified against exactly that scenario plus three related edge cases (natural pause,
  switching between two fields, and blur-triggered flush) directly.

## Fixed (second follow-up): focus still lost in many other places, and app hanging on Windows relaunch

- **Focus lost after using a native file/folder dialog — Import Spec, Import Collection,
  Export, picking a Test Data file, picking the report folder.** The earlier fixes
  covered app startup and the recorder's separate browser, but missed the much more
  common case: every native OS Open/Save dialog in the app hands focus away and none of
  them explicitly reclaimed it afterward. Since the *symptom* (a dead text field) only
  shows up whenever you next try to type — regardless of what you happen to be clicking
  at that moment — this looked like it was happening "in different places at different
  times," but the actual cause was always one of these six dialogs earlier in the
  session. Fixed by calling `forceFocus(win)` right after every
  `dialog.showOpenDialog`/`showSaveDialog` call resolves in `electron/ipcHandlers.js`,
  regardless of whether the user picked a file or cancelled.
- **Packaged Windows app hangs forever on relaunch ("keeps loading, never opens")** — a
  real, distinct bug, not a focus issue. Root cause: the app never called
  `app.requestSingleInstanceLock()`. If a previous process didn't fully terminate on
  close (a lingering child process — an in-progress test run, browser install, or
  recording session can keep the Node event loop alive even after the window closes),
  launching the app again spins up a genuinely separate second process that fights the
  first for Chromium's own internal singleton lock on the userData directory — which
  hangs rather than failing cleanly, exactly matching "keeps loading, never opens."
  Fixed in `electron/main.js`: `app.requestSingleInstanceLock()` now prevents a second
  process from ever fully starting (an attempted second launch just quits immediately
  and focuses the already-running window via the new `second-instance` handler
  instead), `before-quit` now stops any in-progress test run, browser install, or
  recording session so nothing lingers in the background in the first place, and — as a
  safety net for any *other* cause of a startup hang — the splash screen now has a 15s
  timeout that shows the main window anyway rather than leaving it spinning forever with
  no way out, plus `did-fail-load` logging so a genuine load failure isn't a total black
  box.

## Fixed: device emulation leaving blank space around the page, and a "Cancel" for new specs

- **Selecting a device (e.g. "Galaxy S9+") didn't visibly resize the browser, leaving a
  narrow mobile page surrounded by blank space** — the *page content* was actually
  emulating the device correctly the whole time (verified: Galaxy S9+ does resolve to
  its real 320×658 viewport internally), but Playwright doesn't resize the actual OS
  browser window to match a context's viewport by default in headed mode — it only
  constrains the content area via CDP, leaving the real window at whatever size it
  naturally opens at. `electron/configBuilder.js` now computes the effective viewport
  (a selected device's own viewport takes priority over the manual Width/Height fields,
  matching how the device-merge already applies it) and, in headed mode only, passes
  `--window-size=<w>,<h>` as a launch arg so the actual window matches what's being
  emulated — no more dead space. The Settings modal also now disables the manual
  Viewport fields while a device is selected (they were being silently ignored either
  way) and shows the device's real viewport dimensions, fetched live from Playwright's
  own device registry rather than guessed, so the UI doesn't display stale/misleading
  numbers.
- **"Cancel" for a spec with unsaved changes** — the spec editor's footer now shows a
  Cancel button whenever there are unsaved edits (including a brand-new, never-saved
  spec from "+ New Spec"). Clicking it asks for confirmation first; OK discards the
  changes — a new spec is cleared entirely back to the empty-selection state, an edited
  existing spec reverts to its last-saved version (using the copy already held in memory
  from the last load, no extra fetch needed) — Cancel on the confirmation leaves
  everything untouched.

## Conditional steps — run sub-steps based on a check, skip otherwise

A new `conditional` step type lets a spec branch: check something (a locator's
visibility/text/state, or a variable set by an earlier step), then run one set of
sub-steps if it's true, another (or nothing) if it's false. This is implemented as a
real recursive execution engine (`runner/stepRunner.js`), not a shallow one-level
special case — a conditional's branch can itself contain another conditional, nested as
deep as you want.

**Condition types:**
- Element state: `visible`, `hidden`, `exists`, `notExists`, `checked`, `unchecked`,
  `enabled`, `disabled` — checked against a locator (type + value, same locator kinds as
  every other step). None of these ever hang waiting for an element that never
  appears — they check immediately, so `notExists`/`hidden` work correctly as a way to
  detect *absence*, and a missing element for a text-reading check (`containsText`,
  `textEquals`, `checked`, `enabled`) is treated as the condition being `false` rather
  than crashing the test.
- Element text: `containsText`, `textEquals` — compared against the "Expected text"
  field, which supports `{{variables}}`.
- Variables (from anything set by `apiRequest`/`extractText`/`extractLocalStorage`/
  `setVariable`, or the spec's own Variables table / testData): `variableEquals`
  (compares to "Expected text/value") and `variableTruthy` (true unless empty string,
  `"0"`, `"false"`, or unset).

**The two branches** ("✓ IF TRUE" / "✗ IF FALSE") are fully visual, clickable, nested step
editors — same action dropdown, locator fields, and "+ Add step" as the main step table,
not a JSON box. `renderer/src/components/StepList.jsx` renders itself recursively: a
branch's own steps can include another `conditional`, which renders its own nested "IF
TRUE"/"IF FALSE" branches inside that row, to any depth. The FALSE branch is optional —
leave it empty to just skip when the condition doesn't hold, exactly matching "otherwise
can be skipped." Under the hood, a conditional step's `thenSteps`/`elseSteps` are stored
as real arrays of step objects (same shape as the spec's own top-level `steps`) —
`runner/stepRunner.js` also still accepts a JSON *string* for either field, for backward
compatibility with any spec saved under this feature's first iteration, which used a
JSON-text textarea before the fully visual editor replaced it.

## Full feature testing pass — real browser, real results

Ran 20 hand-written specs covering every action, every locator type, all 12 condition
types (including nesting), `apiRequest` with path/regex/path+regex extraction, testData
files, sessions, and screenshots — through the actual app pipeline
(`configBuilder.js` → `generic-runner.spec.js` → `stepRunner.js` → `actionRegistry.js`)
against a real Chromium browser and a local HTTP server (not mocked). One spec was a
**deliberate failure**, included specifically to prove pass/fail detection is trustworthy
rather than rubber-stamping everything.

**Result: 19/20 passed, and the 1 "failure" was the deliberate one** — it failed with
exactly the right expected/received mismatch. Every other bug found along the way turned
out to be a mistake in the test specs themselves (wrong action-name casing, a wrong
assertion expectation, a too-small test image, a bug in the *test server*, not the app) —
none were bugs in ETRO's actions, locators, conditionals, interpolation, or API/regex
logic.

**One genuine, valuable finding, since fixed:** Playwright's own `**`/`*` glob URL
matching turned out to be unreliable in the shipped Playwright version — confirmed by
tracing Playwright's actual source and empirically testing ~15 pattern variations, where
only exact strings and real `RegExp` objects matched reliably. Since JSON can't represent
a `RegExp` directly, this left no reliable way to do partial/pattern URL matching.
`assertUrl` and `waitForUrl` now have a **"Treat value as a regex pattern"** toggle in
their extra fields — off (default) does an exact-string match as before; on interprets
`value` as a regex source string (e.g. `nav=test$`) instead of relying on Playwright's
glob interpretation. Verified both modes directly against a real page, including the
exact string-vs-boolean edge case the UI's `<select>` produces (`'false'`/`'true'` as
strings, not JS booleans).

The 20 specs are included as `etro-full-feature-suite.etro-collection.json` — import it
via **Import Collection…** to see (and re-run against your own environment) exactly what
was tested. They point at a local test fixture page and a local mock API server that
aren't included (built ad hoc for this testing pass) — treat the specs as a reference for
DSL usage and coverage breadth, not as directly runnable out of the box; swap the
`baseUrl`/`apiRequest` URLs for real targets to actually run them.

## Fixed: the pervasive focus/typing bug — corrected diagnosis

An earlier fix pass reverted the app's frameless overlay title bar, hypothesizing it
was the root cause of a pervasive bug where typing in any field stopped working after
a modal closed, recoverable only by minimizing/restoring the app. **That hypothesis was
wrong** — the bug persisted even with a plain native frame, which disproved it. The
title bar theming has been **restored** (see below) since it was never the actual cause.

**The actual likely root cause: `windowFocus.js`'s `forceFocus()` was toggling
`setAlwaysOnTop(true)` → `setAlwaysOnTop(false)` on every dialog/modal close** (a
"known workaround" for Windows focus-stealing bugs), and also calling
`app.focus({ steal: true })` (a macOS-only option, meaningless on Windows, where this
bug was reported). Each fix pass that added more focus-reclaiming call sites — every
native dialog, every `window.confirm`/`alert`, the generic modal-close effect — made
this fire *more* often, which fits the observed pattern of the bug getting worse across
iterations rather than better. Repeatedly forcing window z-order changes in quick
succession (exactly the reported reproduction: open/close several modals in a row) is a
plausible way to confuse the Windows window manager's keyboard-focus-routing state,
while leaving mouse clicks (which don't require the same input-focus routing) still
working — consistent with buttons continuing to respond while typing broke.

`forceFocus()` has been stripped back to the minimum, standard, well-understood API:
just `win.focus()`. Nothing else. `electron-tests/windowFocus.test.js` has regression
guards asserting neither the `alwaysOnTop` toggle nor `app.focus({steal:true})` ever
come back.

**Title bar theming is restored** (`titleBarStyle: 'hidden'` + a themed
`titleBarOverlay` on Windows/Linux, native traffic lights on Mac) — now that the actual
cause has been identified and removed, there's no reason to keep the plain OS-default
title bar.

**Honesty about confidence:** this diagnosis fits the evidence well, but so did the
previous (wrong) one. It hasn't been confirmed by reproducing the bug end-to-end on a
real Windows machine — that's not possible from this environment. If it turns out to
still be wrong, the next step needs to be live DevTools inspection on the actual target
machine (checking `document.activeElement` and watching for console errors at the exact
moment typing stops working) rather than further remote guessing.

**`electron-tests/`** — a Node-level test suite (`node electron-tests/run-all.js`, no
real Electron runtime needed) exists specifically to keep all of this fixed going
forward. See `electron-tests/README.md` for the full breakdown of what's covered.

## Fixed: the actual root cause — native window.confirm()/window.alert() dialogs

The `setAlwaysOnTop` fix above did not fully resolve the bug. The user directly
diagnosed the real cause through their own comparative testing: `PromptModal` (a pure
React modal — "New Collection") could be opened and closed repeatedly with no focus
issue whatsoever, while every native `window.confirm()`/`window.alert()` dialog (used
for delete confirmations, discard-changes prompts, import/export notifications, "no
saved specs" warnings) reliably broke typing afterward. That comparison is much
stronger evidence than anything remote debugging could have produced — native
Chromium-blocking dialogs have a well-documented class of Electron focus-return
problems that a post-hoc `reclaimFocus()` call (the earlier attempted fix) couldn't
reliably paper over.

**The fix: `window.confirm()`/`window.alert()` are no longer called anywhere in the
app.** `renderer/src/components/ConfirmModal.jsx` is a plain React modal replacing
both — reusing the same `.modal`/`.modal-footer` styling as every other modal in the
app. Since a React modal can't return a value synchronously the way `window.confirm()`
does, `App.jsx`'s `confirmDialog()`/`alertDialog()` wrappers now return a `Promise`
that resolves once the user clicks a button, and every call site (`handleDeleteSpec`,
`handleDeleteCollection`, `confirmDiscardIfDirty`, every import/export notification,
etc.) awaits it.

**Per explicit requirement, `ConfirmModal` does not close on backdrop click or
Escape** — unlike every other modal in the app, which do close that way. This is
intentional: for a destructive confirmation ("Delete this collection?"), accidentally
dismissing it via a stray click or Escape press should not silently proceed as if
declined (or ambiguously as if confirmed) — an explicit button click is required
either way.

`electron-tests/confirmAlertFocus.test.js` was rewritten accordingly: it now asserts
`window.confirm`/`window.alert` are never called anywhere in `App.jsx`, that
`confirmDialog`/`alertDialog` return real Promises, and that `ConfirmModal` itself has
no backdrop-click or Escape handling wired up — regression guards directly encoding
this fix.

## Fixed: a bogus second Firefox window (URL "http://1280,720/") in headed runs

The earlier fix for headed-mode browser windows not matching the emulated viewport
(see "device emulation leaving blank space" above) added a `--window-size=W,H` launch
argument — that's Chromium's own CLI syntax. It was applied globally, via the
config's top-level `use.launchOptions`, which Playwright merges into *every* selected
browser project — including Firefox and WebKit, which don't understand it. Firefox's
argument parser doesn't recognize `--window-size` and, per its own CLI handling of an
unrecognized value, can treat it like a URL-bar address — defaulting to the `http://`
scheme and opening it in a new window. That's exactly the reported symptom: a second
window with the URL `http://1280,720/` alongside the real, correctly-controlled one.

`electron/configBuilder.js` now builds `launchOptions` **per project** instead of
globally, with browser-specific sizing syntax:
- **Chromium**: `--window-size=W,H` (unchanged from before, still correct).
- **Firefox**: `-width W -height H` — two separate arguments, matching
  [Mozilla's own documented CLI flags](https://developer.mozilla.org/en-US/docs/Mozilla/Command_Line_Options),
  not Chromium's `=`-joined syntax.
- **WebKit**: deliberately no custom sizing args at all. This project has no real
  WebKit binary available to verify safe CLI flag behavior against, and guessing wrong
  risks repeating exactly this class of bug for a third browser — headed WebKit runs
  keep the pre-existing (imperfect but harmless) extra-blank-space appearance instead
  of a potentially broken guessed fix.

Verified directly: generated a real config for all three browsers together (each gets
its own correct — or absent — `launchOptions`), for headless mode (no `launchOptions`
on any browser, since window sizing is irrelevant there), for Firefox combined with a
mobile device emulation (correctly resolves to that device's viewport), and confirmed
the unrelated `PWD_BROWSER_EXECUTABLE_PATH` CI override still flows through correctly
alongside the per-browser args.

## Fixed (follow-up): Firefox's own documented flags *also* caused a bogus window

The fix above gave Firefox Mozilla's own documented `-width`/`-height` flags instead of
Chromium's syntax — correct on paper, confirmed via the actual generated config in a
real user's run (`launchOptions.args: ["-width","1280","-height","720"]`, exactly
right, no bug in the generation logic). It **still** caused a second window to open, at
a different garbled URL (`https://0.0.5.0/`) with no relationship to the real
1280×720 viewport being configured. Since this project has no real Firefox binary
available (only Chromium — see "Full feature testing pass" above) to test Playwright's
specific patched, Juggler-protocol Firefox build's actual CLI argument handling
against, and documentation has now proven an unreliable guide to it twice, **Firefox
gets no custom sizing args at all anymore** — the same treatment as WebKit, for the
same underlying reason. The cost is purely cosmetic (extra blank space around a
non-default-sized viewport in headed Firefox runs); the alternative was an actively
disruptive bogus window on every run. `electron-tests/configBuilder.test.js` was
updated accordingly — it now asserts Firefox gets no `launchOptions` at all, and the
device-viewport-resolution test (still a real thing worth covering) moved to Chromium,
the only remaining browser where a device's viewport visibly affects the generated
launch args.

## Six new features

1. **Disable a step** — each step in the editor has a ⏸/▶ toggle button. A disabled step
   is grayed out, its fields become read-only, and at runtime (`runner/stepRunner.js`)
   it's skipped entirely rather than executed — still shown in the log/report as
   `(disabled — skipped)` so it's visible it was intentionally bypassed, not silently
   missing. Works for conditional steps too — a disabled `conditional` skips without
   ever evaluating its condition or running either branch.
2. **Insert a step after any step** — a "+" button next to each step's move/delete
   buttons inserts a new empty step immediately after that one, shifting everything
   after it down (step 2's "+" on a 3-step spec makes a new step 3, and the old step 3
   becomes step 4). The existing bottom "+ Add step" button (always appends to the end)
   is unchanged and still there too.
3. **Per-spec timeout override** — a "Spec timeout (ms)" field in the editor's header.
   When set, it overrides the global Settings timeout for that spec only. Implemented
   with `test.setTimeout(ms)`, Playwright's actual documented API for this — worth
   flagging that an earlier attempt assumed `test(title, {timeout}, fn)` was valid
   syntax; checking the actual installed Playwright type definitions before shipping
   caught that this Playwright version's `TestDetails` type only supports
   `tag`/`annotation`, not `timeout`, avoiding a repeat of the Firefox-flags mistake.
4. **Better video quality** — Playwright's own documented default behavior is to
   downscale recorded video to fit within 800×800 unless an explicit `size` is given.
   `configBuilder.js` now always passes `video: { mode, size: <effective viewport> }`
   instead of just a mode string, preserving the actual configured (or device-emulated)
   resolution instead of a silent downscale.
5. **Recorder shows progress while converting to steps** — clicking "Stop & Review" now
   disables the button and shows a spinner with "Converting recording to steps…" for the
   duration of the `stopRecording()` call (which closes the recorded browser and returns
   the captured steps), instead of the button appearing to do nothing during that gap.
6. **Headed mode opens maximized by default** — with an opt-out. Previously headed runs
   used a fixed viewport sized via `--window-size` regardless of your actual screen size.
   Now, headed + no device selected + the new Settings → Viewport → "Use a custom
   viewport instead of maximized" checkbox left unchecked (the default) opens the
   browser maximized instead — Chromium via the standard `--start-maximized` flag,
   combined with Playwright's documented `viewport: null` (which makes the page's
   content area depend on the actual host window size rather than a fixed Playwright
   preset). Checking that box falls back to the previous fixed-viewport behavior.
   **Device emulation is always unaffected regardless of the checkbox** — maximizing
   would defeat the point of emulating a specific device's screen size. Since there's no
   way to know a maximized window's exact size ahead of time, video recording in
   maximized mode uses the actual detected primary display size instead (via Electron's
   `screen.getPrimaryDisplay().workAreaSize`, queried in `testRunner.js` and threaded
   through to `configBuilder.js`), falling back to a sane 1920×1080 default if no
   display is available to query. Firefox/WebKit are unaffected by this feature the same
   way they're unaffected by the custom-viewport `--window-size` flag — no real binary
   available to verify a safe maximize-equivalent flag against, so they keep opening at
   their own natural default size rather than risk guessing wrong a third time.

All six were verified directly rather than just written and assumed correct: the
disable/skip logic and insert-after-step logic were tested with real step-list
execution and array manipulation; the timeout override was tested against 5 input
edge cases (valid, missing, empty string, zero, string-typed number) after first
verifying the actual Playwright API surface in the installed package's own type
definitions; the video sizing was verified against 4 scenarios including device
emulation; and the maximized-mode logic was verified against 7 scenarios (default
maximized, override checked, device selected, headless, Firefox, video sizing with
and without a detected screen size) — all now permanent regression tests in
`electron-tests/configBuilder.test.js`.

## Three follow-up fixes

1. **Step action button spacing** — the disable/move/insert/delete buttons on each step
   row were sitting directly adjacent with barely any visual separation. Given proper
   flex spacing (`.step-actions`, 6px gap) and slightly more comfortable padding.
2. **Recorder locator quality** — the recorder previously fell back to a CSS selector
   for most elements in practice, since its old priority chain only handled testid, an
   element's own `id`, `aria-label`, and button/link text before giving up. Rebuilt the
   whole priority chain to follow Playwright's own documented best practices: test
   hooks → role + accessible name (covering buttons, links, checkboxes, radios,
   textboxes, comboboxes, headings, images) → aria-label → associated `<label>` →
   placeholder → visible text → alt text → title → a *stable-looking* id → the `name`
   attribute → a smarter CSS fallback as an absolute last resort. Specifically avoids
   auto-generated ids and CSS-in-JS class names (Radix UI, React Aria, Ember, MUI,
   emotion/styled-components patterns, UUIDs, hash-like blobs) via heuristic pattern
   matching, since those look plausible but change on every rebuild. Verified against a
   real browser with 13 realistic scenarios covering every priority tier — this also
   caught and fixed two real bugs found only through that real-browser testing: a
   `<select>`'s currently-chosen option and a checkbox's default `value="on"` were both
   being picked up as if they were the element's accessible *name*, which is wrong and
   unstable (neither is fixed — they change with user interaction or default state).
3. **First-match-by-default for locators matching multiple elements** — this was
   already correctly implemented (`runner/locatorResolver.js`'s `resolveLocator`
   defaults to `.first()`, with `assertCount` alone opting out via `{ first: false }`
   since it specifically needs the true count) — verified end-to-end against a real
   browser with three genuinely matching elements: a `click` on a multi-match locator
   now correctly clicks the first one without throwing, while `assertCount` still
   correctly reports the true count of all three rather than being capped at one.

## Help & Documentation modal

A **Help** button (toolbar, next to About) opens a three-tab modal:

- **Features** — every feature the app provides, grouped and point-by-point (authoring,
  data-driven testing, recording, running, organizing/sharing).
- **How to Use** — a full usage guide: quick start, every one of the 9 locator types
  with a real example each, every one of the 30+ actions grouped by category with a
  real example each, variables/data-driven testing, step management, running & reports,
  every Settings section explained, and import/export/sessions. Collapsible sections
  keep it navigable rather than one long scroll.
- **Limitations** — what isn't supported yet, organized by area (recording, browser
  support nuances, data/security, testing capabilities, operational) — written plainly
  rather than glossed over, including specifically calling out the Firefox window-sizing
  decision and why it was made.

The locator and action lists in the How to Use tab are driven directly from
`renderer/src/actionMeta.js` (the same data the step editor's own dropdowns use) rather
than a separately hand-maintained list, so they can't silently drift out of sync with
the app as actions are added or changed later — only the descriptions/examples are
hand-written, keyed by action/locator name.

Verified by actually rendering the component in a real browser (not just reading the
JSX and assuming it looks right) — screenshotted all three tabs, a collapsed and an
expanded How to Use section, and both the default-dark and light themes, catching and
fixing a real bug in the process: the first render attempt had no visible modal card,
wrong font, and looked broken, traced to the test harness's stylesheet link using an
absolute filesystem path instead of a proper served URL. Confirmed zero JavaScript
console/page errors in the actual rendered output.

## Accessibility testing

Every spec can run an accessibility scan, configured via the **♿ Accessibility Testing**
button in the spec header. Uses `@axe-core/playwright` — the same axe-core engine behind
most browser accessibility devtools — verified against its actual installed type
definitions and real WCAG tag list rather than assumed from memory, after earlier
mistakes this conversation made assuming API shapes turned out wrong (Firefox launch
flags, a Playwright `test()` options argument that didn't exist in this version).

**Configuration**, saved directly into the spec's own JSON (`spec.accessibility`) — no
separate storage:
- **Only scan these elements** — CSS selectors to scope the scan to; empty scans the
  whole page.
- **Exclude these elements** — CSS selectors to skip regardless of the above.
- **Rules** — WCAG conformance level tags (2.0/2.1/2.2, A/AA/AAA) plus best practices;
  none ticked runs axe's full default rule set.
- **Fail this test if violations are found** — on by default; turning it off still
  reports and attaches results without failing the run.

**Execution**: runs once, after all of a spec's normal steps complete, scanning
whatever the page looks like at that point — the simplest, most predictable design,
though it does mean there's no way to scan at multiple points within one spec (see
Limitations). Wrapped in its own `test.step('Accessibility scan', ...)`, so it appears
in the live run log the same way a normal step does, not just in the report afterward.

**Reporting**: results attach to that same test's entry in the standard Playwright HTML
report — a full `accessibility-scan-full.json` and a human-readable
`accessibility-summary.txt`, exactly as requested rather than a separate report.

**Verified with real execution, not just written and assumed correct**: hit a real
constraint early on (`AxeBuilder` needs a page from a properly-created context — a raw
`browser.newPage()` shortcut fails with a clear error) and confirmed it's a non-issue
for the real integration, since Playwright Test's own `page` fixture (what
`generic-runner.spec.js` actually uses) works fine. Ran real spec files with genuine
accessibility violations through the actual `configBuilder.js` → Playwright CLI
pipeline with a real Chromium: confirmed violations are detected, `failOnViolations:
false` doesn't fail the test, `includeSelectors` correctly scopes the scan away from a
violating element outside it, and `tags` filtering narrows the violation count rather
than reporting everything. These are now permanent, checked-in regression tests in
`runner-tests/accessibility.test.js` (a new test area distinct from `electron-tests/`,
since this needs a real browser rather than a mockable Electron surface — see
`runner-tests/README.md`). The modal UI itself was also rendered and screenshotted
standalone in a real browser (enabled, disabled, and selector-list-editing states)
before being wired in, confirming no JS errors and that saving produces the exact
expected config shape.

`@axe-core/playwright` and `axe-core` were added to `asarUnpack` in the packaging
config defensively — they're pure JavaScript with no native binaries, so Electron's
asar `fs` patching should handle them transparently either way, but a packaged build
can't be tested from this environment, so this removes that as a variable rather than
assume it's fine.

## Accessibility testing follow-up: two real, user-identified problems fixed

**1. Timing — the spec-level scan can miss transient elements.** Correctly pointed out:
in a single-page app, an element (a modal, a toast) can be shown and gone entirely
within a few steps, and a scan that only ever runs after *all* steps finish can never
catch it. There's no way to fix this by adjusting the end-of-run scan — the real fix is
letting the scan run at a chosen point in the sequence instead. Added a new insertable
**"Accessibility Scan" step** (`runner/stepRunner.js`, special-cased the same way
`conditional` already is) with the same include/exclude/tags/fail-on-violations options,
placeable anywhere and usable more than once per spec. Verified end-to-end against a
genuinely transient element (a modal shown by a click, auto-removed a few seconds
later) — the step-based scan, inserted right after the revealing click, caught a real
violation on it that a spec-level scan would have completely missed by construction.
Honest caveat, discovered while verifying this and documented directly in the UI: the
scan's own script-injection takes a moment, so it still won't reliably catch something
that disappears within roughly a second of the step running.

**2. HTML report format, and a real video-duplication bug found while implementing it.**
Switched the human-readable attachment from plain text to a styled, self-contained HTML
report (`accessibility-report.html`, alongside the full raw JSON). While verifying this
didn't interact badly with video recording (a concern raised directly, not assumed
unfounded), found a genuine bug: `@axe-core/playwright`'s default (non-legacy) `analyze()`
opens an extra internal "blank page" in the same browser context to assemble results —
and since Playwright's video recording is scoped to the whole context, that extra page
got its own separate video file recorded and attached. Confirmed directly: `video.webm`
*and* `video-1.webm` both showed up for one test with accessibility scanning and video
capture both enabled. Fixed via `AxeBuilder.setLegacyMode(true)`, which runs axe-core
directly against the real page with no extra page created — verified this produces
exactly one video attachment afterward, with identical violation-detection accuracy.
Legacy mode's tradeoff is weaker handling of complex cross-origin iframe scanning, an
edge case most specs won't hit; avoiding duplicate videos on every accessibility-enabled
run matters more.

Both fixes are now permanent regression tests in `runner-tests/accessibility.test.js`
(7 tests total, all passing) — the video-duplication guard specifically asserts exactly
one `video (video/webm)` attachment appears in a real run's output, and the timing fix
is verified against the same real transient-element scenario described above, not just
asserted in the abstract.

