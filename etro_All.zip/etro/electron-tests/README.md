# Electron main-process tests

Node-level tests for `electron/*.js` — no real Electron runtime, display, or window
manager needed. Run the whole suite with:

```bash
node electron-tests/run-all.js
```

`mockElectron.js` installs a fake `electron` module into Node's require cache
(intercepting `require('electron')` project-wide via `Module._resolveFilename`), so
`main.js`, `ipcHandlers.js`, and `windowFocus.js` can be required and exercised exactly
as they run in production. `testHarness.js` is a small, dependency-free
suite/test/assert runner (no Jest/Mocha needed).

**Why this exists:** several real regressions in this app — a missing
`app.requestSingleInstanceLock()` causing Windows relaunch hangs, native dialogs not
reclaiming focus afterward, and (the actual main one) `window.confirm`/`window.alert`
having a class of Electron focus-return bug that a themed frameless title bar was
initially (and incorrectly) suspected of causing — were each found through manual
testing during development, then fixed. (The frameless title bar was reverted, then
restored once proven unrelated — see the main README's "Fixed: the pervasive
focus/typing bug" sections for the full story of that misdiagnosis and correction.)
This suite encodes the actual fixes as permanent regression
guards, so if any of them quietly comes back in a future edit, a test fails loudly
instead of the bug just reappearing.

## Test files

- **`main.lifecycle.test.js`** — single-instance lock (both the success and failure
  paths), the `second-instance`/`before-quit`/`window-all-closed` app-level listeners
  that make the lock and cleanup-on-quit actually work, title bar theming
  (`titleBarStyle`/`titleBarOverlay` on non-Mac windows, correctly colored per the
  active theme), and that the app opens maximized by default (`maximize()` called
  before `show()`, while the window is still hidden, so there's no visible resize jump).
- **`ipcHandlers.focus.test.js`** — every native file-dialog call site (`testdata:pick`,
  `specs:export`, `specs:import`, `collections:export`, `collections:import`,
  `dialog:pickReportDir`) reclaims focus afterward, even when the dialog is cancelled;
  `window:reclaimFocus` and a post-recording `recorder:stop` also reclaim focus.
- **`confirmAlertFocus.test.js`** — asserts `window.confirm`/`window.alert` are never
  called anywhere in `App.jsx` (the actual fix for the reported focus/typing bug —
  replaced entirely by `ConfirmModal.jsx`, a plain React modal), that
  `confirmDialog`/`alertDialog` return real Promises (since a React modal can't return
  a value synchronously the way `window.confirm()` does) with every call site awaiting
  them, and that `ConfirmModal` itself has no backdrop-click or Escape-to-close handling
  (an explicit requirement — accidentally dismissing a destructive confirmation like
  "Delete this collection?" should never happen).
- **`windowFocus.test.js`** — `forceFocus()` calls `win.focus()` and nothing else, with
  regression guards asserting neither the `setAlwaysOnTop` toggle nor
  `app.focus({steal:true})` (both suspected, and removed, as an actual cause of the
  bug getting *worse* across earlier fix iterations) ever come back.
- **`configBuilder.test.js`** — headed-mode window-sizing launch args are correctly
  scoped per browser (Chromium's `--window-size=W,H`, Firefox's `-width W -height H`,
  WebKit gets none) rather than applied globally to every selected browser regardless
  of whether it understands the flag — a regression guard against a real reported bug
  where the Chromium-only flag, applied to Firefox too, caused Firefox to open a bogus
  second window at the URL `http://1280,720/`. Also covers headless mode having no
  launchOptions at all, device emulation resolving the correct viewport for sizing, and
  the `PWD_BROWSER_EXECUTABLE_PATH` CI override still working alongside the args.

## Not covered here at all

The runner package (`runner/*.js`) and renderer components — those were verified
extensively via direct execution against a real Playwright browser (see the main
README's "Full feature testing pass" section) rather than as a checked-in automated
suite. Extending this suite to cover those too would be a reasonable next step.
