const fs = require('fs');
const path = require('path');
const { suite, test, assertTrue, assertFalse, assertEqual } = require('./testHarness');
const { writeConfig } = require('../electron/configBuilder');

function buildAndLoad(settings, label, maximizedSize) {
  const configPath = path.resolve(__dirname, `.tmp-configBuilder-${label}.js`);
  writeConfig({ settings, reportDir: '/tmp/electron-tests-reportdir', configPath, maximizedSize });
  delete require.cache[configPath];
  const cfg = require(configPath);
  fs.unlinkSync(configPath);
  return cfg;
}

const baseViewport = { width: 1280, height: 720 };
const baseSettings = {
  browsers: ['chromium', 'firefox', 'webkit'],
  viewport: baseViewport,
  screenshot: 'off',
  stepScreenshots: 'off',
  video: 'off',
  trace: 'off',
  timeoutMs: 30000,
  retries: 0,
  workers: 1,
};

suite('configBuilder: REGRESSION GUARD — browser-specific window-size args, headed mode with custom viewport', () => {
  // overrideMaximizedViewport:true opts into the "use my configured
  // Width/Height" path — headed mode defaults to maximized otherwise (see
  // the "maximized by default" suite below), which is a separate thing
  // this suite isn't testing.
  const cfg = buildAndLoad(
    { ...baseSettings, headless: false, overrideMaximizedViewport: true },
    'headed-all-browsers'
  );
  const byName = Object.fromEntries(cfg.projects.map((p) => [p.name, p.use]));

  test('chromium gets Chromium-syntax --window-size', () => {
    assertTrue(Array.isArray(byName.chromium.launchOptions?.args), 'expected chromium launchOptions.args');
    assertTrue(
      byName.chromium.launchOptions.args.includes('--window-size=1280,720'),
      'expected --window-size=1280,720 in chromium args'
    );
  });

  test('firefox gets NO custom launch args at all (two separate attempts at sizing its window via CLI flags both proved broken — see the doc comment on windowSizeArgsFor in configBuilder.js)', () => {
    // Attempt 1: Chromium's own --window-size=W,H syntax, applied globally —
    // Firefox's parser didn't recognize it and opened a bogus window at
    // "http://1280,720/". Attempt 2: Mozilla's own documented -width/-height
    // flags, applied Firefox-specifically — STILL produced a bogus window,
    // this time at "https://0.0.5.0/" with a real 1280x720 headed Firefox
    // run. With no real Firefox binary available to verify CLI behavior
    // against directly, guessing a third time isn't worth the risk — Firefox
    // gets no custom sizing args at all now, same treatment as WebKit.
    assertTrue(byName.firefox.launchOptions === undefined, 'firefox should have no launchOptions — no custom args of any kind');
  });

  test('webkit gets no custom sizing args at all (no real WebKit binary to verify safe flags against)', () => {
    assertTrue(byName.webkit.launchOptions === undefined, 'webkit should have no launchOptions in this scenario');
  });
});

suite('configBuilder: headed mode opens maximized by default (new feature)', () => {
  test('headed + no device + override unchecked -> viewport:null, chromium gets --start-maximized', () => {
    const cfg = buildAndLoad(
      { ...baseSettings, browsers: ['chromium'], headless: false, overrideMaximizedViewport: false },
      'maximized-default'
    );
    assertEqual(cfg.use.viewport, null, 'viewport should be null so the page fills the actual maximized window');
    assertTrue(
      cfg.projects[0].use.launchOptions.args.includes('--start-maximized'),
      'expected the standard Chromium --start-maximized flag'
    );
    assertFalse(
      cfg.projects[0].use.launchOptions.args.some((a) => a.startsWith('--window-size')),
      'should NOT also pass --window-size when maximized'
    );
  });

  test('headed + no device + override CHECKED -> falls back to the configured viewport, --window-size', () => {
    const cfg = buildAndLoad(
      { ...baseSettings, browsers: ['chromium'], headless: false, overrideMaximizedViewport: true },
      'maximized-override-checked'
    );
    assertEqual(cfg.use.viewport, { width: 1280, height: 720 });
    assertTrue(cfg.projects[0].use.launchOptions.args.includes('--window-size=1280,720'));
  });

  test('device selected -> maximize NEVER applies, regardless of the override checkbox (device emulation always keeps its own viewport)', () => {
    const cfg = buildAndLoad(
      { ...baseSettings, browsers: ['chromium'], headless: false, device: 'Galaxy S9+', overrideMaximizedViewport: false },
      'maximized-with-device'
    );
    assertTrue(cfg.use.viewport !== null, 'viewport should NOT be null when a device is selected');
    assertTrue(cfg.projects[0].use.launchOptions.args.includes('--window-size=320,658'), 'should size to the device viewport, not maximize');
  });

  test('headless mode -> maximize logic never applies (no visible window to maximize)', () => {
    const cfg = buildAndLoad(
      { ...baseSettings, browsers: ['chromium'], headless: true, overrideMaximizedViewport: false },
      'maximized-headless'
    );
    assertTrue(cfg.use.viewport !== null, 'viewport should not be null in headless mode');
    assertTrue(cfg.projects[0].use.launchOptions === undefined, 'headless mode should have no launchOptions at all');
  });

  test('firefox is unaffected by maximize mode (still gets no custom args either way)', () => {
    const cfg = buildAndLoad(
      { ...baseSettings, browsers: ['firefox'], headless: false, overrideMaximizedViewport: false },
      'maximized-firefox'
    );
    assertEqual(cfg.use.viewport, null, 'the global viewport:null still applies even though firefox gets no launch args');
    assertTrue(cfg.projects[0].use.launchOptions === undefined, 'firefox should still have no custom launchOptions in maximized mode');
  });

  test('video gets an explicit size even when viewport is null, using the detected screen size', () => {
    const cfg = buildAndLoad(
      { ...baseSettings, browsers: ['chromium'], headless: false, video: 'on', overrideMaximizedViewport: false },
      'maximized-video-with-screen-size',
      { width: 1920, height: 1040 }
    );
    assertEqual(cfg.use.video, { mode: 'on', size: { width: 1920, height: 1040 } });
  });

  test('video falls back to a sane default size if no screen size was detected (e.g. no display available)', () => {
    const cfg = buildAndLoad(
      { ...baseSettings, browsers: ['chromium'], headless: false, video: 'on', overrideMaximizedViewport: false },
      'maximized-video-no-screen-size'
      // no maximizedSize passed
    );
    assertEqual(cfg.use.video, { mode: 'on', size: { width: 1920, height: 1080 } });
  });
});

suite('configBuilder: headless mode never sets launchOptions on any browser', () => {
  const cfg = buildAndLoad({ ...baseSettings, headless: true }, 'headless-all-browsers');
  test('no project has launchOptions when headless', () => {
    for (const p of cfg.projects) {
      assertTrue(p.use.launchOptions === undefined, `${p.name} should have no launchOptions in headless mode`);
    }
  });
});

suite('configBuilder: device emulation still resolves the correct viewport for window sizing', () => {
  const cfg = buildAndLoad(
    { ...baseSettings, browsers: ['chromium'], headless: false, device: 'Galaxy S9+' },
    'chromium-device'
  );
  test('chromium window-size arg matches the device viewport, not the manual settings.viewport', () => {
    // Firefox no longer gets custom sizing args at all (see the suite above),
    // so this is verified against chromium — the only browser where a
    // device's viewport still visibly affects the generated launch args.
    const args = cfg.projects[0].use.launchOptions.args;
    assertTrue(args.includes('--window-size=320,658'), 'expected Galaxy S9+ viewport (320x658), not the manual 1280x720 setting');
  });
});

suite('configBuilder: PWD_BROWSER_EXECUTABLE_PATH override still works alongside per-browser args', () => {
  test('executablePath is present together with the browser-specific args', () => {
    process.env.PWD_BROWSER_EXECUTABLE_PATH = '/fake/path/to/chrome';
    const cfg = buildAndLoad(
      { ...baseSettings, browsers: ['chromium'], headless: false, overrideMaximizedViewport: true },
      'executable-override'
    );
    delete process.env.PWD_BROWSER_EXECUTABLE_PATH;

    const launchOptions = cfg.projects[0].use.launchOptions;
    assertEqual(launchOptions.executablePath, '/fake/path/to/chrome');
    assertTrue(launchOptions.args.includes('--window-size=1280,720'), 'args should still be present alongside executablePath');
  });

  test('executablePath also works alongside --start-maximized in the default (non-override) maximized mode', () => {
    process.env.PWD_BROWSER_EXECUTABLE_PATH = '/fake/path/to/chrome';
    const cfg = buildAndLoad(
      { ...baseSettings, browsers: ['chromium'], headless: false, overrideMaximizedViewport: false },
      'executable-override-maximized'
    );
    delete process.env.PWD_BROWSER_EXECUTABLE_PATH;

    const launchOptions = cfg.projects[0].use.launchOptions;
    assertEqual(launchOptions.executablePath, '/fake/path/to/chrome');
    assertTrue(launchOptions.args.includes('--start-maximized'), 'args should still be present alongside executablePath');
  });
});
