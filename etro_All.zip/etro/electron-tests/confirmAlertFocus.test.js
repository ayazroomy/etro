const fs = require('fs');
const path = require('path');
const { suite, test, assertTrue, assertFalse } = require('./testHarness');

// This can't render real React/DOM in this environment, so it verifies the
// fix at the source level instead. The original fix (confirmDialog/alertDialog
// wrapping window.confirm/window.alert with a reclaimFocus() call after) did
// not fully resolve the reported bug — native Chromium-blocking dialogs
// turned out to have a deeper class of Electron focus-return problem that a
// post-hoc reclaimFocus() call couldn't reliably paper over. The actual fix:
// window.confirm/window.alert are no longer used AT ALL — replaced entirely
// with a pure React modal (ConfirmModal), verified by direct comparison
// against PromptModal (which never showed the focus bug across repeated
// open/close cycles, unlike the native dialogs) not to need any special
// focus-reclaiming treatment.
suite('App.jsx: window.confirm/window.alert are never called, anywhere', () => {
  const appPath = path.join(__dirname, '..', 'renderer', 'src', 'App.jsx');
  const source = fs.readFileSync(appPath, 'utf-8');
  // Comments legitimately mention window.confirm()/window.alert() as
  // concepts (explaining why they're avoided) — strip comment lines first so
  // those don't get mistaken for real call sites.
  const withoutComments = source
    .split('\n')
    .filter((line) => !line.trim().startsWith('//'))
    .join('\n');

  test('no line anywhere in App.jsx calls window.confirm(...)', () => {
    assertFalse(/window\.confirm\(/.test(withoutComments), 'window.confirm() should never be called — see ConfirmModal.jsx');
  });

  test('no line anywhere in App.jsx calls window.alert(...)', () => {
    assertFalse(/window\.alert\(/.test(withoutComments), 'window.alert() should never be called — see ConfirmModal.jsx');
  });

  test('confirmDialog/alertDialog are defined and return Promises (driving the React ConfirmModal, not a native dialog)', () => {
    assertTrue(/function confirmDialog\(/.test(source), 'confirmDialog should be defined');
    assertTrue(/function alertDialog\(/.test(source), 'alertDialog should be defined');
    const confirmFn = source.match(/function confirmDialog\([^)]*\)\s*{([^]*?)\n  }/);
    const alertFn = source.match(/function alertDialog\([^)]*\)\s*{([^]*?)\n  }/);
    assertTrue(!!confirmFn && /new Promise\(/.test(confirmFn[1]), 'confirmDialog should return a Promise (async, matching how a React modal resolves)');
    assertTrue(!!alertFn && /new Promise\(/.test(alertFn[1]), 'alertDialog should return a Promise');
  });

  test('ConfirmModal is imported and rendered, driven by confirmState', () => {
    assertTrue(/import ConfirmModal from '\.\/components\/ConfirmModal\.jsx'/.test(source));
    assertTrue(/confirmState &&/.test(source), 'ConfirmModal should be conditionally rendered from confirmState');
  });

  test('every confirmation/notification call site is awaited (spot-check known call sites)', () => {
    const expectedCallSites = [
      /await confirmDialog\(\s*['"`]Discard your unsaved changes/, // Cancel / new spec / etc.
      /await confirmDialog\(`Delete "/, // delete spec
      /await confirmDialog\('Delete this collection/, // delete collection
      /await alertDialog\(`Exported to/, // export spec notification
      /await alertDialog\(`Imported \$\{imported\.length\}/, // multi-import notification
    ];
    for (const re of expectedCallSites) {
      assertTrue(re.test(source), `expected to find an awaited call site matching ${re}`);
    }
  });
});

suite('ConfirmModal.jsx: does not close on backdrop click or Escape', () => {
  const modalPath = path.join(__dirname, '..', 'renderer', 'src', 'components', 'ConfirmModal.jsx');
  const source = fs.readFileSync(modalPath, 'utf-8');

  test('the modal-backdrop div has no onClick handler (clicking outside does nothing)', () => {
    // The backdrop div itself should not wire an onClick that closes the
    // modal — only the explicit OK/Cancel buttons should be able to close it.
    const backdropMatch = source.match(/<div className="modal-backdrop"([^>]*)>/);
    assertTrue(!!backdropMatch, 'expected to find the modal-backdrop element');
    assertFalse(/onClick/.test(backdropMatch[1]), 'modal-backdrop should not have an onClick handler');
  });

  test('no keydown/Escape handling is wired anywhere in the component', () => {
    const withoutComments = source
      .split('\n')
      .filter((line) => !line.trim().startsWith('//') && !line.trim().startsWith('*'))
      .join('\n');
    assertFalse(/onKeyDown|['"`]Escape['"`]/.test(withoutComments), 'ConfirmModal should not close on Escape');
  });
});

suite('preload.js: reclaimFocus is still exposed (used for the remaining native file dialogs)', () => {
  const preloadPath = path.join(__dirname, '..', 'electron', 'preload.js');
  const source = fs.readFileSync(preloadPath, 'utf-8');

  test('reclaimFocus is exposed via contextBridge', () => {
    assertTrue(/reclaimFocus:\s*\(\)\s*=>\s*ipcRenderer\.invoke\('window:reclaimFocus'\)/.test(source));
  });
});
