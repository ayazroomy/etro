const { installMockElectron } = require('./mockElectron');
const { suite, test, assertContains, assertTrue } = require('./testHarness');

const DIALOG_CHANNELS = [
  'testdata:pick',
  'specs:export',
  'specs:import',
  'collections:export',
  'collections:import',
  'dialog:pickReportDir',
];

function freshIpcHandlers(mockOverrides) {
  const mock = installMockElectron(mockOverrides);
  for (const modPath of [
    '../electron/ipcHandlers.js',
    '../electron/dataStore.js',
    '../electron/windowFocus.js',
    '../electron/testRunner.js',
    '../electron/recorder.js',
    '../electron/browserInstaller.js',
    '../electron/updater.js',
    '../electron/themeColors.js',
    '../runner/sessionStore.js',
  ]) {
    try {
      delete require.cache[require.resolve(modPath)];
    } catch (err) {
      // fine if not previously required
    }
  }
  const { registerIpcHandlers } = require('../electron/ipcHandlers.js');
  const win = mock.makeWindow();
  registerIpcHandlers(() => win);
  return { mock, win };
}

suite('ipcHandlers: every native dialog reclaims focus afterward', () => {
  for (const channel of DIALOG_CHANNELS) {
    test(`${channel} calls forceFocus (win.focus + app.focus) after the dialog closes, even when cancelled`, async () => {
      const { mock } = freshIpcHandlers({
        showOpenDialog: async () => ({ canceled: true, filePaths: [] }),
        showSaveDialog: async () => ({ canceled: true }),
      });

      const handler = mock.registeredHandlers[channel];
      assertTrue(typeof handler === 'function', `${channel} handler should be registered`);

      // Each channel needs an argument shaped enough to actually reach its
      // dialog call — passing plain `undefined` for all of them made
      // specs:export throw on `spec.name` and collections:export throw with
      // "Collection not found" before ever calling dialog.showSaveDialog,
      // which was a bug in this test (not in the app): the try/catch below
      // swallowed those early throws and let the test pass right past the
      // very code path it was supposed to be exercising.
      let arg;
      if (channel === 'specs:export') {
        arg = { name: 'Test Spec', collectionId: 'default', steps: [] };
      } else if (channel === 'collections:export') {
        // dataStore is real (not mocked) in this harness — create an actual
        // collection so the handler has something real to look up and reach
        // its dialog.showSaveDialog call.
        const dataStore = require('../electron/dataStore.js');
        const created = dataStore.createCollection('Focus Test Collection');
        arg = created.id;
      } else {
        arg = undefined;
      }

      try {
        await handler({}, arg);
      } catch (err) {
        // Any other unexpected throw is still fine to swallow here — this
        // test only cares whether focus was reclaimed after the dialog
        // closed, not about the handler's return value.
      }

      assertContains(mock.calls, 'win.focus()', `${channel} should call win.focus() after the dialog closes`);
      mock.uninstall();
    });
  }
});

suite('ipcHandlers: window:reclaimFocus (used after renderer-side confirm/alert dialogs)', () => {
  test('is registered and calls forceFocus when invoked', () => {
    const { mock } = freshIpcHandlers();
    const handler = mock.registeredHandlers['window:reclaimFocus'];
    assertTrue(typeof handler === 'function', 'window:reclaimFocus handler should be registered');

    handler();
    assertContains(mock.calls, 'win.focus()');
    mock.uninstall();
  });
});

suite('ipcHandlers: recorder session end reclaims focus', () => {
  test('recorder:stop reclaims focus after stopping', async () => {
    const { mock } = freshIpcHandlers();
    const handler = mock.registeredHandlers['recorder:stop'];
    assertTrue(typeof handler === 'function', 'recorder:stop handler should be registered');

    await handler();
    assertContains(mock.calls, 'win.focus()', 'recorder:stop should reclaim focus');
    mock.uninstall();
  });
});
