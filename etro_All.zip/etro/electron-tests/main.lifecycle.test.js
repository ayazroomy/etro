const { installMockElectron } = require('./mockElectron');
const { suite, test, assertTrue, assertFalse, assertContains, assertEqual } = require('./testHarness');

function freshMain(overrides) {
  const mock = installMockElectron(overrides);
  for (const modPath of [
    '../electron/main.js',
    '../electron/ipcHandlers.js',
    '../electron/dataStore.js',
    '../electron/windowFocus.js',
    '../electron/testRunner.js',
    '../electron/recorder.js',
    '../electron/browserInstaller.js',
    '../electron/updater.js',
    '../electron/themeColors.js',
    '../runner/sessionStore.js',
  ]) {
    try {
      delete require.cache[require.resolve(modPath)];
    } catch (err) {
      // fine if not previously required
    }
  }
  require('../electron/main.js');
  return mock;
}

suite('main.js: single-instance lock', () => {
  test('quits immediately if the lock is not obtained (another instance is genuinely running)', () => {
    const mock = freshMain({ requestSingleInstanceLock: () => false });
    assertContains(mock.calls, 'app.quit()', 'should call app.quit() when the lock fails');
    mock.uninstall();
  });

  test('does NOT quit if the lock is obtained', () => {
    const mock = freshMain({ requestSingleInstanceLock: () => true });
    assertFalse(mock.calls.includes('app.quit()'), 'should not quit when the lock succeeds');
    mock.uninstall();
  });

  test('registers a second-instance handler that focuses the existing window', () => {
    const mock = freshMain({ requestSingleInstanceLock: () => true });
    assertTrue(
      typeof mock.registeredAppEvents['second-instance'] === 'function',
      'a second-instance handler should be registered'
    );
    mock.uninstall();
  });
});

suite('main.js: before-quit cleanup', () => {
  test('registers a before-quit handler', () => {
    const mock = freshMain({ requestSingleInstanceLock: () => true });
    assertTrue(
      typeof mock.registeredAppEvents['before-quit'] === 'function',
      'a before-quit handler should be registered'
    );
    mock.uninstall();
  });

  test('before-quit stops any in-progress test run, browser install, and recording without throwing', () => {
    const mock = freshMain({ requestSingleInstanceLock: () => true });
    const handler = mock.registeredAppEvents['before-quit'];
    assertTrue(typeof handler === 'function');

    // Should not throw even with nothing in progress — this is exactly the
    // "leftover process on next launch" bug's fix, so it needs to be robust
    // to being called with nothing active.
    let threw = false;
    try {
      handler();
    } catch (err) {
      threw = true;
    }
    assertFalse(threw, 'before-quit handler should never throw, even with nothing in progress');
    mock.uninstall();
  });
});

suite('main.js: startup registers the focus safety nets', () => {
  test('whenReady resolving removes the default menu bar', async () => {
    const mock = freshMain({
      requestSingleInstanceLock: () => true,
      whenReadyPromise: Promise.resolve(),
    });
    // give the promise chain in main.js a tick to run
    await new Promise((r) => setTimeout(r, 10));

    assertContains(mock.calls, 'Menu.setApplicationMenu(null)', 'should remove the default menu bar');
    mock.uninstall();
  });
});

suite('main.js: title bar theming', () => {
  // A frameless overlay title bar (titleBarStyle:'hidden' + titleBarOverlay,
  // used to recolor the title bar per-theme) was suspected of causing a
  // pervasive keyboard-focus bug and reverted — but the bug persisted even
  // with a plain native frame, disproving that theory. The actual likely
  // cause was windowFocus.js's forceFocus() toggling setAlwaysOnTop() on
  // every dialog/modal close (see windowFocus.test.js's regression guards
  // against that coming back). With that removed, title bar theming was
  // restored as a legitimate, unrelated feature.
  test('non-Mac windows use titleBarStyle:"hidden" with a themed titleBarOverlay', async () => {
    const mock = freshMain({
      requestSingleInstanceLock: () => true,
      whenReadyPromise: Promise.resolve(),
    });
    await new Promise((r) => setTimeout(r, 10));

    const mainWin = mock.createdWindows.find((w) => w._createdWithOpts.width === 1440);
    assertTrue(!!mainWin, 'could not find the main window (expected width 1440)');
    assertEqual(mainWin._createdWithOpts.titleBarStyle, 'hidden');
    assertTrue(!!mainWin._createdWithOpts.titleBarOverlay, 'expected a titleBarOverlay to be set');
    assertTrue(
      typeof mainWin._createdWithOpts.titleBarOverlay.color === 'string' && mainWin._createdWithOpts.titleBarOverlay.color.startsWith('#'),
      'expected titleBarOverlay.color to be a real hex color'
    );
    mock.uninstall();
  });

  test('the main window still uses autoHideMenuBar (unaffected by title bar theming)', async () => {
    const mock = freshMain({
      requestSingleInstanceLock: () => true,
      whenReadyPromise: Promise.resolve(),
    });
    await new Promise((r) => setTimeout(r, 10));

    const mainWin = mock.createdWindows.find((w) => w._createdWithOpts.width === 1440);
    assertTrue(!!mainWin, 'could not find the main window (expected width 1440)');
    assertTrue(mainWin._createdWithOpts.autoHideMenuBar === true, 'expected autoHideMenuBar to still be true');
    mock.uninstall();
  });
});

suite('main.js: opens maximized by default', () => {
  test('maximize() is called BEFORE show(), while the window is still hidden (no visible resize jump)', async () => {
    const mock = freshMain({
      requestSingleInstanceLock: () => true,
      whenReadyPromise: Promise.resolve(),
    });
    await new Promise((r) => setTimeout(r, 10));

    const mainWin = mock.createdWindows.find((w) => w._createdWithOpts.width === 1440);
    assertTrue(!!mainWin, 'could not find the main window (expected width 1440)');
    assertTrue(mainWin._createdWithOpts.show === false, 'window should be created hidden (show:false) so maximizing it is instant');

    // Simulate the real 'ready-to-show' event firing.
    const handler = mainWin['_once_ready-to-show'];
    assertTrue(typeof handler === 'function', 'expected a ready-to-show handler to be registered');
    handler();

    const maximizeIndex = mock.calls.indexOf('win.maximize()');
    const showIndex = mock.calls.indexOf('win.show()');
    assertTrue(maximizeIndex !== -1, 'expected win.maximize() to have been called');
    assertTrue(showIndex !== -1, 'expected win.show() to have been called');
    assertTrue(maximizeIndex < showIndex, 'maximize() must be called BEFORE show() so the window opens already maximized with no visible jump');
    mock.uninstall();
  });
});
