const Module = require('module');

/**
 * Installs a mock 'electron' module in Node's require cache before any
 * app code is required, and returns { app, calls, makeWindow } for making
 * assertions. Call uninstall() when done (or just let the process exit,
 * since each test file runs in its own `node` process via run-all.js).
 */
function installMockElectron(overrides = {}) {
  const calls = [];
  const registeredHandlers = {};
  const registeredAppEvents = {};

  const app = {
    commandLine: { appendSwitch: () => {} },
    requestSingleInstanceLock: overrides.requestSingleInstanceLock || (() => true),
    quit: () => calls.push('app.quit()'),
    whenReady: () => (overrides.whenReadyPromise !== undefined ? overrides.whenReadyPromise : new Promise(() => {})),
    on: (event, handler) => {
      registeredAppEvents[event] = handler;
    },
    focus: (opts) => calls.push(`app.focus(${JSON.stringify(opts)})`),
    getPath: () => '/tmp/fake-userdata-electron-tests',
    getVersion: () => '0.1.0',
    isPackaged: overrides.isPackaged ?? false,
    ...overrides.appOverrides,
  };

  const createdWindows = [];

  function makeWindow(opts = {}) {
    const win = {
      _createdWithOpts: opts,
      isDestroyed: () => !!opts.destroyed,
      isMinimized: () => !!opts.minimized,
      restore: () => calls.push('win.restore()'),
      setAlwaysOnTop: (v) => calls.push(`setAlwaysOnTop(${v})`),
      focus: () => calls.push('win.focus()'),
      show: () => calls.push('win.show()'),
      maximize: () => calls.push('win.maximize()'),
      close: () => calls.push('win.close()'),
      setMenuBarVisibility: () => {},
      setTitleBarOverlay: (o) => calls.push(`setTitleBarOverlay(${JSON.stringify(o)})`),
      loadURL: () => calls.push('win.loadURL()'),
      loadFile: () => calls.push('win.loadFile()'),
      webContents: {
        openDevTools: () => {},
        on: () => {},
      },
      once: (event, handler) => {
        win[`_once_${event}`] = handler;
      },
      on: (event, handler) => {
        win[`_on_${event}`] = handler;
      },
    };
    createdWindows.push(win);
    return win;
  }

  const electronMock = {
    app,
    BrowserWindow: function MockBrowserWindow(opts) {
      return makeWindow(opts);
    },
    Menu: { setApplicationMenu: () => calls.push('Menu.setApplicationMenu(null)') },
    ipcMain: {
      handle: (channel, fn) => {
        registeredHandlers[channel] = fn;
      },
    },
    shell: {
      openPath: () => {},
      showItemInFolder: () => {},
      openExternal: () => {},
    },
    dialog: {
      showOpenDialog: overrides.showOpenDialog || (async () => ({ canceled: true, filePaths: [] })),
      showSaveDialog: overrides.showSaveDialog || (async () => ({ canceled: true })),
    },
  };

  const origResolve = Module._resolveFilename;
  Module._resolveFilename = function (request, ...args) {
    if (request === 'electron') return 'MOCK_ELECTRON_MODULE';
    return origResolve.call(this, request, ...args);
  };
  require.cache['MOCK_ELECTRON_MODULE'] = { id: 'MOCK_ELECTRON_MODULE', exports: electronMock };

  return {
    app,
    calls,
    registeredHandlers,
    registeredAppEvents,
    makeWindow,
    createdWindows,
    uninstall: () => {
      Module._resolveFilename = origResolve;
      delete require.cache['MOCK_ELECTRON_MODULE'];
    },
  };
}

module.exports = { installMockElectron };
