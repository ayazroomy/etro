const fs = require('fs');
const path = require('path');
const { summary, flushAsyncTests } = require('./testHarness');

const files = fs
  .readdirSync(__dirname)
  .filter((f) => f.endsWith('.test.js'))
  .sort();

console.log(`Running ${files.length} Electron test files...\n`);

async function main() {
  for (const file of files) {
    console.log(`${file}`);
    require(path.join(__dirname, file));
    console.log('');
  }

  await flushAsyncTests();

  const ok = summary();
  process.exit(ok ? 0 : 1);
}

main();
