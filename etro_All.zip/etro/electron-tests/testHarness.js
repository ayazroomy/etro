// Minimal, dependency-free test harness — no Jest/Mocha needed, just
// `node electron-tests/run-all.js`. Kept intentionally simple since these
// tests exist to catch regressions in main-process logic (focus handling,
// IPC wiring, lifecycle behavior) without needing a real display/window
// manager, which this environment may not always have.
let currentSuite = '';
let passed = 0;
let failed = 0;
const failures = [];

function suite(name, fn) {
  currentSuite = name;
  fn();
}

const pendingAsyncTests = [];

function test(name, fn) {
  const suiteName = currentSuite;
  try {
    const result = fn();
    if (result && typeof result.then === 'function') {
      // Defer async tests: run them after all synchronous suite() calls have
      // registered (so `currentSuite` context is captured correctly), then
      // await them in order before the final summary.
      pendingAsyncTests.push(
        result
          .then(() => {
            passed++;
            console.log(`  ✓ ${name}`);
          })
          .catch((err) => {
            failed++;
            failures.push({ suite: suiteName, name, error: err });
            console.log(`  ✗ ${name}`);
            console.log(`    ${err.message}`);
          })
      );
      return;
    }
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    failures.push({ suite: suiteName, name, error: err });
    console.log(`  ✗ ${name}`);
    console.log(`    ${err.message}`);
  }
}

async function flushAsyncTests() {
  await Promise.all(pendingAsyncTests);
}

function assertEqual(actual, expected, msg) {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  if (a !== e) {
    throw new Error(`${msg || 'assertEqual failed'}\n    expected: ${e}\n    actual:   ${a}`);
  }
}

function assertTrue(value, msg) {
  if (!value) throw new Error(msg || `expected truthy value, got ${JSON.stringify(value)}`);
}

function assertFalse(value, msg) {
  if (value) throw new Error(msg || `expected falsy value, got ${JSON.stringify(value)}`);
}

function assertContains(array, item, msg) {
  if (!array.includes(item)) {
    throw new Error(msg || `expected array to contain ${JSON.stringify(item)}, got ${JSON.stringify(array)}`);
  }
}

function summary() {
  console.log('');
  console.log(`${passed} passed, ${failed} failed`);
  if (failures.length) {
    console.log('\nFailures:');
    for (const f of failures) {
      console.log(`  [${f.suite}] ${f.name}: ${f.error.message}`);
    }
  }
  return failed === 0;
}

module.exports = { suite, test, assertEqual, assertTrue, assertFalse, assertContains, summary, flushAsyncTests };
