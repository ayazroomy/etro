const { installMockElectron } = require('./mockElectron');
const { suite, test, assertTrue, assertFalse, assertContains } = require('./testHarness');

suite('windowFocus.forceFocus', () => {
  test('focuses a live window', () => {
    const mock = installMockElectron();
    delete require.cache[require.resolve('../electron/windowFocus.js')];
    const { forceFocus } = require('../electron/windowFocus.js');

    const win = mock.makeWindow();
    forceFocus(win);

    assertContains(mock.calls, 'win.focus()', 'should call win.focus()');
    mock.uninstall();
  });

  test('does nothing for a null window (no throw)', () => {
    const mock = installMockElectron();
    delete require.cache[require.resolve('../electron/windowFocus.js')];
    const { forceFocus } = require('../electron/windowFocus.js');

    forceFocus(null); // must not throw
    assertTrue(mock.calls.length === 0, 'should make no calls for a null window');
    mock.uninstall();
  });

  test('does nothing for a destroyed window (no throw)', () => {
    const mock = installMockElectron();
    delete require.cache[require.resolve('../electron/windowFocus.js')];
    const { forceFocus } = require('../electron/windowFocus.js');

    const win = mock.makeWindow({ destroyed: true });
    forceFocus(win);
    assertTrue(mock.calls.length === 0, 'should make no calls for a destroyed window');
    mock.uninstall();
  });

  test('REGRESSION GUARD: does NOT toggle alwaysOnTop (a risky hack that was suspected of causing, not fixing, the focus/freeze bug — repeatedly forcing window z-order changes across many modal close events)', () => {
    const mock = installMockElectron();
    delete require.cache[require.resolve('../electron/windowFocus.js')];
    const { forceFocus } = require('../electron/windowFocus.js');

    const win = mock.makeWindow();
    forceFocus(win);
    assertFalse(mock.calls.includes('setAlwaysOnTop(true)'), 'forceFocus should not toggle alwaysOnTop anymore');
    assertFalse(mock.calls.includes('setAlwaysOnTop(false)'), 'forceFocus should not toggle alwaysOnTop anymore');
    mock.uninstall();
  });

  test('REGRESSION GUARD: does NOT call app.focus({steal:true}) (macOS-specific option, no effect on Windows where this bug was reported, dropped for simplicity)', () => {
    const mock = installMockElectron();
    delete require.cache[require.resolve('../electron/windowFocus.js')];
    const { forceFocus } = require('../electron/windowFocus.js');

    const win = mock.makeWindow();
    forceFocus(win);
    assertFalse(mock.calls.includes('app.focus({"steal":true})'), 'forceFocus should not call app.focus({steal:true}) anymore');
    mock.uninstall();
  });
});
