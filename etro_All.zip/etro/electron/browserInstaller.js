const path = require('path');
const { spawn } = require('child_process');

// Same resolution trick as testRunner.js: @playwright/test's "exports" map
// doesn't expose cli.js as a subpath, so resolve via its package.json instead.
const PLAYWRIGHT_CLI_PATH = path.join(
  path.dirname(require.resolve('@playwright/test/package.json')),
  'cli.js'
);

let currentChild = null;

function isInstalling() {
  return !!currentChild;
}

function stopInstall() {
  if (currentChild) {
    currentChild.kill();
    currentChild = null;
  }
}

/**
 * Runs `playwright install <browsers>` via Electron's own bundled Node
 * runtime — no npm/npx required on the end user's machine, only the app
 * itself. This is what a fresh install needs to run before any test can
 * actually launch a browser.
 * @param {string[]} browsers - e.g. ['chromium', 'firefox', 'webkit']
 * @param {function(string):void} onLine - called with each line of output
 * @param {function(number):void} onExit - called with the process exit code
 */
function installBrowsers({ browsers, onLine, onExit }) {
  if (currentChild) {
    throw new Error('A browser install is already in progress');
  }
  const list = browsers && browsers.length ? browsers : ['chromium'];

  const child = spawn(process.execPath, [PLAYWRIGHT_CLI_PATH, 'install', ...list], {
    env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' },
  });
  currentChild = child;

  const forward = (chunk) => {
    for (const line of chunk.toString().split('\n')) {
      if (line.trim()) onLine(line);
    }
  };
  child.stdout.on('data', forward);
  child.stderr.on('data', forward);

  child.on('close', (code) => {
    currentChild = null;
    onExit(code);
  });
}

module.exports = { installBrowsers, isInstalling, stopInstall };
