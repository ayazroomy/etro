const fs = require('fs');
const path = require('path');
const { devices } = require('@playwright/test');

const RUNNER_DIR = path.join(__dirname, '..', 'runner');

/**
 * Resolves the viewport that will actually be in effect: a selected device's
 * own viewport takes priority (matching how the device-merge below applies
 * it per-project), falling back to the manually configured one.
 */
function effectiveViewport(settings) {
  if (settings.device && devices[settings.device] && devices[settings.device].viewport) {
    return devices[settings.device].viewport;
  }
  return settings.viewport || { width: 1280, height: 720 };
}

/**
 * Headed-mode-only OS window sizing, matching the emulated viewport so a
 * mobile-device-emulated (or otherwise non-default) viewport doesn't sit
 * inside a mostly-blank, much larger window (see effectiveViewport above).
 *
 * Chromium only. Two separate attempts at sizing Firefox's window via CLI
 * flags both caused it to open a bogus second window navigated to a garbled
 * URL instead — first `--window-size=W,H` (Chromium's own syntax, produced
 * "http://1280,720/"), then Mozilla's own documented `-width`/`-height`
 * flags (produced "https://0.0.5.0/" with a real-world 1280×720 Firefox
 * headed run). Since there's no real Firefox binary available to verify
 * against directly — only documentation, which has now proven an unreliable
 * guide to Playwright's specific (patched, Juggler-protocol) Firefox build's
 * actual CLI argument handling — this stops guessing rather than risk a
 * third broken attempt. Firefox (and WebKit, for the same underlying
 * reason: no real binary to verify against) get NO custom sizing args at
 * all. The cost is purely cosmetic (extra blank space around a
 * non-default-sized viewport in headed mode); the alternative was an
 * actively disruptive bogus window appearing during every headed Firefox run.
 */
function windowSizeArgsFor(browserName, viewport, useMaximized) {
  if (browserName === 'chromium') {
    // --start-maximized is one of the oldest, most standard, most widely
    // documented Chromium command-line switches in existence (used across
    // Selenium/Puppeteer/Playwright tooling for years) — unlike the Firefox
    // flags above, this one is trusted without needing a real binary to
    // verify against first.
    if (useMaximized) return ['--start-maximized'];
    return [`--window-size=${viewport.width},${viewport.height}`];
  }
  // Firefox and WebKit: intentionally no custom sizing args — see the doc
  // comment above for why. This also means they're unaffected by "maximize
  // by default" — they keep opening at their own natural default size.
  return null;
}

/**
 * Turns app settings into a plain Playwright config object.
 * Nothing here is per-test-case — it is purely global run configuration,
 * exactly matching what the Settings modal exposes.
 */
function buildConfigObject(settings, opts) {
  const viewport = effectiveViewport(settings);
  const headed = settings.headless === false;
  const hasDevice = !!(settings.device && devices[settings.device] && devices[settings.device].viewport);
  // Optional, opt-in-only override for the browser binary Playwright
  // launches — useful in CI environments or with a custom Chromium build
  // where the standard `playwright install` browsers aren't what should run.
  // No effect at all unless this env var is explicitly set.
  const executablePathOverride = process.env.PWD_BROWSER_EXECUTABLE_PATH || undefined;

  // Headed mode, no device emulation, and the Settings "override maximized
  // viewport" checkbox unchecked (the default) -> open browsers maximized
  // instead of at a fixed viewport size. Device emulation always keeps its
  // own defined viewport regardless of this — maximizing would defeat the
  // whole point of emulating a specific device's screen size.
  const useMaximized = headed && !hasDevice && !settings.overrideMaximizedViewport;

  const videoMode = settings.video || 'retain-on-failure';
  // When maximized, there's no fixed viewport to size the video against —
  // `viewport: null` (below) means the page fills whatever the actual
  // maximized window turns out to be, which isn't knowable until runtime.
  // Use the detected screen size instead (passed in from the main process,
  // via Electron's `screen` module) so recorded video still gets a real,
  // non-downscaled resolution instead of Playwright's 800x800 default.
  const videoSize = useMaximized ? opts.maximizedSize || { width: 1920, height: 1080 } : viewport;

  const useBlock = {
    headless: settings.headless !== false,
    screenshot: settings.screenshot || 'only-on-failure',
    // Playwright's own documented default behavior (see recordVideo.size in
    // its docs) is to downscale video to fit within 800x800 unless an
    // explicit size is given — a real, confirmed quality loss versus the
    // actual configured viewport (e.g. 1280x720 gets scaled down). Passing
    // size explicitly, matching the effective viewport (or the maximized
    // screen size), avoids that.
    video: videoMode === 'off' ? 'off' : { mode: videoMode, size: videoSize },
    trace: settings.trace || 'retain-on-failure',
    // null is Playwright's documented way to opt out of a fixed viewport,
    // making the page's content area depend on the actual host window size
    // instead — exactly what's needed for a genuinely maximized window
    // (paired with Chromium's --start-maximized below) rather than a fixed
    // viewport sitting inside a separately-maximized window frame.
    viewport: useMaximized ? null : settings.viewport || { width: 1280, height: 720 },
  };

  const browsers = settings.browsers && settings.browsers.length ? settings.browsers : ['chromium'];

  return {
    testDir: RUNNER_DIR,
    testMatch: 'generic-runner.spec.js',
    timeout: settings.timeoutMs || 30000,
    retries: settings.retries || 0,
    workers: settings.workers || 1,
    reportSlowTests: null,
    reporter: [
      ['list'],
      ['json', { outputFile: path.join(opts.reportDir, 'results.json') }],
      ['html', { outputFolder: path.join(opts.reportDir, 'html'), open: 'never' }],
      [path.join(RUNNER_DIR, 'electron-reporter.js')],
    ],
    use: useBlock,
    projects: browsers.map((browserName) => {
      const projectUse = { browserName };
      const args = headed ? windowSizeArgsFor(browserName, viewport, useMaximized) : null;
      // Built explicitly per-project (rather than relying on the global
      // `use.launchOptions` merging down) so a Chromium-specific arg never
      // ends up applied to a Firefox/WebKit project just because it happened
      // to be set at the top level.
      if (args || executablePathOverride) {
        projectUse.launchOptions = {
          ...(args ? { args } : {}),
          ...(executablePathOverride ? { executablePath: executablePathOverride } : {}),
        };
      }
      return { name: browserName, use: projectUse };
    }),
  };
}

/**
 * Writes a real playwright.config.js to disk and returns its path.
 * We serialize with JSON + a small header instead of hand-building JS strings
 * for the bulk of the config, only special-casing `devices` when a device is set.
 */
function writeConfig({ settings, reportDir, configPath, maximizedSize }) {
  const cfg = buildConfigObject(settings, { reportDir, maximizedSize });

  const useDevice = !!settings.device;
  // Resolved here (inside the running app, where node_modules is guaranteed
  // reachable) rather than left as a bare `require('@playwright/test')` in
  // the generated file — that bare form only resolves if the config happens
  // to sit inside/under the project's own node_modules tree. Embedding the
  // absolute path lets the generated config live anywhere, including a
  // writable per-user temp folder outside the (read-only, once packaged) app directory.
  const playwrightTestPath = require.resolve('@playwright/test');

  const fileContents = `// AUTO-GENERATED by the app's Settings modal. Do not edit by hand — it is
// regenerated before every run from data/settings.json.
const { defineConfig, devices } = require(${JSON.stringify(playwrightTestPath)});

const config = ${JSON.stringify(cfg, null, 2)};

${
  useDevice
    ? `// Apply the selected device profile on top of each browser project
config.projects = config.projects.map((p) => ({
  ...p,
  use: { ...devices[${JSON.stringify(settings.device)}], ...p.use },
}));`
    : ''
}

module.exports = defineConfig(config);
`;

  fs.mkdirSync(path.dirname(configPath), { recursive: true });
  fs.writeFileSync(configPath, fileContents);
  return configPath;
}

module.exports = { writeConfig, RUNNER_DIR };
