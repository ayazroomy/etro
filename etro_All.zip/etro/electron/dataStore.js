const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { app } = require('electron');

// In dev (`npm run dev` / `electron .`), keep using the project-local data/
// folder so it's easy to inspect. Once packaged, the app directory is
// read-only (Program Files on Windows, inside the .app bundle on Mac), so
// everything moves to the OS-standard per-user app-data folder instead.
const DATA_DIR = app.isPackaged
  ? path.join(app.getPath('userData'), 'data')
  : path.join(__dirname, '..', 'data');
const SPECS_DIR = path.join(DATA_DIR, 'specs');
const REPORTS_DIR = path.join(DATA_DIR, 'reports');
const SESSIONS_DIR = path.join(DATA_DIR, 'sessions');
const COLLECTIONS_FILE = path.join(DATA_DIR, 'collections.json');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');

const DEFAULT_SETTINGS = {
  browsers: ['chromium'], // chromium | firefox | webkit
  viewport: { width: 1280, height: 720 },
  screenshot: 'only-on-failure', // off | on | only-on-failure  (Playwright's built-in, end-of-test capture)
  stepScreenshots: 'off', // off | on | only-on-failure  (this app's per-step capture, attached to each test.step)
  video: 'retain-on-failure', // off | on | retain-on-failure
  trace: 'retain-on-failure', // off | on | retain-on-failure | on-first-retry
  headless: true,
  timeoutMs: 30000,
  retries: 0,
  workers: 1,
  reportDir: REPORTS_DIR,
  device: '', // optional Playwright device name, e.g. 'iPhone 13'
  theme: 'default', // default | dark | light
  // Headed mode (no device selected) opens browsers maximized by default —
  // this opts back into the manually configured Width/Height instead. Only
  // meaningful when headless is false; ignored entirely when a device is
  // selected (device emulation always keeps its own defined viewport).
  overrideMaximizedViewport: false,
};

function ensureDirs() {
  for (const dir of [DATA_DIR, SPECS_DIR, REPORTS_DIR, SESSIONS_DIR]) {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  }
  if (!fs.existsSync(COLLECTIONS_FILE)) {
    fs.writeFileSync(
      COLLECTIONS_FILE,
      JSON.stringify([{ id: 'default', name: 'Default Collection' }], null, 2)
    );
  }
  const defaultCollectionDir = path.join(SPECS_DIR, 'default');
  if (!fs.existsSync(defaultCollectionDir)) {
    fs.mkdirSync(defaultCollectionDir, { recursive: true });
  }
  if (!fs.existsSync(SETTINGS_FILE)) {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(DEFAULT_SETTINGS, null, 2));
  }
}

function newId(prefix) {
  return `${prefix}_${crypto.randomBytes(6).toString('hex')}`;
}

// ---------- Collections ----------
function listCollections() {
  ensureDirs();
  return JSON.parse(fs.readFileSync(COLLECTIONS_FILE, 'utf-8'));
}

function saveCollections(collections) {
  fs.writeFileSync(COLLECTIONS_FILE, JSON.stringify(collections, null, 2));
}

function createCollection(name) {
  ensureDirs();
  const collections = listCollections();
  const id = newId('col');
  collections.push({ id, name });
  saveCollections(collections);
  fs.mkdirSync(path.join(SPECS_DIR, id), { recursive: true });
  return { id, name };
}

function deleteCollection(id) {
  const collections = listCollections().filter((c) => c.id !== id);
  saveCollections(collections);
  const dir = path.join(SPECS_DIR, id);
  if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
}

// ---------- Specs ----------
function listSpecs(collectionId) {
  ensureDirs();
  const dir = path.join(SPECS_DIR, collectionId);
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir)
    .filter((f) => f.endsWith('.json'))
    .map((f) => {
      const filePath = path.join(dir, f);
      const spec = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      spec.__filePath = filePath;
      return spec;
    });
}

function listAllSpecs() {
  ensureDirs();
  const collections = listCollections();
  const all = [];
  for (const c of collections) {
    for (const spec of listSpecs(c.id)) {
      all.push(spec);
    }
  }
  return all;
}

function specFilePath(spec) {
  return path.join(SPECS_DIR, spec.collectionId, `${spec.id}.json`);
}

function saveSpec(spec) {
  ensureDirs();
  if (!spec.collectionId) spec.collectionId = 'default';
  if (!spec.id) spec.id = newId('tc');
  spec.updatedAt = new Date().toISOString();
  const dir = path.join(SPECS_DIR, spec.collectionId);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const filePath = specFilePath(spec);
  const toWrite = { ...spec };
  delete toWrite.__filePath; // internal convenience field, not part of the spec's own data
  fs.writeFileSync(filePath, JSON.stringify(toWrite, null, 2));
  spec.__filePath = filePath;
  return spec;
}

function deleteSpec(spec) {
  const filePath = specFilePath(spec);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
}

// ---------- Settings ----------
function getSettings() {
  ensureDirs();
  return { ...DEFAULT_SETTINGS, ...JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf-8')) };
}

function saveSettings(settings) {
  ensureDirs();
  const merged = { ...getSettings(), ...settings };
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(merged, null, 2));
  return merged;
}

module.exports = {
  DATA_DIR,
  SPECS_DIR,
  REPORTS_DIR,
  SESSIONS_DIR,
  DEFAULT_SETTINGS,
  ensureDirs,
  listCollections,
  createCollection,
  deleteCollection,
  listSpecs,
  listAllSpecs,
  saveSpec,
  deleteSpec,
  getSettings,
  saveSettings,
};
