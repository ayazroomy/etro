const { ipcMain, shell, dialog, app } = require('electron');
const fs = require('fs');
const dataStore = require('./dataStore');
const testRunner = require('./testRunner');
const recorder = require('./recorder');
const sessionStore = require('../runner/sessionStore');
const browserInstaller = require('./browserInstaller');
const updater = require('./updater');
const { devices } = require('@playwright/test');
const { forceFocus } = require('./windowFocus');
const { overlayForTheme } = require('./themeColors');

function registerIpcHandlers(getMainWindow) {
  // ---------- Collections ----------
  ipcMain.handle('collections:list', () => dataStore.listCollections());
  ipcMain.handle('collections:create', (_e, name) => dataStore.createCollection(name));
  ipcMain.handle('collections:delete', (_e, id) => dataStore.deleteCollection(id));

  // ---------- Specs ----------
  ipcMain.handle('specs:list', (_e, collectionId) => dataStore.listSpecs(collectionId));
  ipcMain.handle('specs:listAll', () => dataStore.listAllSpecs());
  ipcMain.handle('specs:save', (_e, spec) => dataStore.saveSpec(spec));
  ipcMain.handle('specs:delete', (_e, spec) => dataStore.deleteSpec(spec));

  // ---------- Test data file reference (spec.testDataFile) ----------
  // Only the file PATH is ever stored on the spec — never its contents — so
  // editing the JSON externally is picked up on the next run without needing
  // to re-save the spec at all.
  ipcMain.handle('testdata:pick', async () => {
    const win = getMainWindow();
    const result = await dialog.showOpenDialog(win, {
      title: 'Select Test Data JSON File',
      properties: ['openFile'],
      filters: [{ name: 'JSON', extensions: ['json'] }],
    });
    forceFocus(win);
    if (result.canceled || !result.filePaths.length) return null;
    return result.filePaths[0];
  });

  // ---------- Devices (accurate viewport info for the Settings UI) ----------
  ipcMain.handle('devices:getViewport', (_e, deviceName) => {
    const d = deviceName && devices[deviceName];
    return d && d.viewport ? d.viewport : null;
  });

  ipcMain.handle('testdata:preview', (_e, filePath) => {
    if (!filePath) return { ok: false, error: 'No file selected' };
    try {
      const raw = fs.readFileSync(filePath, 'utf-8');
      const parsed = JSON.parse(raw);
      const keys =
        parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? Object.keys(parsed) : [];
      return { ok: true, keys };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  });

  ipcMain.handle('specs:export', async (_e, spec) => {
    const win = getMainWindow();
    const safeName = (spec.name || 'test-case').replace(/[^a-z0-9-_]+/gi, '_');
    const result = await dialog.showSaveDialog(win, {
      title: 'Export Test Case',
      defaultPath: `${safeName}.json`,
      filters: [{ name: 'JSON', extensions: ['json'] }],
    });
    forceFocus(win);
    if (result.canceled || !result.filePath) return null;
    const exportable = { ...spec };
    delete exportable.__filePath;
    fs.writeFileSync(result.filePath, JSON.stringify(exportable, null, 2));
    return result.filePath;
  });

  ipcMain.handle('specs:import', async (_e, collectionId) => {
    const win = getMainWindow();
    const result = await dialog.showOpenDialog(win, {
      title: 'Import Test Case(s)',
      properties: ['openFile', 'multiSelections'],
      filters: [{ name: 'JSON', extensions: ['json'] }],
    });
    forceFocus(win);
    if (result.canceled || !result.filePaths.length) return [];

    const imported = [];
    for (const filePath of result.filePaths) {
      try {
        const raw = fs.readFileSync(filePath, 'utf-8');
        const parsed = JSON.parse(raw);
        delete parsed.id; // force a fresh id so it never collides with an existing spec
        parsed.collectionId = collectionId || parsed.collectionId || 'default';
        imported.push(dataStore.saveSpec(parsed));
      } catch (err) {
        // Skip files that aren't valid spec JSON rather than aborting the whole batch
        console.error(`Skipped "${filePath}" during import:`, err.message);
      }
    }
    return imported;
  });

  // ---------- Collections: export/import a whole collection as one bundle file ----------
  ipcMain.handle('collections:export', async (_e, collectionId) => {
    const win = getMainWindow();
    const collections = dataStore.listCollections();
    const collection = collections.find((c) => c.id === collectionId);
    if (!collection) throw new Error('Collection not found');

    const specs = dataStore.listSpecs(collectionId).map((spec) => {
      const clean = { ...spec };
      delete clean.__filePath;
      delete clean.collectionId; // reassigned to a fresh collection on import
      return clean;
    });

    const safeName = collection.name.replace(/[^a-z0-9-_]+/gi, '_');
    const result = await dialog.showSaveDialog(win, {
      title: 'Export Collection',
      defaultPath: `${safeName}.etro-collection.json`,
      filters: [{ name: 'ETRO Collection', extensions: ['json'] }],
    });
    forceFocus(win);
    if (result.canceled || !result.filePath) return null;

    const bundle = { collection: { name: collection.name }, specs };
    fs.writeFileSync(result.filePath, JSON.stringify(bundle, null, 2));
    return result.filePath;
  });

  ipcMain.handle('collections:import', async () => {
    const win = getMainWindow();
    const result = await dialog.showOpenDialog(win, {
      title: 'Import Collection',
      properties: ['openFile'],
      filters: [{ name: 'ETRO Collection', extensions: ['json'] }],
    });
    forceFocus(win);
    if (result.canceled || !result.filePaths.length) return null;

    const raw = fs.readFileSync(result.filePaths[0], 'utf-8');
    const bundle = JSON.parse(raw);
    if (!bundle || !bundle.collection || !Array.isArray(bundle.specs)) {
      throw new Error('This file is not a valid collection export.');
    }

    const newCollection = dataStore.createCollection(bundle.collection.name || 'Imported Collection');
    const savedSpecs = bundle.specs.map((spec) => {
      const clean = { ...spec };
      delete clean.id; // fresh ids, never collide with anything existing
      clean.collectionId = newCollection.id;
      return dataStore.saveSpec(clean);
    });

    return { collection: newCollection, specs: savedSpecs };
  });

  // ---------- Settings ----------
  ipcMain.handle('settings:get', () => dataStore.getSettings());
  ipcMain.handle('settings:save', (_e, settings) => dataStore.saveSettings(settings));

  // ---------- Test run ----------
  ipcMain.handle('run:start', (_e, { specFilePaths }) => {
    if (testRunner.isRunning()) {
      throw new Error('A run is already in progress');
    }
    const win = getMainWindow();
    const { runId, reportDir } = testRunner.runTests({
      specFilePaths,
      onEvent: (event) => {
        if (win && !win.isDestroyed()) {
          win.webContents.send('run:event', event);
        }
      },
      onExit: (code) => {
        if (win && !win.isDestroyed()) {
          win.webContents.send('run:exit', code);
        }
      },
    });
    return { runId, reportDir };
  });

  ipcMain.handle('run:stop', () => {
    testRunner.stopRun();
    return true;
  });

  ipcMain.handle('run:isRunning', () => testRunner.isRunning());

  // ---------- Recorder (generate test cases by browsing) ----------
  ipcMain.handle('recorder:start', async (_e, { browserName, baseUrl }) => {
    const win = getMainWindow();
    await recorder.startRecording({
      browserName,
      baseUrl,
      onStep: (step) => {
        if (win && !win.isDestroyed()) win.webContents.send('recorder:step', step);
      },
      onClosed: () => {
        // The recorder's browser is a real, separate Chromium process — not
        // an Electron window — so Electron has no automatic way of knowing
        // it closed and reclaiming focus. Without this, our own window can
        // be left without OS-level keyboard focus even though it's visible.
        forceFocus(win);
        if (win && !win.isDestroyed()) win.webContents.send('recorder:closed');
      },
    });
    return true;
  });

  ipcMain.handle('recorder:stop', async () => {
    const { steps } = await recorder.stopRecording();
    forceFocus(getMainWindow());
    return steps;
  });

  ipcMain.handle('recorder:isRecording', () => recorder.isRecording());

  // ---------- Sessions (saved login state for reuse across test runs) ----------
  ipcMain.handle('sessions:list', () => sessionStore.listSessions());
  ipcMain.handle('sessions:delete', (_e, name) => {
    sessionStore.deleteSession(name);
    return true;
  });

  // ---------- Browser install (first-run setup, no npm required) ----------
  ipcMain.handle('browsers:install', (_e, browsers) => {
    const win = getMainWindow();
    if (browserInstaller.isInstalling()) {
      throw new Error('A browser install is already in progress');
    }
    browserInstaller.installBrowsers({
      browsers,
      onLine: (line) => {
        if (win && !win.isDestroyed()) win.webContents.send('browsers:installLog', line);
      },
      onExit: (code) => {
        if (win && !win.isDestroyed()) win.webContents.send('browsers:installExit', code);
      },
    });
    return true;
  });
  ipcMain.handle('browsers:isInstalling', () => browserInstaller.isInstalling());

  // ---------- Reports / filesystem helpers ----------
  ipcMain.handle('shell:openPath', (_e, targetPath) => shell.openPath(targetPath));
  ipcMain.handle('shell:showItemInFolder', (_e, targetPath) => shell.showItemInFolder(targetPath));
  ipcMain.handle('dialog:pickReportDir', async () => {
    const win = getMainWindow();
    const result = await dialog.showOpenDialog(win, {
      properties: ['openDirectory', 'createDirectory'],
    });
    forceFocus(win);
    if (result.canceled || !result.filePaths.length) return null;
    return result.filePaths[0];
  });

  ipcMain.handle('meta:paths', () => ({
    specsDir: dataStore.SPECS_DIR,
    reportsDir: dataStore.REPORTS_DIR,
  }));

  // ---------- About / updates ----------
  ipcMain.handle('app:getVersion', () => app.getVersion());
  ipcMain.handle('app:isPackaged', () => app.isPackaged);
  ipcMain.handle('app:platform', () => process.platform);

  ipcMain.handle('window:setTitleBarTheme', (_e, themeName) => {
    const win = getMainWindow();
    // Mac's traffic-light buttons aren't recolorable via any public Electron
    // API (Apple doesn't expose that) — this only does anything on
    // Windows/Linux, where the title bar is a themed overlay instead.
    if (!win || process.platform === 'darwin') return;
    if (typeof win.setTitleBarOverlay === 'function') {
      win.setTitleBarOverlay(overlayForTheme(themeName));
    }
  });

  // Called by the renderer right after any window.confirm()/window.alert()
  // dialog closes. These are Chromium-native blocking dialogs — unlike the
  // OS file dialogs (dialog.showOpenDialog etc.), there's no main-process
  // event to hook when one closes, since the whole interaction happens
  // synchronously on the renderer side. This gives the renderer an explicit
  // way to ask for the same focus-reclaim treatment right after.
  ipcMain.handle('window:reclaimFocus', () => {
    forceFocus(getMainWindow());
  });

  ipcMain.handle('updates:check', () => updater.checkForUpdates());
  ipcMain.handle('updates:download', () => updater.downloadUpdate());
  ipcMain.handle('updates:install', () => updater.quitAndInstall());

  ipcMain.handle('shell:openExternal', (_e, url) => shell.openExternal(url));
}

module.exports = { registerIpcHandlers };
