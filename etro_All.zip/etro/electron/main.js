const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
const dataStore = require('./dataStore');
const { registerIpcHandlers } = require('./ipcHandlers');
const { setupAutoUpdater } = require('./updater');
const { forceFocus } = require('./windowFocus');
const { overlayForTheme } = require('./themeColors');
const testRunner = require('./testRunner');
const recorder = require('./recorder');
const browserInstaller = require('./browserInstaller');

// Chromium's DevTools frontend calls the 'Autofill' CDP domain (used for its
// Elements-panel autofill highlighting), which Electron's embedded Chromium
// doesn't implement. This produces harmless "Autofill.enable wasn't found"
// console errors whenever DevTools is open (dev mode only) — it's a
// long-standing, widely-reported Electron/Chromium quirk, not a bug in this
// app. This switch quiets it in most Electron versions; if a line or two
// still slips through occasionally, it's safe to ignore.
app.commandLine.appendSwitch('disable-features', 'Autofill');

// Prevents a second process from ever fully starting while one is already
// running. Without this, if the previous process didn't fully terminate on
// close (a lingering child process — a Playwright test run, the browser
// installer, or the recorder's separate browser — can keep the Node event
// loop alive even after the window closes), launching the app again spins
// up a genuinely separate process that fights the first for Chromium's own
// internal singleton lock on the userData directory — which hangs rather
// than fails cleanly. Symptom without this: the app "keeps loading, never
// opens" on a relaunch. With the lock in place, a second launch attempt
// just quits immediately and focuses the already-running window instead.
const gotSingleInstanceLock = app.requestSingleInstanceLock();
if (!gotSingleInstanceLock) {
  app.quit();
}

const APP_ICON = path.join(__dirname, 'assets', 'icon.png');

let mainWindow = null;
let splashWindow = null;

function createSplashWindow() {
  splashWindow = new BrowserWindow({
    width: 340,
    height: 340,
    frame: false,
    resizable: false,
    movable: false,
    transparent: false,
    backgroundColor: '#1a1b20',
    icon: APP_ICON,
    show: true,
    skipTaskbar: false,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  splashWindow.loadFile(path.join(__dirname, 'splash.html'));
  splashWindow.on('closed', () => {
    splashWindow = null;
  });
}

function createWindow() {
  // Use whatever theme was last saved (falls back to 'default' on first run)
  // so the title bar is correctly colored from the very first frame.
  const settings = dataStore.getSettings();
  const isMac = process.platform === 'darwin';

  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 640,
    backgroundColor: '#1e1f24',
    icon: APP_ICON,
    show: false, // revealed once ready, so the splash screen covers the load time
    autoHideMenuBar: true, // Windows/Linux: menu bar stays hidden unless Alt is pressed
    // Mac: keep the native traffic-light buttons (small, top-left, always
    // native-colored by OS convention) but hide the title text bar so our
    // own toolbar sits flush at the top. Windows/Linux: replace the native
    // title bar with a themed overlay — same minimize/maximize/close
    // buttons, just recolored to match the app's current theme.
    //
    // NOTE: this was previously suspected of causing a pervasive keyboard-
    // focus bug and reverted. It was NOT the cause — the bug persisted even
    // with a plain native frame. The actual likely cause was
    // windowFocus.js's forceFocus() repeatedly toggling setAlwaysOnTop() on
    // every dialog/modal close, which can confuse the Windows window
    // manager's z-order/focus state when called often in quick succession.
    // That toggle has been removed; this feature is restored.
    ...(isMac
      ? { titleBarStyle: 'hiddenInset' }
      : { titleBarStyle: 'hidden', titleBarOverlay: overlayForTheme(settings.theme) }),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });
  mainWindow.setMenuBarVisibility(false);

  const isDev = process.env.NODE_ENV === 'development';
  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  } else {
    mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'renderer', 'index.html'));
  }

  // Diagnostics: if the page genuinely fails to load, log why instead of
  // just silently sitting on the splash screen with no clue what happened.
  // Visible when launched from a terminal/command prompt; otherwise at
  // least this doesn't make a real load failure any harder to debug later.
  mainWindow.webContents.on('did-fail-load', (_event, errorCode, errorDescription) => {
    console.error(`[ETRO] Main window failed to load: ${errorCode} ${errorDescription}`);
  });

  // Safety net: if 'ready-to-show' never fires for any reason (a genuine
  // load hang, an unexpected exception mid-startup, etc.), don't leave the
  // user stuck on the splash screen forever with no way out but killing the
  // process. Show whatever we've got after a timeout instead.
  let readyTimeoutHandle = setTimeout(() => {
    console.error('[ETRO] Main window did not become ready within 15s — showing it anyway.');
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.maximize();
      mainWindow.show();
      forceFocus(mainWindow);
    }
    if (splashWindow) {
      splashWindow.close();
      splashWindow = null;
    }
  }, 15000);

  mainWindow.once('ready-to-show', () => {
    clearTimeout(readyTimeoutHandle);
    // Maximize while still hidden (show:false) so it's instant — no visible
    // resize jump from windowed to maximized right after appearing.
    mainWindow.maximize();
    mainWindow.show();
    if (splashWindow) {
      splashWindow.close();
      splashWindow = null;
    }
    // show() alone doesn't reliably hand the window OS-level keyboard focus
    // in every case (most noticeably right after another window — here, the
    // splash screen — was just closed), which is what caused text fields to
    // look "dead" until the user alt-tabbed away and back to force the OS to
    // reassign focus. Asserting focus LAST (after splash is already closed,
    // with a short delay for the OS to finish processing that closure) avoids
    // a race where closing splash steals focus right back immediately after
    // we grab it.
    setTimeout(() => forceFocus(mainWindow), 100);
  });

  // General safety net: reclaim focus any time the window becomes visible
  // again (e.g. un-minimized, or shown after losing focus to some other
  // process), not just once at initial startup.
  mainWindow.on('show', () => forceFocus(mainWindow));

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// A second launch attempt while we're already running: focus the existing
// window instead of doing nothing (or, without the lock above, hanging).
app.on('second-instance', () => {
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    forceFocus(mainWindow);
  }
});

app.whenReady().then(() => {
  if (!gotSingleInstanceLock) return; // already quitting; avoid starting anything

  // Removes the default File/Edit/View/Window/Help menu bar entirely on
  // Windows/Linux. On Mac, the OS-level app menu (leftmost menu, holding
  // Quit/Cmd+Q and a few system items) can't be fully removed by convention —
  // this still strips it down to Electron's bare minimum rather than the
  // full default template with Edit/View/Window menus.
  Menu.setApplicationMenu(null);

  dataStore.ensureDirs();
  process.env.PWD_SESSIONS_DIR = dataStore.SESSIONS_DIR;
  registerIpcHandlers(() => mainWindow);
  setupAutoUpdater(() => mainWindow);

  createSplashWindow();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// Belt-and-suspenders alongside the single-instance lock above: make sure a
// test run, browser install, or recording session in progress when the app
// closes doesn't leave a child process running in the background — that's
// exactly the kind of leftover process that can interfere with (or get
// mistaken for) a subsequent launch.
app.on('before-quit', () => {
  try {
    testRunner.stopRun();
  } catch (err) {
    // no run in progress, or already stopped
  }
  try {
    browserInstaller.stopInstall();
  } catch (err) {
    // no install in progress, or already stopped
  }
  if (recorder.isRecording()) {
    recorder.stopRecording().catch(() => {});
  }
});
