const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  // Collections
  listCollections: () => ipcRenderer.invoke('collections:list'),
  createCollection: (name) => ipcRenderer.invoke('collections:create', name),
  deleteCollection: (id) => ipcRenderer.invoke('collections:delete', id),
  exportCollection: (id) => ipcRenderer.invoke('collections:export', id),
  importCollection: () => ipcRenderer.invoke('collections:import'),

  // Specs
  listSpecs: (collectionId) => ipcRenderer.invoke('specs:list', collectionId),
  listAllSpecs: () => ipcRenderer.invoke('specs:listAll'),
  saveSpec: (spec) => ipcRenderer.invoke('specs:save', spec),
  deleteSpec: (spec) => ipcRenderer.invoke('specs:delete', spec),
  exportSpec: (spec) => ipcRenderer.invoke('specs:export', spec),
  importSpecs: (collectionId) => ipcRenderer.invoke('specs:import', collectionId),
  pickTestDataFile: () => ipcRenderer.invoke('testdata:pick'),
  previewTestDataFile: (filePath) => ipcRenderer.invoke('testdata:preview', filePath),
  getDeviceViewport: (deviceName) => ipcRenderer.invoke('devices:getViewport', deviceName),

  // Settings
  getSettings: () => ipcRenderer.invoke('settings:get'),
  saveSettings: (settings) => ipcRenderer.invoke('settings:save', settings),

  // Run
  startRun: (specFilePaths) => ipcRenderer.invoke('run:start', { specFilePaths }),
  stopRun: () => ipcRenderer.invoke('run:stop'),
  isRunning: () => ipcRenderer.invoke('run:isRunning'),
  onRunEvent: (callback) => {
    const listener = (_e, event) => callback(event);
    ipcRenderer.on('run:event', listener);
    return () => ipcRenderer.removeListener('run:event', listener);
  },
  onRunExit: (callback) => {
    const listener = (_e, code) => callback(code);
    ipcRenderer.on('run:exit', listener);
    return () => ipcRenderer.removeListener('run:exit', listener);
  },

  // Recorder
  startRecording: (opts) => ipcRenderer.invoke('recorder:start', opts),
  stopRecording: () => ipcRenderer.invoke('recorder:stop'),
  isRecording: () => ipcRenderer.invoke('recorder:isRecording'),
  onRecorderStep: (callback) => {
    const listener = (_e, step) => callback(step);
    ipcRenderer.on('recorder:step', listener);
    return () => ipcRenderer.removeListener('recorder:step', listener);
  },
  onRecorderClosed: (callback) => {
    const listener = () => callback();
    ipcRenderer.on('recorder:closed', listener);
    return () => ipcRenderer.removeListener('recorder:closed', listener);
  },

  // Sessions
  listSessions: () => ipcRenderer.invoke('sessions:list'),
  deleteSession: (name) => ipcRenderer.invoke('sessions:delete', name),

  // Browser install
  installBrowsers: (browsers) => ipcRenderer.invoke('browsers:install', browsers),
  isInstallingBrowsers: () => ipcRenderer.invoke('browsers:isInstalling'),
  onBrowserInstallLog: (callback) => {
    const listener = (_e, line) => callback(line);
    ipcRenderer.on('browsers:installLog', listener);
    return () => ipcRenderer.removeListener('browsers:installLog', listener);
  },
  onBrowserInstallExit: (callback) => {
    const listener = (_e, code) => callback(code);
    ipcRenderer.on('browsers:installExit', listener);
    return () => ipcRenderer.removeListener('browsers:installExit', listener);
  },

  // Filesystem helpers
  openPath: (targetPath) => ipcRenderer.invoke('shell:openPath', targetPath),
  showItemInFolder: (targetPath) => ipcRenderer.invoke('shell:showItemInFolder', targetPath),
  pickReportDir: () => ipcRenderer.invoke('dialog:pickReportDir'),
  getPaths: () => ipcRenderer.invoke('meta:paths'),

  // About / updates
  getAppVersion: () => ipcRenderer.invoke('app:getVersion'),
  isPackaged: () => ipcRenderer.invoke('app:isPackaged'),
  getPlatform: () => ipcRenderer.invoke('app:platform'),
  setTitleBarTheme: (themeName) => ipcRenderer.invoke('window:setTitleBarTheme', themeName),
  reclaimFocus: () => ipcRenderer.invoke('window:reclaimFocus'),
  checkForUpdates: () => ipcRenderer.invoke('updates:check'),
  downloadUpdate: () => ipcRenderer.invoke('updates:download'),
  installUpdate: () => ipcRenderer.invoke('updates:install'),
  onUpdateStatus: (callback) => {
    const listener = (_e, payload) => callback(payload);
    ipcRenderer.on('updates:status', listener);
    return () => ipcRenderer.removeListener('updates:status', listener);
  },
  openExternal: (url) => ipcRenderer.invoke('shell:openExternal', url),
});
