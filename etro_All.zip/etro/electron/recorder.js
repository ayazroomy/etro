const { chromium, firefox, webkit } = require('@playwright/test');

const BROWSER_LAUNCHERS = { chromium, firefox, webkit };

let currentSession = null; // { browser, context, page, steps, onClosed }

/**
 * Runs INSIDE the recorded page (via context.addInitScript). It has no access
 * to the Node/Electron world directly — it only talks back out through the
 * `window.__pwd_record` function that Playwright's `exposeFunction` installs
 * on every frame in the context before this init script runs.
 *
 * Locator preference mirrors runner/locatorResolver.js so recorded steps are
 * already compatible with the app's own DSL without any translation step.
 */
function injectedRecorderScript() {
  // ---- "Does this id/class look stable, or auto-generated?" heuristics ----
  // Best-effort pattern matching against common auto-generated id/class
  // shapes from popular frameworks/libraries — not a perfect classifier, but
  // catches the large majority of real-world cases seen in practice.
  function looksLikeStableId(id) {
    if (!id) return false;
    if (/^:.+:$/.test(id)) return false; // Radix UI / React Aria, e.g. ":r0:", ":r1a:"
    if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) return false; // UUID
    if (/^(ember|mui|radix|react|vue|ng|css|headlessui)[-:]?\d+$/i.test(id)) return false; // framework-prefixed counters
    if (/^[a-z]{1,8}[-_]?\d{3,}$/i.test(id)) return false; // short-prefix + long digit run (generated counters)
    if (/^\d+$/.test(id)) return false; // purely numeric
    if (id.length > 25 && !/[-_\s]/.test(id) && /\d/.test(id) && /[a-z]/i.test(id)) return false; // long hash-like blob
    return true;
  }

  function looksLikeStableClass(cls) {
    if (!cls) return false;
    if (/^(css|sc|jsx|emotion|makeStyles|MuiBox|styled)[-_][a-z0-9]+$/i.test(cls)) return false; // CSS-in-JS generated
    if (/^[a-z0-9]{6,}$/i.test(cls) && /\d/.test(cls) && !/[-_]/.test(cls)) return false; // hashy blob, no separators
    if (/^(active|hover|focus|disabled|selected)$/i.test(cls)) return false; // transient state classes
    return true;
  }

  // Best-effort accessible name approximation: what a screen reader would
  // announce for this element, checked in the same priority ARIA itself
  // specifies (label associations before visible text before title).
  function accessibleName(el) {
    const ariaLabel = el.getAttribute('aria-label');
    if (ariaLabel) return ariaLabel.trim();
    if (el.labels && el.labels.length) {
      const text = el.labels[0].innerText || el.labels[0].textContent;
      if (text && text.trim()) return text.trim();
    }
    // innerText/value only makes sense as a "name" for non-form-input
    // elements (buttons, links, headings — where the visible text genuinely
    // IS the accessible name). For INPUT/TEXTAREA/SELECT, falling back to
    // innerText/value here would pick up things like a <select>'s currently
    // chosen option, or a checkbox's default value="on" — neither is a
    // meaningful or stable "name"; those element types fall through to the
    // dedicated placeholder/name-attribute steps in getLocator() instead.
    const tag = el.tagName;
    const isFormInput = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';
    if (!isFormInput) {
      const text = (el.innerText || el.textContent || '').trim();
      if (text) return text.slice(0, 80);
    }
    const title = el.getAttribute('title');
    if (title) return title;
    return '';
  }

  // Maps common HTML elements to the ARIA role Playwright's getByRole()
  // would need — covering the interactive elements people actually record
  // clicking/filling/checking, not attempting a full HTML-AAM implementation.
  function impliedRole(el) {
    const explicit = el.getAttribute('role');
    if (explicit) return explicit;
    const tag = el.tagName;
    const type = (el.type || '').toLowerCase();
    if (tag === 'BUTTON') return 'button';
    if (tag === 'A' && el.hasAttribute('href')) return 'link';
    if (tag === 'SELECT') return 'combobox';
    if (tag === 'TEXTAREA') return 'textbox';
    if (tag === 'IMG') return 'img';
    if (/^H[1-6]$/.test(tag)) return 'heading';
    if (tag === 'INPUT') {
      if (type === 'checkbox') return 'checkbox';
      if (type === 'radio') return 'radio';
      if (type === 'submit' || type === 'button' || type === 'reset') return 'button';
      if (type === 'search') return 'searchbox';
      if (['text', 'email', 'tel', 'url', 'password', 'number', ''].includes(type)) return 'textbox';
    }
    return null;
  }

  // Builds a short, human-legible CSS path as an absolute last resort — only
  // reached when nothing above (testid/role/label/placeholder/text/alt/title/
  // stable id/name attribute) matched. Prefers a semantic attribute selector
  // (name, type, aria-*) over positional nth-of-type traversal, and only
  // includes class names that don't look auto-generated.
  function cssPath(el) {
    // A semantic attribute is far more stable than a structural path.
    if (el.name) return `${el.tagName.toLowerCase()}[name="${CSS.escape(el.name)}"]`;
    if (el.type && el.tagName === 'INPUT') {
      const withType = document.querySelectorAll(`input[type="${CSS.escape(el.type)}"]`);
      if (withType.length === 1) return `input[type="${CSS.escape(el.type)}"]`;
    }

    const parts = [];
    let node = el;
    while (node && node.nodeType === 1 && parts.length < 6) {
      let selector = node.tagName.toLowerCase();
      if (node.id && looksLikeStableId(node.id)) {
        // A stable ancestor id anchors the whole path — no need to climb
        // further or worry about siblings above this point.
        parts.unshift('#' + CSS.escape(node.id));
        break;
      }
      const stableClasses = node.classList
        ? Array.from(node.classList).filter(looksLikeStableClass).slice(0, 2)
        : [];
      if (stableClasses.length) {
        selector += '.' + stableClasses.map((c) => CSS.escape(c)).join('.');
      }
      const parent = node.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter((s) => s.tagName === node.tagName);
        if (siblings.length > 1) {
          selector += `:nth-of-type(${siblings.indexOf(node) + 1})`;
        }
      }
      parts.unshift(selector);
      node = parent;
    }
    return parts.join(' > ');
  }

  function getLocator(el) {
    if (!el || el.nodeType !== 1) return null;

    // 1. Explicit test hooks — the most stable signal there is, since
    //    they're deliberately added for automation and won't shift with
    //    redesigns the way visible text or styling might.
    const testId = (el.dataset && (el.dataset.testid || el.dataset.testId)) || el.getAttribute('data-test') || el.getAttribute('data-qa');
    if (testId) return { type: 'testid', value: testId };

    // 2. Role + accessible name — Playwright's own documented top
    //    recommendation ("closely resembles how users and assistive
    //    technology perceive the page"), and resilient to markup/styling
    //    changes as long as the element's purpose and visible label don't
    //    change.
    const role = impliedRole(el);
    if (role) {
      const name = accessibleName(el);
      if (name) return { type: 'role', role, name };
    }

    // 3. An aria-label with no clean role match still makes a fine label
    //    locator on its own.
    const ariaLabel = el.getAttribute('aria-label');
    if (ariaLabel) return { type: 'label', value: ariaLabel };

    // 4. An explicitly associated <label> (via `for=` or wrapping) —
    //    getByLabel() is exactly built for this.
    if (el.labels && el.labels.length) {
      const text = (el.labels[0].innerText || el.labels[0].textContent || '').trim();
      if (text) return { type: 'label', value: text };
    }

    // 5. Placeholder — common and stable for inputs with no visible label.
    const placeholder = el.getAttribute('placeholder');
    if (placeholder) return { type: 'placeholder', value: placeholder };

    // 6. Visible text — good for links/buttons/generic clickable elements
    //    that didn't get a role match above (e.g. a <div role="button"> was
    //    already caught by step 2; this catches plain text-bearing elements
    //    like a <span> or <li> acting as a click target).
    const text = (el.innerText || el.textContent || '').trim();
    if (text && text.length <= 80 && el.children.length === 0) {
      return { type: 'text', value: text };
    }

    // 7. Alt text — images.
    const alt = el.getAttribute('alt');
    if (alt) return { type: 'altText', value: alt };

    // 8. Title attribute.
    const title = el.getAttribute('title');
    if (title) return { type: 'title', value: title };

    // 9. A stable-looking id — good, but checked this late specifically to
    //    avoid the common case of auto-generated ids (React/Vue/Angular
    //    component instances, Radix UI, MUI, etc.) getting picked over a
    //    genuinely more meaningful signal above. Random/generated-looking
    //    ids are rejected by looksLikeStableId() and fall through instead of
    //    being used here.
    if (el.id && looksLikeStableId(el.id)) {
      return { type: 'css', value: '#' + CSS.escape(el.id) };
    }

    // 10. name attribute — very common and stable on form elements.
    if (el.name) {
      return { type: 'css', value: `${el.tagName.toLowerCase()}[name="${CSS.escape(el.name)}"]` };
    }

    // 11. Last resort: a short, semantic-where-possible CSS path that
    //     specifically avoids auto-generated ids/classes (see cssPath above).
    return { type: 'css', value: cssPath(el) };
  }

  document.addEventListener(
    'click',
    (e) => {
      const el = e.target && e.target.closest ? e.target.closest('button, a, [role], input, select, label, *') : e.target;
      const locator = getLocator(el);
      if (!locator || !window.__pwd_record) return;
      // Clicks on inputs/selects are usually just focusing before typing/choosing —
      // let the 'change' handler below record the meaningful action instead.
      const tag = el.tagName;
      if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
      window.__pwd_record({ action: 'click', locator });
    },
    true
  );

  // ---- Text entry (fill) ----
  // Deliberately NOT relying on 'change' alone (fires only on blur/commit
  // within the SAME page) — when the user finishes typing and then switches
  // to a totally different OS window (this app's own "Stop & Review" button)
  // rather than clicking elsewhere on the page, that cross-window focus
  // switch doesn't reliably fire 'change' before the browser gets closed,
  // silently dropping the typed text. Instead: debounce on 'input' (fires on
  // every keystroke) and flush the pending value after a short pause in
  // typing, PLUS flush immediately on blur, PLUS expose a flush function
  // externally so stopRecording() can force one last flush right before
  // closing the browser, covering the "typed and immediately clicked Stop"
  // case with no pause at all.
  let pendingInputEl = null;
  let pendingInputTimer = null;

  function flushPendingInput() {
    if (pendingInputTimer) {
      clearTimeout(pendingInputTimer);
      pendingInputTimer = null;
    }
    if (!pendingInputEl || !window.__pwd_record) {
      pendingInputEl = null;
      return;
    }
    const el = pendingInputEl;
    pendingInputEl = null;
    const locator = getLocator(el);
    if (!locator) return;
    window.__pwd_record({ action: 'fill', locator, value: el.value });
  }
  // Exposed so recorder.js can force a flush (via page.evaluate) right
  // before closing the browser, catching text with no pause before Stop.
  window.__pwd_flushPendingInput = flushPendingInput;

  document.addEventListener(
    'input',
    (e) => {
      const el = e.target;
      if (!el) return;
      const tag = el.tagName;
      const type = (el.type || '').toLowerCase();
      if (tag !== 'INPUT' && tag !== 'TEXTAREA') return;
      if (type === 'checkbox' || type === 'radio') return; // handled by 'change' below

      if (pendingInputEl && pendingInputEl !== el) {
        flushPendingInput(); // switched fields — commit the previous one now
      }
      pendingInputEl = el;
      if (pendingInputTimer) clearTimeout(pendingInputTimer);
      pendingInputTimer = setTimeout(flushPendingInput, 600);
    },
    true
  );

  document.addEventListener(
    'blur',
    (e) => {
      if (e.target === pendingInputEl) flushPendingInput();
    },
    true
  );

  window.addEventListener('beforeunload', () => flushPendingInput());

  document.addEventListener(
    'change',
    (e) => {
      const el = e.target;
      if (!el || !window.__pwd_record) return;
      const tag = el.tagName;
      const type = (el.type || '').toLowerCase();
      const locator = getLocator(el);
      if (!locator) return;
      if (tag === 'SELECT') {
        window.__pwd_record({ action: 'selectOption', locator, value: el.value });
      } else if (type === 'checkbox' || type === 'radio') {
        window.__pwd_record({ action: el.checked ? 'check' : 'uncheck', locator });
      }
      // Plain text INPUT/TEXTAREA is handled by the debounced 'input'
      // listener above instead, not here — avoids double-recording and
      // works reliably even when blur never fires within the page.
    },
    true
  );

  // ---- Keyboard-driven actions (Tab navigation, Enter/Escape, arrow-key
  // menu navigation, keyboard shortcuts) — recorded as page-level `pressKey`
  // steps with NO locator, since replaying the same key sequence naturally
  // reproduces whatever focus movement happened during recording, exactly
  // like a real user tabbing through the page.
  const NAV_KEYS = new Set([
    'Tab', 'Enter', 'Escape',
    'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight',
    'Home', 'End', 'PageUp', 'PageDown', ' ',
  ]);
  const MODIFIER_KEYS = new Set(['Control', 'Meta', 'Alt', 'Shift']);

  function normalizeKeyName(key) {
    if (key === ' ') return 'Space';
    if (key.length === 1) return key.toUpperCase();
    return key; // Tab, Enter, Escape, ArrowUp, etc. already match Playwright's key names
  }

  function buildKeyCombo(e) {
    const parts = [];
    if (e.ctrlKey) parts.push('Control');
    if (e.metaKey) parts.push('Meta');
    if (e.altKey) parts.push('Alt');
    if (e.shiftKey) parts.push('Shift');
    const mainKey = normalizeKeyName(e.key);
    if (!MODIFIER_KEYS.has(mainKey)) parts.push(mainKey);
    return parts.join('+');
  }

  document.addEventListener(
    'keydown',
    (e) => {
      if (!window.__pwd_record) return;
      if (MODIFIER_KEYS.has(e.key)) return; // a lone modifier keydown isn't an action by itself

      const hasModifier = e.ctrlKey || e.metaKey || e.altKey || e.shiftKey;
      const isNavKey = NAV_KEYS.has(e.key);
      if (!hasModifier && !isNavKey) return; // plain character typing — already captured via 'change' on commit

      const el = e.target;
      const tag = el && el.tagName;
      const editableTypes = ['checkbox', 'radio', 'button', 'submit', 'reset', 'range', 'file', 'color'];
      const isTextEditable =
        el &&
        (tag === 'TEXTAREA' ||
          el.isContentEditable ||
          (tag === 'INPUT' && !editableTypes.includes((el.type || 'text').toLowerCase())));

      // Inside a plain text field, unmodified arrow keys / Home / End / PageUp/Down / Space
      // just move the caret or insert a literal space — not meaningful for replay. Tab,
      // Enter, and Escape are always meaningful (leave the field / submit / cancel) even
      // inside a text field, so they're excluded from this skip.
      const isPureCaretMovement = !hasModifier && isTextEditable && !['Tab', 'Enter', 'Escape'].includes(e.key);
      if (isPureCaretMovement) return;

      window.__pwd_record({ action: 'pressKey', value: buildKeyCombo(e) });
    },
    true
  );
}

async function startRecording({ browserName, baseUrl, onStep, onClosed }) {
  if (currentSession) {
    throw new Error('A recording session is already in progress');
  }

  const launcher = BROWSER_LAUNCHERS[browserName] || chromium;
  const browser = await launcher.launch({ headless: false });
  const context = await browser.newContext({ viewport: null });
  const page = await context.newPage();

  const steps = [];
  const record = (event) => {
    steps.push(event);
    if (onStep) onStep(event);
  };

  await context.exposeFunction('__pwd_record', record);
  await context.addInitScript(injectedRecorderScript);

  page.on('framenavigated', (frame) => {
    if (frame !== page.mainFrame()) return;
    const url = frame.url();
    if (!url || url === 'about:blank') return;
    const last = steps[steps.length - 1];
    if (last && last.action === 'goto' && last.value === url) return;
    record({ action: 'goto', value: url });
  });

  browser.on('disconnected', () => {
    if (currentSession) {
      currentSession = null;
      if (onClosed) onClosed();
    }
  });

  currentSession = { browser, context, page, steps };

  if (baseUrl) {
    await page.goto(baseUrl);
  }

  return { steps };
}

async function stopRecording() {
  if (!currentSession) return { steps: [] };
  const { browser, page, steps } = currentSession;
  currentSession = null;
  try {
    if (page && !page.isClosed()) {
      await page
        .evaluate(() => {
          if (window.__pwd_flushPendingInput) window.__pwd_flushPendingInput();
        })
        .catch(() => {});
    }
  } catch (err) {
    // page may already be gone if the user closed the window manually
  }
  try {
    await browser.close();
  } catch (err) {
    // browser may already be closed if the user closed the window manually
  }
  return { steps };
}

function isRecording() {
  return !!currentSession;
}

module.exports = { startRecording, stopRecording, isRecording };
