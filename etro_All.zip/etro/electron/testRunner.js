const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { screen } = require('electron');
const { writeConfig } = require('./configBuilder');
const dataStore = require('./dataStore');

// Lives under DATA_DIR (project-local in dev, per-user app-data once
// packaged — see dataStore.js) so it's always writable, regardless of
// whether the app itself is installed somewhere read-only.
const RUN_TMP_DIR = path.join(dataStore.DATA_DIR, '.run-tmp');
const EVENT_PREFIX = '__PWD_EVENT__';

// Resolved once, at require time, from *this* running app's own
// node_modules — works whether we're in dev or a packaged build (where
// @playwright/test is unpacked from asar per the electron-builder config).
// Note: @playwright/test's package.json "exports" map only exposes its main
// entry point, not arbitrary subpaths — require.resolve('@playwright/test/cli.js')
// throws ERR_PACKAGE_PATH_NOT_EXPORTED. Resolving via package.json's own
// location (always resolvable) and joining 'cli.js' from there sidesteps that.
const PLAYWRIGHT_CLI_PATH = path.join(
  path.dirname(require.resolve('@playwright/test/package.json')),
  'cli.js'
);

let currentChild = null;

function isRunning() {
  return !!currentChild;
}

function stopRun() {
  if (currentChild) {
    currentChild.kill();
    currentChild = null;
  }
}

/**
 * @param {object} params
 * @param {string[]} params.specFilePaths - absolute paths of the spec JSON files to run
 * @param {function(object):void} params.onEvent - called with each structured event
 * @param {function(number):void} params.onExit - called with the process exit code
 */
function runTests({ specFilePaths, onEvent, onExit }) {
  if (currentChild) {
    throw new Error('A test run is already in progress');
  }

  const settings = dataStore.getSettings();
  const runId = `run_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
  const reportDir = path.join(settings.reportDir || dataStore.REPORTS_DIR, runId);
  fs.mkdirSync(reportDir, { recursive: true });
  fs.mkdirSync(RUN_TMP_DIR, { recursive: true });

  const configPath = path.join(RUN_TMP_DIR, `config-${runId}.js`);
  // Used only when headed + no device + the "override maximized viewport"
  // Settings checkbox is unchecked — video recording needs a concrete size
  // even though the page itself has no fixed viewport in that mode (see
  // configBuilder.js's `useMaximized` logic). workAreaSize excludes the
  // taskbar/dock, closely matching what a maximized window's actual content
  // area will be.
  let maximizedSize;
  try {
    maximizedSize = screen.getPrimaryDisplay().workAreaSize;
  } catch (err) {
    // No display available (e.g. a headless CI machine) — configBuilder.js
    // already has its own sane fallback default if this is undefined.
    maximizedSize = undefined;
  }
  writeConfig({ settings, reportDir, configPath, maximizedSize });

  // Tell the generic-runner.spec.js which specs to load for this run
  const filterFile = path.join(RUN_TMP_DIR, `filter-${runId}.json`);
  fs.writeFileSync(filterFile, JSON.stringify(specFilePaths));

  // Spawn Playwright's own CLI directly through Electron's bundled Node
  // runtime (ELECTRON_RUN_AS_NODE makes the Electron binary behave as plain
  // Node instead of launching a GUI window) instead of `npx playwright
  // test`. This is what lets a packaged, distributed app run tests on a
  // machine that has no npm/Node.js installed at all — only the app itself.
  const child = spawn(process.execPath, [PLAYWRIGHT_CLI_PATH, 'test', '--config', configPath], {
    env: {
      ...process.env,
      ELECTRON_RUN_AS_NODE: '1',
      SPECS_DIR: dataStore.SPECS_DIR,
      SPECS_FILTER_FILE: filterFile,
      PWD_STEP_SCREENSHOTS: settings.stepScreenshots || 'off',
    },
  });
  currentChild = child;

  let stdoutBuffer = '';
  child.stdout.on('data', (chunk) => {
    stdoutBuffer += chunk.toString();
    const lines = stdoutBuffer.split('\n');
    stdoutBuffer = lines.pop(); // keep the last partial line in the buffer

    for (const line of lines) {
      if (line.startsWith(EVENT_PREFIX)) {
        try {
          const event = JSON.parse(line.slice(EVENT_PREFIX.length));
          onEvent(event);
        } catch (err) {
          onEvent({ type: 'raw', message: line });
        }
      } else if (line.trim()) {
        onEvent({ type: 'raw', message: line });
      }
    }
  });

  child.stderr.on('data', (chunk) => {
    const text = chunk.toString().trim();
    if (text) onEvent({ type: 'stderr', message: text });
  });

  child.on('close', (code) => {
    currentChild = null;
    for (const f of [configPath, filterFile]) {
      fs.rm(f, { force: true }, () => {});
    }
    onEvent({
      type: 'process-exit',
      code,
      reportDir,
      htmlReportPath: path.join(reportDir, 'html', 'index.html'),
      jsonResultsPath: path.join(reportDir, 'results.json'),
    });
    onExit(code);
  });

  return { runId, reportDir };
}

module.exports = { runTests, stopRun, isRunning };
