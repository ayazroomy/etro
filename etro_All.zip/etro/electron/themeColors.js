// Mirrors the --bg-toolbar / --text-primary values for each theme in
// renderer/src/styles.css. Native title bar overlay colors (Windows/Linux)
// can't read CSS variables — this is the one place to update if a theme's
// toolbar color ever changes, so the title bar and the in-app toolbar stay
// in sync.
const THEME_TITLEBAR_COLORS = {
  default: { bg: '#26272e', symbol: '#e6e6e6' },
  dark: { bg: '#17181c', symbol: '#e9e9ec' },
  light: { bg: '#ffffff', symbol: '#1c1d21' },
};

const TITLEBAR_OVERLAY_HEIGHT = 40;

function overlayForTheme(themeName) {
  const colors = THEME_TITLEBAR_COLORS[themeName] || THEME_TITLEBAR_COLORS.default;
  return { color: colors.bg, symbolColor: colors.symbol, height: TITLEBAR_OVERLAY_HEIGHT };
}

module.exports = { THEME_TITLEBAR_COLORS, TITLEBAR_OVERLAY_HEIGHT, overlayForTheme };
