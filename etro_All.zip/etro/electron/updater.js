const { app } = require('electron');
const { autoUpdater } = require('electron-updater');

// User confirms each step from the UI rather than updating silently in the
// background — download only starts once they click "Download update", and
// install only happens once they click "Restart & Install".
autoUpdater.autoDownload = false;
autoUpdater.autoInstallOnAppQuit = false;

let wired = false;

function setupAutoUpdater(getMainWindow) {
  if (wired) return; // avoid double-registering listeners if called more than once
  wired = true;

  function send(payload) {
    const win = getMainWindow();
    if (win && !win.isDestroyed()) win.webContents.send('updates:status', payload);
  }

  autoUpdater.on('checking-for-update', () => send({ status: 'checking' }));
  autoUpdater.on('update-available', (info) => send({ status: 'available', version: info.version }));
  autoUpdater.on('update-not-available', (info) => send({ status: 'not-available', version: info.version }));
  autoUpdater.on('download-progress', (progress) =>
    send({ status: 'downloading', percent: Math.round(progress.percent) })
  );
  autoUpdater.on('update-downloaded', (info) => send({ status: 'downloaded', version: info.version }));
  autoUpdater.on('error', (err) =>
    send({ status: 'error', message: err && err.message ? err.message : String(err) })
  );
}

async function checkForUpdates() {
  if (!app.isPackaged) {
    // electron-updater intentionally no-ops (or errors) in a dev/unpackaged run —
    // there's no packaged app.asar + latest.yml to compare against yet.
    return { skipped: true, reason: 'Checking for updates only works in a packaged, installed build — not in `npm run dev`.' };
  }
  await autoUpdater.checkForUpdates();
  return { skipped: false };
}

async function downloadUpdate() {
  await autoUpdater.downloadUpdate();
}

function quitAndInstall() {
  autoUpdater.quitAndInstall();
}

module.exports = { setupAutoUpdater, checkForUpdates, downloadUpdate, quitAndInstall };
