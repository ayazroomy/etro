const { app } = require('electron');

/**
 * Reclaims OS-level keyboard focus for a window. Deliberately just the
 * standard, safe `.focus()` call — an earlier version also toggled
 * `setAlwaysOnTop(true)` → `setAlwaysOnTop(false)` as a "known workaround"
 * for Windows focus-stealing bugs, and called `app.focus({ steal: true })`
 * (a macOS-specific option, meaningless on Windows). Given this function
 * gets called on every dialog close, every confirm/alert, and every modal
 * close, and the reported bug got WORSE (not better) across iterations that
 * added more calls to it, the aggressive always-on-top toggle — repeatedly
 * forcing z-order changes on the window, especially several times in quick
 * succession across a few modal open/close cycles — is a strong suspect for
 * actually being the cause, not the fix. Stripped back to the minimum,
 * standard, well-understood API.
 */
function forceFocus(win) {
  if (!win || win.isDestroyed()) return;
  win.focus();
}

module.exports = { forceFocus };
