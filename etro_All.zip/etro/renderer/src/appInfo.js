// Central place for app branding — update these once and everything (About
// modal, footer, splash screen) picks up the change.
export const APP_NAME = 'ETRO';
export const APP_TAGLINE = 'Visual Playwright Test Studio';

export const TEAM_NAME = 'ETRO Development Team'; // TODO: replace with your real team/company name
export const TEAM_EMAILS = [
  'support@etro.app', // TODO: replace with your real contact email(s)
];

export const REPO_URL = 'https://github.com/yourusername/etro'; // TODO: set your real repo URL

export function copyrightLine() {
  const year = new Date().getFullYear();
  return `© ${year} ${TEAM_NAME}. All rights reserved.`;
}
