import React, { useEffect, useState } from 'react';
import { APP_NAME, APP_TAGLINE, TEAM_NAME, TEAM_EMAILS, REPO_URL, copyrightLine } from '../appInfo.js';
import appIcon from '../assets/icon.png';

function statusText(state) {
  switch (state.status) {
    case 'checking':
      return 'Checking for updates…';
    case 'available':
      return `Update available: v${state.version}`;
    case 'not-available':
      return 'You’re on the latest version.';
    case 'downloading':
      return `Downloading update… ${state.percent ?? 0}%`;
    case 'downloaded':
      return `Update v${state.version} downloaded — restart to install.`;
    case 'error':
      return `Update check failed: ${state.message}`;
    default:
      return null;
  }
}

export default function AboutModal({ onClose }) {
  const [version, setVersion] = useState('…');
  const [packaged, setPackaged] = useState(true);
  const [platform, setPlatform] = useState('');
  const [state, setState] = useState({ status: 'idle' });

  useEffect(() => {
    window.api.getAppVersion().then(setVersion);
    window.api.isPackaged().then(setPackaged);
    setPlatform(navigator.platform.toLowerCase().includes('mac') ? 'mac' : 'other');

    const off = window.api.onUpdateStatus((payload) => setState(payload));
    return off;
  }, []);

  async function handleCheck() {
    setState({ status: 'checking' });
    const result = await window.api.checkForUpdates();
    if (result && result.skipped) {
      setState({ status: 'error', message: result.reason });
    }
    // otherwise, status updates arrive via onUpdateStatus as electron-updater progresses
  }

  async function handleDownload() {
    await window.api.downloadUpdate();
  }

  async function handleInstall() {
    await window.api.installUpdate();
  }

  const text = statusText(state);
  const isMacUnsigned = platform === 'mac'; // see note below — can't detect signing status at runtime

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" style={{ width: 460 }} onClick={(e) => e.stopPropagation()}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 4 }}>
          <img src={appIcon} alt={APP_NAME} style={{ width: 52, height: 52, borderRadius: 12 }} />
          <div>
            <h2 style={{ margin: 0 }}>{APP_NAME}</h2>
            <div style={{ fontSize: 12, color: 'var(--text-faint)' }}>{APP_TAGLINE}</div>
          </div>
        </div>
        <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 10 }}>Version {version}</p>

        {!packaged && (
          <p style={{ fontSize: 12, color: 'var(--text-faint)' }}>
            Running in dev mode — update checks only work in an installed build.
          </p>
        )}

        <div style={{ marginTop: 4 }}>
          {state.status !== 'available' && state.status !== 'downloading' && state.status !== 'downloaded' && (
            <button className="btn" onClick={handleCheck} disabled={!packaged || state.status === 'checking'}>
              {state.status === 'checking' ? 'Checking…' : 'Check for Updates'}
            </button>
          )}

          {state.status === 'available' && (
            <button className="btn btn-primary" onClick={handleDownload}>
              Download update (v{state.version})
            </button>
          )}

          {state.status === 'downloading' && (
            <div style={{ fontSize: 12, color: 'var(--accent-soft)' }}>Downloading… {state.percent ?? 0}%</div>
          )}

          {state.status === 'downloaded' && (
            <button className="btn btn-primary" onClick={handleInstall}>
              Restart &amp; Install v{state.version}
            </button>
          )}

          {text && (
            <p
              style={{
                fontSize: 12,
                color: state.status === 'error' ? 'var(--log-failed)' : 'var(--text-muted)',
                marginTop: 8,
              }}
            >
              {text}
            </p>
          )}

          {isMacUnsigned && (state.status === 'available' || state.status === 'error') && (
            <p style={{ fontSize: 11, color: 'var(--text-faint)', marginTop: 8, lineHeight: 1.5 }}>
              Note: on Mac, in-app download &amp; install only works for a properly
              code-signed build (Apple requires this). If this build is unsigned, use the
              link below to grab the new version manually instead.
            </p>
          )}
        </div>

        <div className="section-title">Team &amp; Support</div>
        <p style={{ fontSize: 13, color: 'var(--text-secondary)', margin: '0 0 4px' }}>{TEAM_NAME}</p>
        {TEAM_EMAILS.map((email) => (
          <p key={email} style={{ fontSize: 12, margin: '2px 0' }}>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                window.api.openExternal(`mailto:${email}`);
              }}
              style={{ color: 'var(--accent-soft)', textDecoration: 'none' }}
            >
              {email}
            </a>
          </p>
        ))}
        <p style={{ fontSize: 11, color: 'var(--text-faint)', marginTop: 10 }}>{copyrightLine()}</p>

        <div className="modal-footer" style={{ justifyContent: 'space-between' }}>
          <button className="btn" onClick={() => window.api.openExternal(`${REPO_URL}/releases`)}>
            View Releases on GitHub
          </button>
          <button className="btn" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}
