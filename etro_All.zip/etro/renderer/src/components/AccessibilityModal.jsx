import React, { useState } from 'react';

const TAG_OPTIONS = [
  { value: 'wcag2a', label: 'WCAG 2.0 Level A' },
  { value: 'wcag2aa', label: 'WCAG 2.0 Level AA' },
  { value: 'wcag2aaa', label: 'WCAG 2.0 Level AAA' },
  { value: 'wcag21a', label: 'WCAG 2.1 Level A' },
  { value: 'wcag21aa', label: 'WCAG 2.1 Level AA' },
  { value: 'wcag22aa', label: 'WCAG 2.2 Level AA' },
  { value: 'best-practice', label: 'Best practices (beyond WCAG)' },
];

export function defaultAccessibilityConfig() {
  return {
    enabled: false,
    includeSelectors: [],
    excludeSelectors: [],
    tags: [],
    failOnViolations: true,
  };
}

function SelectorList({ label, hint, selectors, onChange }) {
  function updateAt(i, value) {
    const next = selectors.slice();
    next[i] = value;
    onChange(next);
  }
  function removeAt(i) {
    const next = selectors.slice();
    next.splice(i, 1);
    onChange(next);
  }
  function add() {
    onChange([...selectors, '']);
  }

  return (
    <div className="field" style={{ marginBottom: 12 }}>
      <label>{label}</label>
      {hint && <p style={{ fontSize: 11, color: 'var(--text-faint)', margin: '0 0 6px' }}>{hint}</p>}
      {selectors.length === 0 && (
        <p style={{ fontSize: 12, color: 'var(--text-faint)', margin: '0 0 6px' }}>None set.</p>
      )}
      {selectors.map((sel, i) => (
        <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 6 }}>
          <input
            type="text"
            placeholder="CSS selector, e.g. #main-content"
            value={sel}
            onChange={(e) => updateAt(i, e.target.value)}
            style={{ flex: 1 }}
          />
          <button className="btn btn-icon" onClick={() => removeAt(i)} title="Remove">✕</button>
        </div>
      ))}
      <button className="btn" onClick={add}>+ Add selector</button>
    </div>
  );
}

export default function AccessibilityModal({ config, onSave, onClose }) {
  const [local, setLocal] = useState({ ...defaultAccessibilityConfig(), ...(config || {}) });

  function set(patch) {
    setLocal((c) => ({ ...c, ...patch }));
  }

  function toggleTag(tag) {
    const set1 = new Set(local.tags || []);
    if (set1.has(tag)) set1.delete(tag);
    else set1.add(tag);
    set({ tags: Array.from(set1) });
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" style={{ width: 620 }} onClick={(e) => e.stopPropagation()}>
        <h2>♿ Accessibility Testing</h2>

        <div className="field-row">
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={!!local.enabled}
              onChange={(e) => set({ enabled: e.target.checked })}
            />
            Run an accessibility scan for this spec
          </label>
        </div>

        <p style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.5 }}>
          Scans the final page state after <strong>all</strong> of this spec's steps have run, using{' '}
          <strong>axe-core</strong> (the same engine behind most browser accessibility devtools).
          Results are attached to this test's entry in the HTML report either way.
        </p>
        <p style={{ fontSize: 12, color: 'var(--log-skipped)', lineHeight: 1.5, background: 'var(--bg-code-block)', borderRadius: 6, padding: '8px 10px' }}>
          ⚠ In a single-page app, an element that only exists briefly — a modal that
          gets closed, a toast that disappears — may already be gone by the time this
          runs, since it always happens last. For that, add an{' '}
          <strong>Accessibility Scan</strong> <em>step</em> instead, right after the step
          that reveals the element you want checked — it scans immediately, at that exact
          point in the sequence, and can be added more than once per spec. Note that the
          scan itself takes a moment to inject and run, so this still won't reliably catch
          something that disappears within roughly a second.
        </p>

        {local.enabled && (
          <>
            <div className="section-title">Scope</div>
            <SelectorList
              label="Only scan these elements (optional)"
              hint="Leave empty to scan the whole page. If set, only these elements (and their contents) are scanned."
              selectors={local.includeSelectors || []}
              onChange={(v) => set({ includeSelectors: v })}
            />
            <SelectorList
              label="Exclude these elements (optional)"
              hint="Skipped even if they'd otherwise be included — useful for third-party widgets/ads you don't control."
              selectors={local.excludeSelectors || []}
              onChange={(v) => set({ excludeSelectors: v })}
            />

            <div className="section-title">Rules</div>
            <p style={{ fontSize: 11, color: 'var(--text-faint)', margin: '0 0 6px' }}>
              Limit the scan to specific WCAG conformance levels. Leave all unchecked to run axe's
              full default rule set.
            </p>
            <div className="checkbox-row" style={{ flexWrap: 'wrap' }}>
              {TAG_OPTIONS.map((t) => (
                <label key={t.value}>
                  <input
                    type="checkbox"
                    checked={(local.tags || []).includes(t.value)}
                    onChange={() => toggleTag(t.value)}
                  />
                  {t.label}
                </label>
              ))}
            </div>

            <div className="section-title">Behavior</div>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={local.failOnViolations !== false}
                onChange={(e) => set({ failOnViolations: e.target.checked })}
              />
              Fail this test if violations are found
              <span style={{ fontSize: 11, color: 'var(--text-faint)', fontWeight: 400 }}>
                (unticked: violations are still reported and attached, but don't fail the run)
              </span>
            </label>
          </>
        )}

        <div className="modal-footer">
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={() => onSave(local)}>Save</button>
        </div>
      </div>
    </div>
  );
}
