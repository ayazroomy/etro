import React from 'react';

export default function CollectionTree({
  collections,
  specsByCollection,
  activeSpecId,
  selectedIds,
  onSelectSpec,
  onToggleChecked,
  onDeleteSpec,
  onDeleteCollection,
  onImportSpec,
  onExportCollection,
  onImportCollection,
}) {
  return (
    <div>
      <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
        <button className="btn" style={{ flex: 1 }} onClick={onImportSpec}>
          ⭳ Import Spec(s)…
        </button>
      </div>
      <button className="btn" style={{ width: '100%', marginBottom: 14 }} onClick={onImportCollection}>
        ⭳ Import Collection…
      </button>

      {collections.map((col) => {
        const specs = specsByCollection[col.id] || [];
        return (
          <div className="collection" key={col.id}>
            <div className="collection-header">
              <span style={{ flex: 1 }}>{col.name}</span>
              <button
                className="btn btn-icon"
                style={{ padding: '2px 6px', fontSize: 11 }}
                title="Export collection"
                onClick={() => onExportCollection(col.id)}
              >
                ⭱
              </button>
              {col.id !== 'default' && (
                <button
                  className="btn btn-icon"
                  style={{ padding: '2px 6px', fontSize: 11 }}
                  title="Delete collection"
                  onClick={() => onDeleteCollection(col.id)}
                >
                  ✕
                </button>
              )}
            </div>

            {specs.length === 0 && (
              <div style={{ fontSize: 12, color: 'var(--text-very-faint)', padding: '4px 8px' }}>
                No specs yet
              </div>
            )}

            {specs.map((spec) => (
              <div
                key={spec.id}
                className={`spec-item ${activeSpecId === spec.id ? 'active' : ''}`}
              >
                <input
                  type="checkbox"
                  checked={!!selectedIds[spec.id]}
                  onChange={() => onToggleChecked(spec)}
                  onClick={(e) => e.stopPropagation()}
                />
                <span style={{ flex: 1 }} onClick={() => onSelectSpec(spec)}>
                  {spec.name || '(untitled)'}
                </span>
                <button
                  className="btn btn-icon"
                  style={{ padding: '1px 6px', fontSize: 11 }}
                  title="Delete spec"
                  onClick={() => onDeleteSpec(spec)}
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        );
      })}
    </div>
  );
}
