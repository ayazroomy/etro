import React from 'react';

// Deliberately does NOT close on backdrop click or Escape — this is the
// whole point of replacing window.confirm()/window.alert() with a React
// modal: those are Chromium-native blocking dialogs with a well-documented
// class of Electron focus-return bugs, while a pure React modal (verified
// directly by comparing against PromptModal, which never showed the issue)
// doesn't have that problem. Making this one dismissible via backdrop/Escape
// would be a minor UX nicety but risks the user accidentally dismissing a
// destructive confirmation (e.g. "Delete this collection?") without meaning
// to, so it requires an explicit button click either way.
export default function ConfirmModal({
  title,
  message,
  showCancel = true,
  confirmLabel = 'OK',
  cancelLabel = 'Cancel',
  onConfirm,
  onCancel,
}) {
  return (
    <div className="modal-backdrop">
      <div className="modal" style={{ width: 440 }} onClick={(e) => e.stopPropagation()}>
        <h2>{title || 'ETRO'}</h2>
        <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
          {message}
        </p>
        <div className="modal-footer">
          {showCancel && (
            <button className="btn" onClick={onCancel}>
              {cancelLabel}
            </button>
          )}
          <button className="btn btn-primary" onClick={onConfirm} autoFocus>
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
