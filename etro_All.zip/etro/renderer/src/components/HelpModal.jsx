import React, { useState } from 'react';
import { ACTIONS, LOCATOR_TYPES } from '../actionMeta.js';

function Code({ children }) {
  return (
    <code
      style={{
        background: 'var(--bg-code-block)',
        borderRadius: 4,
        padding: '1px 6px',
        fontSize: 12,
        fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
      }}
    >
      {children}
    </code>
  );
}

function Example({ children }) {
  return (
    <div
      style={{
        background: 'var(--bg-code-block)',
        borderRadius: 6,
        padding: '8px 10px',
        fontSize: 12,
        fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
        color: 'var(--text-muted)',
        marginTop: 4,
        whiteSpace: 'pre-wrap',
      }}
    >
      {children}
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 6 }}>{title}</div>
      {children}
    </div>
  );
}

function Entry({ name, desc, example }) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ fontSize: 12.5 }}>
        <Code>{name}</Code> — <span style={{ color: 'var(--text-muted)' }}>{desc}</span>
      </div>
      {example && <Example>{example}</Example>}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Tab 1: Features
// ---------------------------------------------------------------------------
function FeaturesTab() {
  return (
    <div style={{ fontSize: 13, lineHeight: 1.6 }}>
      <Section title="Authoring tests — no code required">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li>Build test cases visually — every step is a form, not hand-written code.</li>
          <li>Organize tests into collections, each holding any number of specs (test cases).</li>
          <li>9 locator types (Test ID, Role, Text, Label, Placeholder, Alt text, Title, CSS, XPath) covering how to find any element.</li>
          <li>30+ actions: navigation, clicking/typing/form controls, keyboard, waiting, assertions, screenshots, API calls, data extraction, sessions, and conditional branching.</li>
          <li>Conditional steps (if/else) with fully nested, visually-editable branches — no JSON editing needed even for branching logic.</li>
          <li>Disable any step with one click to temporarily skip it without deleting it.</li>
          <li>Insert a new step immediately after any existing step, not just at the end.</li>
          <li>A raw JSON view of any spec, for direct editing or copy/paste, alongside the visual editor.</li>
        </ul>
      </Section>

      <Section title="Accessibility testing">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li>Powered by axe-core (the same engine behind most browser accessibility devtools).</li>
          <li>Spec-level: scans the final page state after all of a spec's steps have run — the simple option for a page's end state.</li>
          <li>Step-level: an insertable "Accessibility Scan" step that runs immediately, wherever it's placed — for single-page apps where a modal or other transient element needs checking before it disappears.</li>
          <li>Either way: scope to the whole page or specific elements, filter by WCAG conformance level (2.0/2.1/2.2, A/AA/AAA) and best practices, and choose whether violations fail the test — results attach to that test's entry in the same HTML report, as a styled HTML summary and the full raw data.</li>
        </ul>
      </Section>

      <Section title="Data-driven testing">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li>A Variables table per spec, plus an optional external JSON test-data file — both accessible anywhere via <Code>{'{{variable}}'}</Code>.</li>
          <li>API request steps (GET/POST/PUT/PATCH/DELETE) with headers, body, and response extraction by JSON path and/or regex.</li>
          <li>Extract text from the page, or a value from localStorage, into a variable for later steps.</li>
          <li>Save and reuse browser sessions (cookies/storage) — log in once, start other specs already authenticated.</li>
        </ul>
      </Section>

      <Section title="Recording">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li>Record real interactions in a real, visible browser — clicks, typing, checkboxes, dropdowns, navigation, and keyboard shortcuts are all captured live as steps.</li>
          <li>Automatic locator selection follows the same best-practices priority Playwright itself recommends (explained in the How to Use tab), rather than defaulting to fragile CSS selectors.</li>
          <li>Stop & Review converts the recording into an editable spec you can refine and save like any other.</li>
        </ul>
      </Section>

      <Section title="Running tests">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li>Run the spec currently open, a checkbox-selected subset, or every saved spec at once.</li>
          <li>Chromium, Firefox, and WebKit — select any combination to run across simultaneously.</li>
          <li>Mobile device emulation (iPhone, Pixel, iPad, Galaxy, etc.) or a manually configured viewport.</li>
          <li>Headless or headed (visible) execution — headed mode opens maximized by default, with an opt-out to a custom viewport.</li>
          <li>Configurable screenshots (end-of-test and/or per-step), video, and trace capture.</li>
          <li>A global timeout, retry count, and worker count in Settings — plus a per-spec timeout override for tests that need more or less time than the rest.</li>
          <li>A live run log streamed step-by-step while a run is in progress, plus a generated HTML report afterward.</li>
        </ul>
      </Section>

      <Section title="Organizing & sharing">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li>Export a single spec or a whole collection to a JSON file; import it back in on any machine running the app.</li>
          <li>Light, dark, and default themes.</li>
          <li>Built-in update checking (About panel), when the app is distributed as a signed, published build.</li>
        </ul>
      </Section>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Tab 2: How to Use
// ---------------------------------------------------------------------------
const LOCATOR_HELP = {
  testid: {
    desc: "Matches an element's data-testid attribute — the most stable option there is, since it's added deliberately for automation and won't shift when copy or styling changes.",
    example: 'Element:  <button data-testid="submit-btn">\nLocator:  Test ID = submit-btn',
  },
  role: {
    desc: 'Matches by ARIA role plus its accessible name (visible text, aria-label, or associated label) — how a screen reader perceives the element. Playwright\'s own top recommendation.',
    example: 'Element:  <button>Add to Cart</button>\nLocator:  Role = button, Name = Add to Cart',
  },
  text: {
    desc: 'Matches an element containing this visible text anywhere on the page.',
    example: 'Locator:  Text = "Add to Cart"',
  },
  label: {
    desc: "Matches a form field by its associated <label> text, or an element's aria-label attribute directly.",
    example: 'Element:  <label for="email">Email Address</label><input id="email">\nLocator:  Label = Email Address',
  },
  placeholder: {
    desc: 'Matches an input by its placeholder text — useful when there is no visible label.',
    example: 'Element:  <input placeholder="Search products...">\nLocator:  Placeholder = Search products...',
  },
  altText: {
    desc: "Matches an image by its alt attribute.",
    example: 'Element:  <img alt="Company Logo">\nLocator:  Alt text = Company Logo',
  },
  title: {
    desc: 'Matches an element by its title attribute (the small tooltip text shown on hover).',
    example: 'Element:  <button title="Close dialog">\nLocator:  Title attr = Close dialog',
  },
  css: {
    desc: 'Any valid CSS selector — the most flexible option, and the right choice when nothing above applies, but also the option most likely to break if the page structure changes.',
    example: 'Locator:  CSS selector = #login-form input[name="email"]',
  },
  xpath: {
    desc: 'Any valid XPath expression — useful for cases CSS alone can\'t express, like matching by text content up the DOM tree.',
    example: 'Locator:  XPath = //button[text()="Save"]',
  },
};

const ACTION_GROUPS = [
  {
    title: 'Navigation',
    names: ['goto', 'goBack', 'goForward', 'reload', 'waitForUrl', 'waitForLoadState'],
    help: {
      goto: { desc: 'Navigates to a URL or path.', example: 'Value: https://example.com/checkout' },
      goBack: { desc: 'Goes back one page in browser history.' },
      goForward: { desc: 'Goes forward one page in browser history.' },
      reload: { desc: 'Reloads the current page.' },
      waitForUrl: { desc: 'Waits until the URL matches (exact string by default — tick "Treat as regex" for partial matching, e.g. matching just a query parameter).', example: 'Value: **checkout/confirm  ->  turn on "Treat as regex" and use:  confirm$' },
      waitForLoadState: { desc: 'Waits for a load state.', example: 'Value: networkidle' },
    },
  },
  {
    title: 'Clicking, typing & form controls',
    names: ['click', 'dblclick', 'fill', 'type', 'press', 'pressKey', 'check', 'uncheck', 'selectOption', 'hover', 'focus', 'setInputFiles', 'scrollIntoView'],
    help: {
      click: { desc: 'Clicks the located element.' },
      dblclick: { desc: 'Double-clicks the located element.' },
      fill: { desc: 'Clears the field and sets its value instantly (no keystroke events).', example: 'Locator: Test ID = email-field\nValue: user@example.com' },
      type: { desc: 'Types the value character by character, firing real keystroke events — use this over "fill" when the page reacts to individual keystrokes (autocomplete, live validation).' },
      press: { desc: 'Presses a key while the located element has focus.', example: 'Locator: Test ID = search-box\nValue: Enter' },
      pressKey: { desc: 'Presses a key or combo on whatever currently has focus — no locator needed.', example: 'Value: Control+A' },
      check: { desc: 'Checks a checkbox or radio button.' },
      uncheck: { desc: 'Unchecks a checkbox.' },
      selectOption: { desc: 'Chooses an option in a <select> dropdown by its value.', example: 'Locator: CSS selector = select[name="country"]\nValue: US' },
      hover: { desc: 'Hovers the mouse over the element (useful for revealing hover menus/tooltips before a later step).' },
      focus: { desc: 'Focuses the element without clicking or typing.' },
      setInputFiles: { desc: 'Sets a file input\'s value to a local file path.', example: 'Value: C:\\Users\\you\\Documents\\resume.pdf' },
      scrollIntoView: { desc: 'Scrolls the element into the visible viewport.' },
    },
  },
  {
    title: 'Waiting',
    names: ['waitForSelector', 'waitForTimeout'],
    help: {
      waitForSelector: { desc: 'Waits for the located element to appear (useful before interacting with something that loads dynamically).' },
      waitForTimeout: { desc: 'Waits a fixed number of milliseconds. Prefer waitForSelector/waitForUrl/waitForLoadState where possible — a fixed wait is the least reliable way to handle timing.', example: 'Value: 1000' },
    },
  },
  {
    title: 'Assertions',
    names: ['assertVisible', 'assertHidden', 'assertText', 'assertContainsText', 'assertValue', 'assertCount', 'assertEnabled', 'assertDisabled', 'assertChecked', 'assertUrl', 'assertTitle'],
    help: {
      assertVisible: { desc: 'Fails the test unless the located element is visible.' },
      assertHidden: { desc: 'Fails the test unless the located element is hidden or absent.' },
      assertText: { desc: 'Fails unless the element\'s text matches exactly.', example: 'Value: Order Confirmed' },
      assertContainsText: { desc: 'Fails unless the element\'s text contains this substring.', example: 'Value: Confirmed' },
      assertValue: { desc: 'Fails unless a form field\'s value matches exactly.' },
      assertCount: { desc: 'Fails unless exactly this many elements match the locator — the one assertion that sees every match, not just the first.', example: 'Locator: CSS selector = .cart-item\nValue: 3' },
      assertEnabled: { desc: 'Fails unless the element is enabled.' },
      assertDisabled: { desc: 'Fails unless the element is disabled.' },
      assertChecked: { desc: 'Fails unless a checkbox/radio is checked.' },
      assertUrl: { desc: 'Fails unless the URL matches (exact string by default — tick "Treat as regex" for partial matching).', example: 'Value: https://example.com/checkout' },
      assertTitle: { desc: 'Fails unless the page title matches exactly.' },
    },
  },
  {
    title: 'Data, variables & external APIs',
    names: ['apiRequest', 'extractText', 'extractLocalStorage', 'setVariable'],
    help: {
      apiRequest: {
        desc: 'Calls an external API. Optionally extract a value from the JSON response — by dotted path, by regex, or a path first then a regex within that field — and save it as a variable for later steps.',
        example:
          'Method: GET\nURL: https://api.example.com/user/me\nExtract path: data.user.id\nSave as: userId\n\nLater step value:  Welcome, {{userId}}',
      },
      extractText: { desc: "Reads the located element's text into a variable.", example: 'Locator: CSS selector = #order-number\nSave as: orderNumber' },
      extractLocalStorage: { desc: 'Reads a localStorage key into a variable.', example: 'Value: authToken\nSave as: token' },
      setVariable: { desc: 'Sets a variable directly, optionally built from other variables.', example: 'Value: {{firstName}} {{lastName}}\nSave as: fullName' },
    },
  },
  {
    title: 'Sessions',
    names: ['saveSession'],
    help: {
      saveSession: {
        desc: "Saves the browser's current cookies and storage under a name, so another spec can start already logged in — pick it from the spec header's \"Start from saved session\" dropdown.",
        example: 'Value: logged-in-admin',
      },
    },
  },
  {
    title: 'Conditional branching',
    names: ['conditional'],
    help: {
      conditional: {
        desc: 'Runs one set of steps if a condition is true, and optionally a different set if it\'s false. Conditions can check an element (visible, hidden, exists, checked, contains text, ...) or a variable (equals a value, or is simply truthy). Branches are fully editable step lists, including further nested conditionals.',
        example:
          'Condition: visible\nLocator: CSS selector = .premium-badge\nIf true:  fill "Welcome, premium member"\nIf false: fill "Upgrade to premium"',
      },
    },
  },
  {
    title: 'Other',
    names: ['screenshot'],
    help: {
      screenshot: { desc: 'Saves a screenshot to a file path at this point in the test — separate from the automatic end-of-test/per-step capture configured in Settings.', example: 'Value: C:\\temp\\checkout-page.png' },
    },
  },
];

function HowToUseTab() {
  const [open, setOpen] = useState('quickstart');
  function toggle(key) {
    setOpen((prev) => (prev === key ? null : key));
  }
  function CollapsibleSection({ id, title, children }) {
    const isOpen = open === id;
    return (
      <div style={{ marginBottom: 8, border: '1px solid var(--border-color)', borderRadius: 8 }}>
        <button
          onClick={() => toggle(id)}
          style={{
            width: '100%',
            textAlign: 'left',
            background: 'none',
            border: 'none',
            color: 'var(--text-primary)',
            fontSize: 13,
            fontWeight: 700,
            padding: '10px 12px',
            cursor: 'pointer',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          {title}
          <span style={{ color: 'var(--text-faint)', fontWeight: 400 }}>{isOpen ? '−' : '+'}</span>
        </button>
        {isOpen && <div style={{ padding: '0 12px 12px', fontSize: 13, lineHeight: 1.6 }}>{children}</div>}
      </div>
    );
  }

  return (
    <div>
      <CollapsibleSection id="quickstart" title="Quick start">
        <ol style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li>Click <strong>+ New Collection</strong> to create somewhere to keep your tests (or use the Default collection).</li>
          <li>Click <strong>+ New Spec</strong>, give it a name and, if the site needs one, a Base URL.</li>
          <li>Add steps one at a time — pick an Action, a Locator type + value if needed, and a Value if needed.</li>
          <li>Click <strong>Save spec</strong>, then <strong>▶ Run</strong>. Watch the live log on the right as it executes.</li>
          <li>Not sure what to click? Try <strong>● Record</strong> instead — perform the actions in a real browser and let it write the steps for you.</li>
        </ol>
      </CollapsibleSection>

      <CollapsibleSection id="locators" title="Locators — how to find an element">
        <p style={{ color: 'var(--text-muted)', marginTop: 0 }}>
          Every locator-based step needs a <strong>Locator type</strong> and <strong>Locator value</strong> (Role also
          needs a Name). If a locator matches more than one element, the <strong>first match is used
          automatically</strong> — no error, no extra configuration needed. <Code>assertCount</Code> is the one
          exception, since it specifically needs to see every match.
        </p>
        {LOCATOR_TYPES.map((lt) => (
          <Entry key={lt.value} name={lt.label} desc={LOCATOR_HELP[lt.value]?.desc} example={LOCATOR_HELP[lt.value]?.example} />
        ))}
      </CollapsibleSection>

      {ACTION_GROUPS.map((group) => (
        <CollapsibleSection key={group.title} id={`actions-${group.title}`} title={`Actions — ${group.title}`}>
          {group.names.map((name) => {
            const meta = ACTIONS.find((a) => a.name === name);
            const help = group.help[name] || {};
            return <Entry key={name} name={meta ? meta.name : name} desc={help.desc} example={help.example} />;
          })}
        </CollapsibleSection>
      ))}

      <CollapsibleSection id="variables" title="Variables & data-driven testing">
        <p style={{ color: 'var(--text-muted)', marginTop: 0 }}>
          Use <Code>{'{{name}}'}</Code> in almost any field (Base URL, step values, API URLs/bodies) to insert a
          variable. Variables come from three places, all merged together and usable interchangeably:
        </p>
        <ul style={{ color: 'var(--text-muted)', paddingLeft: 18 }}>
          <li>The spec's own <strong>Variables</strong> table (name/value pairs, seeded before the first step runs).</li>
          <li>
            An external <strong>Test Data JSON file</strong> — its contents are available under <Code>{'{{testData...}}'}</Code>,
            including nested paths, e.g. <Code>{'{{testData.user.email}}'}</Code> for <Code>{'{ "user": { "email": "..." } }'}</Code>.
            Read fresh from disk on every run, so editing the file doesn't require re-saving the spec.
          </li>
          <li>
            Steps that extract data — <Code>apiRequest</Code>, <Code>extractText</Code>, <Code>extractLocalStorage</Code>,{' '}
            <Code>setVariable</Code> — add to or overwrite these as the test runs, so a value pulled from an API
            response in step 2 can be used in step 5.
          </li>
        </ul>
      </CollapsibleSection>

      <CollapsibleSection id="steps" title="Managing steps">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li><strong>⏸ / ▶</strong> — disable or re-enable a step. A disabled step is skipped entirely when the spec runs, but stays in place so you don't lose it.</li>
          <li><strong>↑ / ↓</strong> — move a step up or down.</li>
          <li><strong>+</strong> — insert a new empty step immediately after this one.</li>
          <li><strong>✕</strong> — delete this step.</li>
          <li><strong>{'{ } Show Spec'}</strong> — view or hand-edit the spec as raw JSON.</li>
        </ul>
      </CollapsibleSection>

      <CollapsibleSection id="running" title="Running & reports">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li>Tick specs in the left panel to run just that subset — otherwise <strong>▶ Run</strong> runs the spec currently open in the editor, or every saved spec if none is open.</li>
          <li>The Run Log panel streams each step's pass/fail live as the run happens.</li>
          <li>After a run, <strong>Open Last HTML Report</strong> opens Playwright's own detailed report (with screenshots/video/trace attached, if enabled in Settings).</li>
        </ul>
      </CollapsibleSection>

      <CollapsibleSection id="accessibility" title="Accessibility testing">
        <p style={{ color: 'var(--text-muted)', marginTop: 0 }}>
          There are two ways to run an accessibility scan, depending on what you need to check.
        </p>

        <p style={{ color: 'var(--text-primary)', fontWeight: 600, marginBottom: 4 }}>
          Spec-level (♿ Accessibility Testing button in the spec header)
        </p>
        <p style={{ color: 'var(--text-muted)', marginTop: 0 }}>
          Runs once, automatically, after <strong>all</strong> of the spec's steps finish — checking
          whatever the page looks like at that point. The simplest option for checking a page's final
          state.
        </p>
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li><strong>Only scan these elements</strong> — one or more CSS selectors; leave empty to scan the whole page.</li>
          <li><strong>Exclude these elements</strong> — CSS selectors to skip even if included, e.g. a third-party widget you don't control.</li>
          <li><strong>Rules</strong> — tick specific WCAG conformance levels to limit the scan to those, or leave all unticked to run axe-core's full default rule set.</li>
          <li><strong>Fail this test if violations are found</strong> — on by default. Turn off to still get the report without failing the run.</li>
        </ul>

        <p style={{ color: 'var(--text-primary)', fontWeight: 600, marginTop: 14, marginBottom: 4 }}>
          Step-level ("Accessibility Scan" action, insertable anywhere)
        </p>
        <p style={{ color: 'var(--text-muted)', marginTop: 0 }}>
          Runs immediately, at that exact point in the step sequence — the fix for single-page apps
          where something you need to check (a modal, a toast) is only on screen briefly and would
          already be gone by the time an end-of-spec scan gets to it. Insert it right after the step
          that reveals the element. Same include/exclude/tags/fail options as above, plus it can be
          added more than once per spec. The scan itself still takes a moment to inject and run, so
          it won't reliably catch something that disappears within roughly a second of the step running.
        </p>

        <p style={{ color: 'var(--text-muted)', marginTop: 14 }}>
          Either way, results attach to that test's entry in the same HTML report as everything else
          — a styled HTML summary and the full raw JSON. The scan itself also shows up as its own
          step ("Accessibility scan") in the live run log.
        </p>
      </CollapsibleSection>

      <CollapsibleSection id="settings" title="Settings, explained">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li><strong>Appearance → Theme</strong> — Default, Light, or Dark.</li>
          <li><strong>Browsers</strong> — tick any combination of Chromium/Firefox/WebKit to run against; "Install Selected Browsers" downloads the actual binaries (needed once after installing the app).</li>
          <li><strong>Device emulation</strong> — pick a real device profile (viewport, user agent, touch support) instead of a manual viewport.</li>
          <li><strong>Viewport</strong> — manual Width/Height, used when no device is selected. In headed mode, the browser opens maximized by default instead of at this fixed size — tick "Use a custom viewport instead of maximized" to force this size even when headed.</li>
          <li><strong>Capture</strong> — screenshots (end-of-test and/or per-step), video, and trace, each Off / On / conditional.</li>
          <li><strong>Execution</strong> — Headless vs Headed, global Timeout, Retries, and Workers (parallel execution).</li>
          <li><strong>HTML report location</strong> — where generated reports are written.</li>
        </ul>
      </CollapsibleSection>

      <CollapsibleSection id="sharing" title="Import, export & sessions">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li><strong>Import Spec(s)…</strong> / <strong>Import Collection…</strong> — load JSON files exported from this app (yours or a teammate's).</li>
          <li>Each spec and each collection has its own Export, producing a JSON file you can share or back up.</li>
          <li><strong>saveSession</strong> steps + the spec header's "Start from saved session" dropdown let a login flow run once and every other spec start already authenticated.</li>
        </ul>
      </CollapsibleSection>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Tab 3: Limitations
// ---------------------------------------------------------------------------
function LimitationsTab() {
  return (
    <div style={{ fontSize: 13, lineHeight: 1.6 }}>
      <Section title="Recording">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li>Locator selection during recording is heuristic-based best-effort — it follows Playwright's documented priorities and specifically avoids common auto-generated id/class patterns, but isn't guaranteed to pick the ideal locator on every site or framework. Review recorded steps before relying on them.</li>
          <li>The recorder captures clicks, typed text, checkboxes/radios, dropdown selection, navigation, and common keyboard shortcuts. It does not capture drag-and-drop, canvas/WebGL interactions, multi-touch gestures, or interactions inside cross-origin iframes.</li>
          <li>Recording happens in one real browser window at a time — there's no multi-tab or multi-window recording.</li>
        </ul>
      </Section>

      <Section title="Browser support nuances">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li>Maximized-by-default headed windows, and custom launch window sizing, are Chromium-only. Firefox and WebKit headed windows open at their own default size regardless of the Viewport/maximize settings — this is cosmetic only and doesn't affect what a test does or its results.</li>
          <li>This is a deliberate choice, not an oversight — Firefox specifically was tried twice with documented, standard command-line flags, and both attempts caused it to open a spurious second window instead of resizing correctly, so custom sizing was removed for it entirely rather than risk a third broken attempt.</li>
        </ul>
      </Section>

      <Section title="Data & security">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li>There is no built-in secrets manager. Passwords, tokens, and other sensitive values placed in steps, the Variables table, or a test-data JSON file are stored as plain text on disk.</li>
          <li>Specs, collections, sessions, and settings are all stored locally on the machine running the app — there is no cloud sync or built-in team collaboration. Sharing means exporting and sending a JSON file.</li>
        </ul>
      </Section>

      <Section title="Testing capabilities not (yet) included">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li>No visual regression / pixel-diff screenshot comparison.</li>
          <li>No native mobile app testing — device emulation here means a mobile browser viewport/user-agent, not a real iOS/Android app.</li>
          <li>No database/SQL step type — data-driven testing is limited to the Variables table, a JSON test-data file, and API request steps.</li>
          <li>No built-in email/SMS/2FA interaction helpers.</li>
          <li>No step-level retry — retries (in Settings) re-run the whole spec, not an individual failing step.</li>
          <li>No undo/redo in the step editor.</li>
          <li>Plain wildcard/glob URL patterns (e.g. <Code>**/checkout</Code>) are intentionally not supported for <Code>assertUrl</Code>/<Code>waitForUrl</Code> — they proved unreliable in testing. Use an exact URL, or tick "Treat as regex" for partial matching.</li>
          <li>The insertable Accessibility Scan step still takes a moment to inject and run — it won't reliably catch an element that disappears within roughly a second of that step running.</li>
          <li>Automated accessibility scanning (axe-core, like any automated tool) catches a meaningful subset of WCAG issues — things like missing alt text, poor color contrast, or missing form labels — but can't catch everything a manual audit would (e.g. whether alt text is actually meaningful, or a genuinely sensible tab order). Treat it as a useful baseline, not a full audit.</li>
        </ul>
      </Section>

      <Section title="Operational">
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--text-muted)' }}>
          <li>No built-in CI/scheduling integration (cron, remote trigger, etc.) — the app is designed to be run interactively.</li>
          <li>Auto-update requires the distributed build to be properly code-signed and published; an unsigned/local build won't self-update and needs manual reinstallation for new versions.</li>
          <li>No cross-spec dependency/ordering system beyond manually chaining specs via a shared saved session.</li>
        </ul>
      </Section>
    </div>
  );
}

// ---------------------------------------------------------------------------
export default function HelpModal({ onClose }) {
  const [tab, setTab] = useState('features');

  const tabs = [
    { id: 'features', label: 'Features', render: FeaturesTab },
    { id: 'howto', label: 'How to Use', render: HowToUseTab },
    { id: 'limitations', label: 'Limitations', render: LimitationsTab },
  ];
  const ActiveTab = tabs.find((t) => t.id === tab).render;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" style={{ width: 780, maxWidth: '92vw' }} onClick={(e) => e.stopPropagation()}>
        <h2>Help &amp; Documentation</h2>

        <div style={{ display: 'flex', gap: 4, borderBottom: '1px solid var(--border-color)', marginBottom: 16 }}>
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              style={{
                background: 'none',
                border: 'none',
                borderBottom: tab === t.id ? '2px solid var(--accent)' : '2px solid transparent',
                color: tab === t.id ? 'var(--text-primary)' : 'var(--text-faint)',
                fontSize: 13,
                fontWeight: tab === t.id ? 700 : 500,
                padding: '8px 14px',
                cursor: 'pointer',
                marginBottom: -1,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div style={{ maxHeight: '60vh', overflowY: 'auto', paddingRight: 4 }}>
          <ActiveTab />
        </div>

        <div className="modal-footer">
          <button className="btn btn-primary" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}
