import React, { useState } from 'react';

function cleanForDisplay(spec) {
  const copy = { ...spec };
  delete copy.__filePath; // internal, not part of the spec's own data
  return copy;
}

export default function JsonEditorModal({ spec, onSave, onClose }) {
  const [text, setText] = useState(() => JSON.stringify(cleanForDisplay(spec), null, 2));
  const [error, setError] = useState(null);

  function handleSave() {
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch (err) {
      setError(`Invalid JSON: ${err.message}`);
      return;
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      setError('The spec must be a JSON object, e.g. { "name": ..., "steps": [...] }.');
      return;
    }
    if (!Array.isArray(parsed.steps)) {
      setError('The spec must include a "steps" array (it can be empty: "steps": []).');
      return;
    }
    setError(null);
    onSave(parsed);
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" style={{ width: 640 }} onClick={(e) => e.stopPropagation()}>
        <h2>Edit Spec JSON</h2>
        <p style={{ fontSize: 12, color: '#9a9ba5', marginTop: -6, lineHeight: 1.5 }}>
          This is the exact test case that gets saved to disk and run. Saving here updates
          the form view and writes the spec file immediately — same as clicking "Save spec".
          Note: clearing <code>id</code> or changing <code>collectionId</code> saves this as a{' '}
          <em>new</em> spec file rather than updating the current one.
        </p>
        <textarea
          rows={22}
          style={{
            width: '100%',
            fontFamily: "'SFMono-Regular', Consolas, Menlo, monospace",
            fontSize: 12,
            lineHeight: 1.5,
          }}
          value={text}
          onChange={(e) => setText(e.target.value)}
          spellCheck={false}
        />
        {error && <p style={{ color: '#ff8787', fontSize: 12, marginTop: 6 }}>{error}</p>}
        <div className="modal-footer">
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={handleSave}>Save</button>
        </div>
      </div>
    </div>
  );
}
