import React, { useEffect, useRef } from 'react';

function lineClass(entry) {
  if (entry.kind === 'test-end') return entry.status;
  if (entry.kind === 'step') return 'step';
  if (entry.kind === 'stderr') return 'stderr';
  return 'meta';
}

function formatEntry(entry) {
  switch (entry.kind) {
    case 'run-start':
      return `▶ Run started — ${entry.total} test(s) queued`;
    case 'test-start':
      return `— ${entry.title}`;
    case 'step':
      return `    · ${entry.title}${entry.error ? `  ✗ ${entry.error}` : ''}`;
    case 'test-end':
      return `${entry.status === 'passed' ? '✓' : entry.status === 'skipped' ? '↷' : '✗'} ${entry.title} (${entry.durationMs}ms)${
        entry.error ? `\n      ${entry.error}` : ''
      }`;
    case 'run-end':
      return `■ Run finished — ${entry.status}`;
    case 'stderr':
      return entry.message;
    case 'raw':
      return entry.message;
    default:
      return JSON.stringify(entry);
  }
}

export default function LogPanel({ entries, running, onClear }) {
  const listRef = useRef(null);

  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
    }
  }, [entries]);

  return (
    <>
      <div className="log-header">
        <span style={{ flex: 1 }}>
          Run Log {running && <span style={{ color: '#69db7c' }}>● running</span>}
        </span>
        <button className="btn btn-icon" style={{ padding: '3px 8px' }} onClick={onClear}>
          Clear
        </button>
      </div>
      <div className="log-list" ref={listRef}>
        {entries.length === 0 && (
          <div className="log-line meta">No output yet. Select tests and click Run.</div>
        )}
        {entries.map((entry, i) => (
          <div key={i} className={`log-line ${lineClass(entry)}`}>
            {formatEntry(entry)}
          </div>
        ))}
      </div>
    </>
  );
}
