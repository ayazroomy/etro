import React, { useCallback, useRef, useState } from 'react';

/**
 * A thin draggable bar between two panels. Reports incremental horizontal
 * movement (not absolute position) via onResize(dx), so the parent just
 * needs to add dx to whatever width state it's tracking — no coordination
 * of start positions needed between multiple dividers.
 */
export default function PanelDivider({ onResize }) {
  const [dragging, setDragging] = useState(false);
  const lastX = useRef(null);

  const onMouseMove = useCallback(
    (e) => {
      if (lastX.current === null) return;
      const dx = e.clientX - lastX.current;
      lastX.current = e.clientX;
      onResize(dx);
    },
    [onResize]
  );

  const onMouseUp = useCallback(() => {
    lastX.current = null;
    setDragging(false);
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
  }, [onMouseMove]);

  function onMouseDown(e) {
    e.preventDefault();
    lastX.current = e.clientX;
    setDragging(true);
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
  }

  return (
    <div
      className={`panel-divider${dragging ? ' dragging' : ''}`}
      onMouseDown={onMouseDown}
      role="separator"
      aria-orientation="vertical"
    />
  );
}
