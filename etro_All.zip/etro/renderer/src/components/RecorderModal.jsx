import React, { useEffect, useState } from 'react';
import { BROWSERS } from '../actionMeta.js';

export default function RecorderModal({ onFinish, onClose }) {
  const [browserName, setBrowserName] = useState('chromium');
  const [baseUrl, setBaseUrl] = useState('https://');
  const [recording, setRecording] = useState(false);
  const [steps, setSteps] = useState([]);
  const [starting, setStarting] = useState(false);
  const [stopping, setStopping] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const offStep = window.api.onRecorderStep((step) => {
      setSteps((prev) => [...prev, step]);
    });
    const offClosed = window.api.onRecorderClosed(() => {
      // The user closed the recorded browser window directly — treat that the
      // same as pressing "Stop & Review" so nothing gets lost.
      setRecording(false);
    });
    return () => {
      offStep();
      offClosed();
    };
  }, []);

  async function start() {
    setError(null);
    setSteps([]);
    setStarting(true);
    try {
      await window.api.startRecording({ browserName, baseUrl });
      setRecording(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setStarting(false);
    }
  }

  async function stop() {
    setStopping(true);
    try {
      const finalSteps = await window.api.stopRecording();
      setRecording(false);
      onFinish(finalSteps && finalSteps.length ? finalSteps : steps);
    } finally {
      setStopping(false);
    }
  }

  return (
    <div className="modal-backdrop" onClick={recording ? undefined : onClose}>
      <div className="modal" style={{ width: 520 }} onClick={(e) => e.stopPropagation()}>
        <h2>Generate Test Case</h2>

        {!recording ? (
          <>
            <div className="field-row">
              <div className="field">
                <label>Browser</label>
                <select value={browserName} onChange={(e) => setBrowserName(e.target.value)}>
                  {BROWSERS.map((b) => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </div>
              <div className="field" style={{ flex: 2 }}>
                <label>Starting URL</label>
                <input
                  type="text"
                  value={baseUrl}
                  onChange={(e) => setBaseUrl(e.target.value)}
                  placeholder="https://example.com"
                />
              </div>
            </div>

            <p style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.5 }}>
              A real browser window will open. Click, type, check boxes, select dropdown
              options, and navigate normally — each action is captured as a step below in
              real time. Click <strong>Stop &amp; Review</strong> when you're done, then edit
              and save the generated steps like any other spec.
            </p>

            {error && <p style={{ color: 'var(--log-failed)', fontSize: 12 }}>{error}</p>}

            <div className="modal-footer">
              <button className="btn" onClick={onClose}>Cancel</button>
              <button className="btn btn-primary" onClick={start} disabled={!baseUrl || starting}>
                {starting ? 'Launching…' : 'Start Recording'}
              </button>
            </div>
          </>
        ) : (
          <>
            <p style={{ fontSize: 13, color: 'var(--log-passed)', margin: '4px 0 10px' }}>
              ● Recording — interact with the opened browser window
            </p>
            <div
              className="log-list"
              style={{ maxHeight: 280, background: 'var(--bg-panel-right)', borderRadius: 6, padding: 8 }}
            >
              {steps.length === 0 && <div className="log-line meta">Waiting for actions…</div>}
              {steps.map((s, i) => (
                <div key={i} className="log-line step">
                  {i + 1}. {s.action}
                  {s.locator ? ` (${s.locator.type}=${s.locator.value || s.locator.name || ''})` : ''}
                  {s.value ? ` -> ${s.value}` : ''}
                </div>
              ))}
            </div>
            {stopping && (
              <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 8 }}>
                <span className="spinner-inline" />
                Converting recording to steps…
              </p>
            )}
            <div className="modal-footer">
              <button className="btn btn-primary" onClick={stop} disabled={stopping}>
                {stopping ? (
                  <>
                    <span className="spinner-inline" />
                    Converting…
                  </>
                ) : (
                  <>■ Stop &amp; Review</>
                )}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
