import React, { useEffect, useState } from 'react';
import { BROWSERS, COMMON_DEVICES } from '../actionMeta.js';

function SettingsGearIcon() {
  return (
    <svg width="19" height="19" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="12" r="3.4" stroke="currentColor" strokeWidth="1.6" />
      <path
        d="M19.4 13.4a7.6 7.6 0 0 0 0-2.8l1.9-1.47-1.9-3.3-2.24.63a7.7 7.7 0 0 0-2.42-1.4l-.34-2.3H9.6l-.34 2.3a7.7 7.7 0 0 0-2.42 1.4l-2.24-.63-1.9 3.3 1.9 1.47a7.6 7.6 0 0 0 0 2.8l-1.9 1.47 1.9 3.3 2.24-.63c.71.6 1.53 1.08 2.42 1.4l.34 2.3h4.8l.34-2.3a7.7 7.7 0 0 0 2.42-1.4l2.24.63 1.9-3.3-1.9-1.47Z"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export default function SettingsModal({ initialSettings, onSave, onClose }) {
  const [settings, setSettings] = useState(initialSettings);
  const [installing, setInstalling] = useState(false);
  const [installLog, setInstallLog] = useState([]);
  const [deviceViewport, setDeviceViewport] = useState(null);

  useEffect(() => {
    if (settings.device) {
      window.api.getDeviceViewport(settings.device).then(setDeviceViewport);
    } else {
      setDeviceViewport(null);
    }
  }, [settings.device]);

  useEffect(() => {
    const offLog = window.api.onBrowserInstallLog((line) => {
      setInstallLog((prev) => [...prev, line]);
    });
    const offExit = window.api.onBrowserInstallExit((code) => {
      setInstalling(false);
      setInstallLog((prev) => [...prev, code === 0 ? '✓ Done.' : `✗ Exited with code ${code}`]);
    });
    window.api.isInstallingBrowsers().then(setInstalling);
    return () => {
      offLog();
      offExit();
    };
  }, []);

  function startInstall() {
    setInstallLog([]);
    setInstalling(true);
    window.api.installBrowsers(settings.browsers && settings.browsers.length ? settings.browsers : ['chromium']);
  }

  function set(patch) {
    setSettings((s) => ({ ...s, ...patch }));
  }

  function toggleBrowser(name) {
    const set1 = new Set(settings.browsers || []);
    if (set1.has(name)) set1.delete(name);
    else set1.add(name);
    set({ browsers: Array.from(set1) });
  }

  async function pickReportDir() {
    const dir = await window.api.pickReportDir();
    if (dir) set({ reportDir: dir });
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h2 style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <SettingsGearIcon />
          Playwright Settings
        </h2>

        <div className="section-title" style={{ marginTop: 0 }}>Appearance</div>
        <div className="field-row">
          <div className="field">
            <label>Theme</label>
            <select value={settings.theme || 'default'} onChange={(e) => set({ theme: e.target.value })}>
              <option value="default">Default</option>
              <option value="light">Light</option>
              <option value="dark">Dark</option>
            </select>
          </div>
        </div>

        <div className="section-title">Browsers</div>
        <div className="checkbox-row">
          {BROWSERS.map((b) => (
            <label key={b}>
              <input
                type="checkbox"
                checked={(settings.browsers || []).includes(b)}
                onChange={() => toggleBrowser(b)}
              />
              {b}
            </label>
          ))}
        </div>
        <div style={{ marginTop: 8 }}>
          <button className="btn" onClick={startInstall} disabled={installing}>
            {installing ? 'Installing…' : 'Install Selected Browsers'}
          </button>
          <span style={{ fontSize: 11, color: '#7d7e88', marginLeft: 8 }}>
            Run this once after installing the app — it downloads the actual browser
            binaries, which aren't bundled in the installer.
          </span>
          {installLog.length > 0 && (
            <div
              className="log-list"
              style={{ maxHeight: 140, background: '#17181c', borderRadius: 6, padding: 8, marginTop: 8 }}
            >
              {installLog.map((line, i) => (
                <div key={i} className="log-line meta">{line}</div>
              ))}
            </div>
          )}
        </div>

        <div className="section-title">Device emulation (optional)</div>
        <div className="field">
          <select
            value={settings.device || ''}
            onChange={(e) => set({ device: e.target.value })}
          >
            {COMMON_DEVICES.map((d) => (
              <option key={d || 'none'} value={d}>{d || '— none (use viewport below) —'}</option>
            ))}
          </select>
          {settings.device && (
            <p style={{ fontSize: 11, color: 'var(--text-faint)', margin: '6px 0 0' }}>
              {deviceViewport
                ? `Using ${settings.device}'s own viewport — ${deviceViewport.width}×${deviceViewport.height}. The manual Viewport fields below are ignored while a device is selected.`
                : 'Loading device info…'}
            </p>
          )}
        </div>

        <div className="section-title">Viewport</div>

        {settings.headless === false && !settings.device && (
          <div className="field-row">
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={!!settings.overrideMaximizedViewport}
                onChange={(e) => set({ overrideMaximizedViewport: e.target.checked })}
              />
              Use a custom viewport instead of maximized
              <span style={{ fontSize: 11, color: 'var(--text-faint)', fontWeight: 400 }}>
                (headed mode opens the browser maximized by default)
              </span>
            </label>
          </div>
        )}

        <div className="field-row">
          <div className="field">
            <label>
              Width
              {settings.device
                ? ' (overridden by device above)'
                : settings.headless === false && !settings.overrideMaximizedViewport
                ? ' (ignored — browser opens maximized)'
                : ''}
            </label>
            <input
              type="number"
              disabled={!!settings.device || (settings.headless === false && !settings.overrideMaximizedViewport)}
              value={settings.viewport?.width ?? 1280}
              onChange={(e) =>
                set({ viewport: { ...settings.viewport, width: Number(e.target.value) } })
              }
            />
          </div>
          <div className="field">
            <label>
              Height
              {settings.device
                ? ' (overridden by device above)'
                : settings.headless === false && !settings.overrideMaximizedViewport
                ? ' (ignored — browser opens maximized)'
                : ''}
            </label>
            <input
              type="number"
              disabled={!!settings.device || (settings.headless === false && !settings.overrideMaximizedViewport)}
              value={settings.viewport?.height ?? 720}
              onChange={(e) =>
                set({ viewport: { ...settings.viewport, height: Number(e.target.value) } })
              }
            />
          </div>
        </div>

        <div className="section-title">Capture</div>
        <div className="field-row">
          <div className="field">
            <label>Screenshots (end of test)</label>
            <select value={settings.screenshot} onChange={(e) => set({ screenshot: e.target.value })}>
              <option value="off">Off</option>
              <option value="on">On (every test)</option>
              <option value="only-on-failure">Only on failure</option>
            </select>
          </div>
          <div className="field">
            <label>Screenshots (per step)</label>
            <select
              value={settings.stepScreenshots || 'off'}
              onChange={(e) => set({ stepScreenshots: e.target.value })}
            >
              <option value="off">Off</option>
              <option value="on">Every step</option>
              <option value="only-on-failure">Only the failing step</option>
            </select>
          </div>
        </div>
        <div className="field-row">
          <div className="field">
            <label>Video</label>
            <select value={settings.video} onChange={(e) => set({ video: e.target.value })}>
              <option value="off">Off</option>
              <option value="on">On (every test)</option>
              <option value="retain-on-failure">Retain on failure</option>
            </select>
          </div>
          <div className="field">
            <label>Trace</label>
            <select value={settings.trace} onChange={(e) => set({ trace: e.target.value })}>
              <option value="off">Off</option>
              <option value="on">On (every test)</option>
              <option value="retain-on-failure">Retain on failure</option>
              <option value="on-first-retry">On first retry</option>
            </select>
          </div>
        </div>

        <div className="section-title">Execution</div>
        <div className="field-row">
          <div className="field">
            <label>Headless</label>
            <select
              value={settings.headless ? 'true' : 'false'}
              onChange={(e) => set({ headless: e.target.value === 'true' })}
            >
              <option value="true">Headless</option>
              <option value="false">Headed (visible browser)</option>
            </select>
          </div>
          <div className="field">
            <label>Timeout (ms)</label>
            <input
              type="number"
              value={settings.timeoutMs}
              onChange={(e) => set({ timeoutMs: Number(e.target.value) })}
            />
          </div>
        </div>
        <div className="field-row">
          <div className="field">
            <label>Retries</label>
            <input
              type="number"
              value={settings.retries}
              onChange={(e) => set({ retries: Number(e.target.value) })}
            />
          </div>
          <div className="field">
            <label>Workers</label>
            <input
              type="number"
              min={1}
              value={settings.workers}
              onChange={(e) => set({ workers: Number(e.target.value) })}
            />
          </div>
        </div>

        <div className="section-title">HTML report location</div>
        <div className="field-row">
          <div className="field" style={{ flex: 2 }}>
            <input type="text" value={settings.reportDir} readOnly />
          </div>
          <button className="btn" onClick={pickReportDir}>Browse…</button>
        </div>

        <div className="modal-footer">
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={() => onSave(settings)}>Save Settings</button>
        </div>
      </div>
    </div>
  );
}
