import React, { useEffect, useState } from 'react';
import { emptyVariable } from '../actionMeta.js';
import StepList from './StepList.jsx';
import AccessibilityModal from './AccessibilityModal.jsx';

export default function SpecEditor({ spec, collections, sessions, onChange, onSave, onCancel, onExport, onOpenJson, dirty }) {
  const [testDataPreview, setTestDataPreview] = useState(null);
  const [showAccessibility, setShowAccessibility] = useState(false);

  useEffect(() => {
    let cancelled = false;
    if (spec && spec.testDataFile) {
      window.api.previewTestDataFile(spec.testDataFile).then((result) => {
        if (!cancelled) setTestDataPreview(result);
      });
    } else {
      setTestDataPreview(null);
    }
    return () => {
      cancelled = true;
    };
  }, [spec && spec.testDataFile, spec && spec.id]);

  if (!spec) {
    return (
      <div style={{ color: 'var(--text-faint)', fontSize: 14, padding: '16px 20px' }}>
        Select a spec on the left, or click “+ New Spec” to create one.
      </div>
    );
  }

  function update(patch) {
    onChange({ ...spec, ...patch });
  }

  // ---- Variables table ----
  function updateVariable(index, patch) {
    const variables = (spec.variables || []).slice();
    variables[index] = { ...variables[index], ...patch };
    update({ variables });
  }

  function addVariable() {
    update({ variables: [...(spec.variables || []), emptyVariable()] });
  }

  function removeVariable(index) {
    const variables = (spec.variables || []).slice();
    variables.splice(index, 1);
    update({ variables });
  }

  return (
    <div className="spec-editor">
      {/* ---- Fixed header: name/collection, base URL/session, variables ---- */}
      <div className="spec-editor-header">
        <div className="field-row">
          <div className="field" style={{ flex: 2 }}>
            <label>Test name</label>
            <input
              type="text"
              value={spec.name}
              onChange={(e) => update({ name: e.target.value })}
            />
          </div>
          <div className="field">
            <label>Collection</label>
            <select
              value={spec.collectionId}
              onChange={(e) => update({ collectionId: e.target.value })}
            >
              {collections.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="field-row">
          <div className="field">
            <label>Base URL (opened before the first step, supports {'{{variables}}'})</label>
            <input
              type="text"
              placeholder="https://example.com"
              value={spec.baseUrl || ''}
              onChange={(e) => update({ baseUrl: e.target.value })}
            />
          </div>
          <div className="field">
            <label>Start from saved session (optional)</label>
            <select
              value={spec.sessionKey || ''}
              onChange={(e) => update({ sessionKey: e.target.value })}
            >
              <option value="">— none, start logged out —</option>
              {(sessions || []).map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Spec timeout (ms, optional — overrides Settings)</label>
            <input
              type="number"
              placeholder="e.g. 60000"
              value={spec.timeoutMs || ''}
              onChange={(e) => update({ timeoutMs: e.target.value })}
            />
          </div>
        </div>

        <div className="field-row" style={{ alignItems: 'center' }}>
          <button className="btn" onClick={() => setShowAccessibility(true)}>
            ♿ Accessibility Testing
          </button>
          <span style={{ fontSize: 12, color: spec.accessibility?.enabled ? 'var(--log-passed)' : 'var(--text-faint)' }}>
            {spec.accessibility?.enabled
              ? `Enabled — scans ${spec.accessibility.includeSelectors?.length ? 'selected elements' : 'the whole page'} after all steps run${spec.accessibility.failOnViolations === false ? ' (won\'t fail the test)' : ''}`
              : 'Not configured for this spec'}
          </span>
        </div>

        <div className="section-title" style={{ marginTop: 4 }}>
          Test Data
          <span style={{ fontWeight: 400, color: 'var(--text-faint)', fontSize: 11, marginLeft: 8 }}>
            reference values from a JSON file instead of hardcoding them in steps — edit the
            file directly and changes apply on the next run, no need to re-save this spec
          </span>
        </div>
        <div className="field-row">
          <div className="field" style={{ flex: 2 }}>
            <input type="text" readOnly value={spec.testDataFile || ''} placeholder="No test data file selected" />
          </div>
          <div className="field" style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 6, flex: 'none' }}>
            <button
              className="btn"
              onClick={async () => {
                const filePath = await window.api.pickTestDataFile();
                if (filePath) update({ testDataFile: filePath });
              }}
            >
              Browse…
            </button>
            {spec.testDataFile && (
              <button className="btn" onClick={() => update({ testDataFile: '' })}>
                Clear
              </button>
            )}
          </div>
        </div>
        {spec.testDataFile && testDataPreview && (
          <p style={{ fontSize: 11, marginTop: -6, marginBottom: 8 }}>
            {testDataPreview.ok ? (
              <span style={{ color: 'var(--text-faint)' }}>
                Loaded — top-level keys: {testDataPreview.keys.join(', ') || '(empty object)'}. Reference with{' '}
                <code>{'{{testData.'}{testDataPreview.keys[0] || 'key'}{'}}'}</code> (nested paths like{' '}
                <code>{'{{testData.details.myName}}'}</code> work too).
              </span>
            ) : (
              <span style={{ color: 'var(--log-failed)' }}>Could not load this file: {testDataPreview.error}</span>
            )}
          </p>
        )}

        <div className="section-title" style={{ marginTop: 4 }}>
          Variables
          <span style={{ fontWeight: 400, color: 'var(--text-faint)', fontSize: 11, marginLeft: 8 }}>
            seeded before the run — steps like "API request" or "Extract text" can add more as they run
          </span>
        </div>
        <table className="steps-table">
          <thead>
            <tr>
              <th style={{ width: 200 }}>Name</th>
              <th>Value</th>
              <th style={{ width: 40 }}></th>
            </tr>
          </thead>
          <tbody>
            {(spec.variables || []).map((v, i) => (
              <tr key={i}>
                <td>
                  <input
                    type="text"
                    placeholder="username"
                    value={v.name}
                    onChange={(e) => updateVariable(i, { name: e.target.value })}
                  />
                </td>
                <td>
                  <input
                    type="text"
                    placeholder="test@example.com"
                    value={v.value}
                    onChange={(e) => updateVariable(i, { value: e.target.value })}
                  />
                </td>
                <td>
                  <button className="btn btn-icon" style={{ padding: '3px 6px' }} onClick={() => removeVariable(i)}>✕</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <button className="btn" style={{ marginTop: 6 }} onClick={addVariable}>+ Add variable</button>

        <div className="section-title" style={{ marginBottom: 0 }}>Steps</div>
      </div>

      {/* ---- Scrollable steps region — this is the only part that scrolls ---- */}
      <div className="spec-editor-steps">
        <StepList steps={spec.steps} onChange={(steps) => update({ steps })} />
      </div>

      {/* ---- Fixed footer: save/export actions ---- */}
      <div className="spec-editor-footer">
        <button className="btn btn-primary" onClick={onSave}>
          {dirty ? 'Save spec*' : 'Save spec'}
        </button>
        <button className="btn" onClick={onCancel}>
          Cancel
        </button>
        <button className="btn" onClick={onExport}>
          Export…
        </button>
        <button className="btn" onClick={onOpenJson}>
          {'{ } '}Show Spec
        </button>
      </div>

      {showAccessibility && (
        <AccessibilityModal
          config={spec.accessibility}
          onSave={(accessibility) => {
            update({ accessibility });
            setShowAccessibility(false);
          }}
          onClose={() => setShowAccessibility(false)}
        />
      )}
    </div>
  );
}
