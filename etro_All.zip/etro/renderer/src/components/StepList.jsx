import React from 'react';
import { ACTIONS, LOCATOR_TYPES, emptyStep, actionMeta } from '../actionMeta.js';

export default function StepList({ steps, onChange, depth = 0 }) {
  const list = steps || [];

  function updateStep(index, patch) {
    const next = list.slice();
    next[index] = { ...next[index], ...patch };
    onChange(next);
  }

  function updateLocator(index, patch) {
    const next = list.slice();
    next[index] = {
      ...next[index],
      locator: { ...(next[index].locator || {}), ...patch },
    };
    onChange(next);
  }

  function addStep() {
    onChange([...list, emptyStep()]);
  }

  // Inserts a new step immediately after `index` — e.g. clicking "+" on step
  // 2 of 3 makes the new step the new step 3, shifting the old step 3 to 4.
  function addStepAfter(index) {
    const next = list.slice();
    next.splice(index + 1, 0, emptyStep());
    onChange(next);
  }

  function removeStep(index) {
    const next = list.slice();
    next.splice(index, 1);
    onChange(next);
  }

  function moveStep(index, dir) {
    const next = list.slice();
    const target = index + dir;
    if (target < 0 || target >= next.length) return;
    [next[index], next[target]] = [next[target], next[index]];
    onChange(next);
  }

  function toggleDisabled(index) {
    updateStep(index, { disabled: !list[index].disabled });
  }

  function updateBranch(index, branchKey, branchSteps) {
    updateStep(index, { [branchKey]: branchSteps });
  }

  return (
    <div>
      <table className="steps-table">
        <thead>
          <tr>
            <th style={{ width: 26 }}></th>
            <th style={{ width: 150 }}>Action</th>
            <th style={{ width: 110 }}>Locator type</th>
            <th>Locator value</th>
            <th>Value</th>
            <th style={{ width: 175 }}></th>
          </tr>
        </thead>
        <tbody>
          {list.map((step, i) => {
            const meta = actionMeta(step.action);
            const isConditional = step.action === 'conditional';
            const isDisabled = !!step.disabled;

            return (
              <React.Fragment key={i}>
                <tr className={isDisabled ? 'step-row-disabled' : undefined}>
                  <td style={{ color: 'var(--text-very-faint)', paddingTop: 8 }}>{i + 1}</td>
                  <td>
                    <select
                      value={step.action}
                      onChange={(e) => updateStep(i, { action: e.target.value })}
                      disabled={isDisabled}
                    >
                      {ACTIONS.map((a) => (
                        <option key={a.name} value={a.name}>{a.name}</option>
                      ))}
                    </select>
                  </td>
                  <td>
                    {meta.needsLocator ? (
                      <select
                        value={(step.locator && step.locator.type) || 'testid'}
                        onChange={(e) => updateLocator(i, { type: e.target.value })}
                        disabled={isDisabled}
                      >
                        {LOCATOR_TYPES.map((l) => (
                          <option key={l.value} value={l.value}>{l.label}</option>
                        ))}
                      </select>
                    ) : (
                      <span style={{ color: 'var(--text-very-faint)', fontSize: 12 }}>—</span>
                    )}
                  </td>
                  <td>
                    {meta.needsLocator ? (
                      <input
                        type="text"
                        placeholder={
                          step.locator && step.locator.type === 'role'
                            ? 'e.g. button (name below)'
                            : 'selector / id / text'
                        }
                        value={(step.locator && step.locator.value) || ''}
                        onChange={(e) => updateLocator(i, { value: e.target.value })}
                        disabled={isDisabled}
                      />
                    ) : (
                      <span style={{ color: 'var(--text-very-faint)', fontSize: 12 }}>—</span>
                    )}
                    {meta.needsLocator && step.locator && step.locator.type === 'role' && (
                      <input
                        type="text"
                        placeholder="accessible name (optional)"
                        style={{ marginTop: 4 }}
                        value={step.locator.name || ''}
                        onChange={(e) => updateLocator(i, { name: e.target.value })}
                        disabled={isDisabled}
                      />
                    )}
                  </td>
                  <td>
                    {meta.needsValue ? (
                      <input
                        type="text"
                        placeholder={meta.valueLabel || 'value'}
                        value={step.value || ''}
                        onChange={(e) => updateStep(i, { value: e.target.value })}
                        disabled={isDisabled}
                      />
                    ) : (
                      <span style={{ color: 'var(--text-very-faint)', fontSize: 12 }}>—</span>
                    )}
                  </td>
                  <td className="step-actions">
                    <button
                      className="btn btn-icon"
                      onClick={() => toggleDisabled(i)}
                      title={isDisabled ? 'Enable this step' : 'Disable this step (skipped when running)'}
                    >
                      {isDisabled ? '▶' : '⏸'}
                    </button>
                    <button className="btn btn-icon" onClick={() => moveStep(i, -1)} title="Move up">↑</button>
                    <button className="btn btn-icon" onClick={() => moveStep(i, 1)} title="Move down">↓</button>
                    <button className="btn btn-icon" onClick={() => addStepAfter(i)} title="Insert a new step after this one">+</button>
                    <button className="btn btn-icon" onClick={() => removeStep(i)} title="Delete this step">✕</button>
                  </td>
                </tr>

                {isDisabled && (
                  <tr className="step-row-disabled">
                    <td></td>
                    <td colSpan={5} style={{ fontSize: 11, color: 'var(--text-faint)', paddingBottom: 4 }}>
                      Disabled — this step will be skipped when the spec runs.
                    </td>
                  </tr>
                )}

                {meta.extraFields && meta.extraFields.length > 0 && (
                  <tr>
                    <td></td>
                    <td colSpan={5} style={{ background: 'var(--bg-code-block)', borderRadius: 6, padding: '8px 10px' }}>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                        {meta.extraFields.map((f) => (
                          <div key={f.key} className="field" style={{ minWidth: 200, flex: f.type === 'textarea' ? '1 1 100%' : '1 1 200px' }}>
                            <label>{f.label}</label>
                            {f.type === 'select' ? (
                              <select
                                value={step[f.key] || f.options[0]}
                                onChange={(e) => updateStep(i, { [f.key]: e.target.value })}
                                disabled={isDisabled}
                              >
                                {f.options.map((opt) => (
                                  <option key={opt} value={opt}>{opt}</option>
                                ))}
                              </select>
                            ) : f.type === 'textarea' ? (
                              <textarea
                                rows={f.rows || 2}
                                placeholder={f.placeholder}
                                value={step[f.key] || ''}
                                onChange={(e) => updateStep(i, { [f.key]: e.target.value })}
                                disabled={isDisabled}
                              />
                            ) : (
                              <input
                                type="text"
                                placeholder={f.placeholder}
                                value={step[f.key] || ''}
                                onChange={(e) => updateStep(i, { [f.key]: e.target.value })}
                                disabled={isDisabled}
                              />
                            )}
                          </div>
                        ))}
                      </div>
                    </td>
                  </tr>
                )}

                {isConditional && (
                  <tr>
                    <td></td>
                    <td colSpan={5}>
                      <div
                        style={{
                          border: '1px solid var(--border-color)',
                          borderRadius: 6,
                          padding: '8px 10px',
                          marginTop: 2,
                          marginBottom: 6,
                        }}
                      >
                        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--log-passed)', marginBottom: 4 }}>
                          ✓ IF TRUE — run these steps
                        </div>
                        <StepList
                          steps={step.thenSteps || []}
                          onChange={(next) => updateBranch(i, 'thenSteps', next)}
                          depth={depth + 1}
                        />

                        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--log-failed)', margin: '12px 0 4px' }}>
                          ✗ IF FALSE — run these steps (optional, leave empty to just skip)
                        </div>
                        <StepList
                          steps={step.elseSteps || []}
                          onChange={(next) => updateBranch(i, 'elseSteps', next)}
                          depth={depth + 1}
                        />
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            );
          })}
        </tbody>
      </table>

      <button className="btn" style={{ marginTop: 10 }} onClick={addStep}>
        + Add step{depth > 0 ? ' to this branch' : ''}
      </button>
    </div>
  );
}
