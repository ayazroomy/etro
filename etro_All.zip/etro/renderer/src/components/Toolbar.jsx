import React from 'react';
import { APP_NAME } from '../appInfo.js';

// A cleaner circular info-badge icon in place of the plain "ⓘ" glyph.
function AboutIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="10" cy="10" r="8.5" stroke="currentColor" strokeWidth="1.6" />
      <circle cx="10" cy="6.2" r="1.15" fill="currentColor" />
      <rect x="9.1" y="8.7" width="1.8" height="6" rx="0.9" fill="currentColor" />
    </svg>
  );
}

// A matching circular question-mark badge for Help.
function HelpIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="10" cy="10" r="8.5" stroke="currentColor" strokeWidth="1.6" />
      <path
        d="M7.6 7.6c0-1.5 1.1-2.5 2.5-2.5 1.4 0 2.5 1 2.5 2.3 0 1.7-2.3 1.7-2.3 3.6"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        fill="none"
      />
      <circle cx="10" cy="14.3" r="1.05" fill="currentColor" />
    </svg>
  );
}

export default function Toolbar({
  appIcon,
  platform,
  onRun,
  onStop,
  running,
  runDisabled,
  onOpenSettings,
  onOpenAbout,
  onOpenHelp,
  onNewSpec,
  onNewCollection,
  onOpenRecorder,
  onOpenHtmlReport,
  htmlReportPath,
}) {
  const isMac = platform === 'darwin';
  const toolbarStyle = isMac
    ? { paddingLeft: 78 } // room for the native traffic-light buttons
    : { paddingRight: 150 }; // room for the native minimize/maximize/close overlay

  return (
    <div className="toolbar" style={toolbarStyle}>
      <div className="toolbar-brand">
        {appIcon && <img src={appIcon} alt={APP_NAME} />}
        <strong>{APP_NAME}</strong>
      </div>

      <button className="btn" onClick={onNewSpec}>+ New Spec</button>
      <button className="btn" onClick={onNewCollection}>+ New Collection</button>
      <button className="btn" onClick={onOpenRecorder}>● Record</button>

      <div className="spacer" />

      {htmlReportPath && (
        <button className="btn" onClick={onOpenHtmlReport}>Open Last HTML Report</button>
      )}

      {running ? (
        <button className="btn btn-danger" onClick={onStop}>■ Stop</button>
      ) : (
        <button className="btn btn-primary" onClick={onRun} disabled={runDisabled}>
          ▶ Run
        </button>
      )}

      <button className="btn btn-icon" onClick={onOpenSettings} title="Playwright settings">
        ⚙ Settings
      </button>
      <button className="btn btn-icon" onClick={onOpenHelp} title="Help & documentation">
        <HelpIcon /> Help
      </button>
      <button className="btn btn-icon" onClick={onOpenAbout} title="About & updates">
        <AboutIcon /> About
      </button>
    </div>
  );
}
