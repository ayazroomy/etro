# Runner package tests (real browser required)

Unlike `electron-tests/` (which mocks Electron entirely and needs no real browser),
these tests exercise `runner/*.js` through the actual Playwright Test CLI with a real
Chromium — some things (like an accessibility scan genuinely reading real page content)
can't be meaningfully tested against a mock DOM.

Run with:

```bash
node runner-tests/accessibility.test.js
```

Needs a real Chromium binary. It checks, in order: `PWD_TEST_CHROMIUM_PATH` (explicit
override), then `/opt/pw-browsers/chromium-1194/chrome-linux/chrome` (this project's
development sandbox), then scans `PLAYWRIGHT_BROWSERS_PATH` for any installed
`chromium-*` build. If none are found, it prints a clear skip message and exits 0
rather than failing confusingly.

## `accessibility.test.js`

Covers `runner/accessibilityRunner.js` and its wiring into `runner/generic-runner.spec.js`
— writes real temporary spec JSON files, runs them through the real
`electron/configBuilder.js` → Playwright Test CLI pipeline (the same path a real run
through the app takes), and asserts on the actual CLI output:

- Disabled accessibility config runs the spec normally, with no scan step at all.
- A page with real violations and `failOnViolations: true` fails the test, with the
  `accessibility-report.html` attachment present (contentType `text/html`).
- The same violations with `failOnViolations: false` still pass.
- `includeSelectors` correctly scopes the scan away from a violating element outside
  the included scope.
- `tags` filtering (e.g. `wcag2a`) narrows the violation count rather than reporting
  every rule in axe's full default set.
- **Video duplication regression guard**: with video recording enabled, an
  accessibility-enabled test produces exactly one video attachment, not two.
  `@axe-core/playwright`'s default (non-legacy) mode opens an extra internal "blank
  page" in the same browser context to aggregate results — since video recording is
  scoped to the whole context, that extra page got its own separate video file
  recorded and attached. Fixed via `AxeBuilder.setLegacyMode(true)`.
- **Step-based scan timing**: the insertable "Accessibility Scan" step correctly
  catches a violation on a genuinely transient element (a modal shown by a click and
  removed automatically a few seconds later) that a spec-level "scan after all steps"
  config could never catch, since by definition the element is already gone by then.
