/**
 * Real end-to-end tests for the accessibility scan feature
 * (runner/accessibilityRunner.js + its wiring in generic-runner.spec.js).
 *
 * Unlike electron-tests/ (which mocks Electron and needs no real browser),
 * this needs an actual Chromium — axe-core genuinely scans a real page, so
 * there's no meaningful way to test it against a mock DOM. Requires
 * PLAYWRIGHT_BROWSERS_PATH to point at real installed browsers; if none are
 * available this prints a clear skip message rather than a confusing crash.
 *
 * Run with: node runner-tests/accessibility.test.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');

let passed = 0;
let failed = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  PASS: ${name}`);
  } catch (err) {
    failed++;
    failures.push({ name, err });
    console.log(`  FAIL: ${name}`);
    console.log(`        ${err.message}`);
  }
}

function findChromiumExecutable() {
  const candidates = [
    process.env.PWD_TEST_CHROMIUM_PATH,
    '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  ].filter(Boolean);
  for (const c of candidates) {
    if (fs.existsSync(c)) return c;
  }
  // Fall back to scanning the standard Playwright browsers cache for any
  // installed chromium build, so this isn't hardcoded to one specific
  // sandbox's exact revision number.
  const browsersPath = process.env.PLAYWRIGHT_BROWSERS_PATH;
  if (browsersPath && fs.existsSync(browsersPath)) {
    for (const entry of fs.readdirSync(browsersPath)) {
      if (entry.startsWith('chromium-')) {
        const exe = path.join(browsersPath, entry, 'chrome-linux', 'chrome');
        if (fs.existsSync(exe)) return exe;
      }
    }
  }
  return null;
}

function runSpecs(specs, { extraEnv, videoMode = 'off' } = {}) {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'etro-a11y-test-'));
  const specsDir = path.join(tmpDir, 'specs');
  fs.mkdirSync(specsDir, { recursive: true });
  for (const spec of specs) {
    fs.writeFileSync(path.join(specsDir, `${spec.id}.json`), JSON.stringify(spec));
  }

  const chromiumPath = findChromiumExecutable();
  if (!chromiumPath) {
    throw new Error('No real Chromium binary found — set PWD_TEST_CHROMIUM_PATH or PLAYWRIGHT_BROWSERS_PATH to run this suite.');
  }

  // Same resolution approach as electron/testRunner.js: @playwright/test's
  // package.json "exports" map only exposes its main entry point, not
  // arbitrary subpaths, so require.resolve('@playwright/test/cli.js')
  // throws ERR_PACKAGE_PATH_NOT_EXPORTED. Resolving via package.json's own
  // location (always resolvable) and joining cli.js from there works.
  const playwrightCliPath = path.join(
    path.dirname(require.resolve('@playwright/test/package.json')),
    'cli.js'
  );

  const configPath = path.join(tmpDir, 'playwright.config.js');
  const reportDir = path.join(tmpDir, 'report');
  const { writeConfig } = require(path.join(__dirname, '..', 'electron', 'configBuilder.js'));

  const settings = {
    browsers: ['chromium'],
    viewport: { width: 1280, height: 720 },
    screenshot: 'off',
    stepScreenshots: 'off',
    video: videoMode,
    trace: 'off',
    headless: true,
    timeoutMs: 30000,
    retries: 0,
    workers: 1,
  };

  const origEnv = process.env.PWD_BROWSER_EXECUTABLE_PATH;
  process.env.PWD_BROWSER_EXECUTABLE_PATH = chromiumPath;
  writeConfig({ settings, reportDir, configPath });
  process.env.PWD_BROWSER_EXECUTABLE_PATH = origEnv;

  let stdout = '';
  try {
    stdout = execFileSync(
      process.execPath,
      [playwrightCliPath, 'test', '--config', configPath, '--reporter=list'],
      {
        env: { ...process.env, SPECS_DIR: specsDir, ...extraEnv },
        encoding: 'utf-8',
      }
    );
  } catch (err) {
    // Non-zero exit is expected for specs designed to fail — the actual
    // test assertions below check stdout content, not the exit code.
    stdout = (err.stdout || '') + (err.stderr || '');
  }

  fs.rmSync(tmpDir, { recursive: true, force: true });
  return stdout;
}

function runSpecsWithVideo(specs) {
  return runSpecs(specs, { videoMode: 'on' });
}

const chromiumPath = findChromiumExecutable();
if (!chromiumPath) {
  console.log('SKIPPED: no real Chromium binary available in this environment.');
  console.log('Set PWD_TEST_CHROMIUM_PATH or PLAYWRIGHT_BROWSERS_PATH to run this suite.');
  process.exit(0);
}

console.log(`Using Chromium at: ${chromiumPath}\n`);

test('a spec with accessibility disabled runs normally with no scan step', () => {
  const output = runSpecs([
    {
      id: 'disabled_test',
      name: 'A11y disabled',
      collectionId: 'default',
      baseUrl: 'data:text/html,<html><body><h1>Hi</h1></body></html>',
      steps: [{ action: 'waitForTimeout', value: '10' }],
      accessibility: { enabled: false },
    },
  ]);
  if (!output.includes('1 passed')) throw new Error(`expected the test to pass; got:\n${output}`);
  if (output.includes('Accessibility scan')) throw new Error('an accessibility scan step should not appear when disabled');
});

test('a spec with violations and failOnViolations:true fails, with an HTML attachment', () => {
  const output = runSpecs([
    {
      id: 'fail_test',
      name: 'A11y should fail',
      collectionId: 'default',
      baseUrl: 'data:text/html,<html><body><img src=x.png></body></html>',
      steps: [],
      accessibility: { enabled: true, includeSelectors: [], excludeSelectors: [], tags: [], failOnViolations: true },
    },
  ]);
  if (!output.includes('1 failed')) throw new Error(`expected the test to fail; got:\n${output}`);
  if (!output.includes('Accessibility scan found')) throw new Error('expected the violation-count error message');
  if (!output.includes('accessibility-report.html')) throw new Error('expected the HTML report attachment to be listed');
  if (!output.includes('(text/html)')) throw new Error('expected the attachment to have contentType text/html');
});

test('the same violations with failOnViolations:false pass instead', () => {
  const output = runSpecs([
    {
      id: 'pass_test',
      name: 'A11y should still pass',
      collectionId: 'default',
      baseUrl: 'data:text/html,<html><body><img src=x.png></body></html>',
      steps: [],
      accessibility: { enabled: true, includeSelectors: [], excludeSelectors: [], tags: [], failOnViolations: false },
    },
  ]);
  if (!output.includes('1 passed')) throw new Error(`expected the test to pass despite violations; got:\n${output}`);
});

test('includeSelectors correctly scopes the scan away from a violating element', () => {
  const output = runSpecs([
    {
      id: 'scoped_test',
      name: 'A11y scoped to a clean element',
      collectionId: 'default',
      baseUrl: 'data:text/html,<html><body><img src=x.png id=bad><div id=clean>Just plain text</div></body></html>',
      steps: [],
      accessibility: { enabled: true, includeSelectors: ['#clean'], excludeSelectors: [], tags: [], failOnViolations: true },
    },
  ]);
  if (!output.includes('1 passed')) throw new Error(`expected the scoped scan to pass; got:\n${output}`);
});

test('tags filtering narrows down which violations are reported', () => {
  const output = runSpecs([
    {
      id: 'tags_test',
      name: 'A11y with wcag2a tag filter',
      collectionId: 'default',
      baseUrl: 'data:text/html,<html><body><img src=x.png></body></html>',
      steps: [],
      accessibility: { enabled: true, includeSelectors: [], excludeSelectors: [], tags: ['wcag2a'], failOnViolations: true },
    },
  ]);
  if (!output.includes('1 failed')) throw new Error(`expected the tag-filtered scan to still fail (some violations remain); got:\n${output}`);
  // The full, untagged scan on this same fixture finds 7 violations (see the
  // conversation history this was verified against) — the wcag2a-only scan
  // should find fewer.
  const match = output.match(/Accessibility scan found (\d+) violation/);
  if (!match) throw new Error('could not find the violation count in output');
  const count = Number(match[1]);
  if (!(count > 0 && count < 7)) throw new Error(`expected a tag-filtered violation count between 1 and 6, got ${count}`);
});

test('REGRESSION GUARD: accessibility scan with video recording enabled produces exactly one video attachment, not two', () => {
  // AxeBuilder's default (non-legacy) mode opens an extra internal "blank
  // page" in the same browser context to aggregate results — since video
  // recording is scoped to the whole context in Playwright, that extra page
  // got its own separate video file recorded and attached (confirmed
  // directly: video.webm AND video-1.webm both showed up for the same
  // test). Fixed via AxeBuilder.setLegacyMode(true) in accessibilityRunner.js.
  const output = runSpecsWithVideo([
    {
      id: 'video_dup_test',
      name: 'Video plus a11y attachments together',
      collectionId: 'default',
      baseUrl: 'data:text/html,<html><body><img src=x.png><h1>Real Title</h1></body></html>',
      steps: [{ action: 'assertText', locator: { type: 'css', value: 'h1' }, value: 'Real Title' }],
      accessibility: { enabled: true, includeSelectors: [], excludeSelectors: [], tags: [], failOnViolations: true },
    },
  ]);
  const videoAttachmentCount = (output.match(/attachment #\d+: video \(video\/webm\)/g) || []).length;
  if (videoAttachmentCount !== 1) {
    throw new Error(`expected exactly 1 video attachment, found ${videoAttachmentCount}. Output:\n${output}`);
  }
});

test('step-based Accessibility Scan action catches a transient element that the end-of-spec scan design would miss', () => {
  // The real problem this solves: in a single-page app, an element
  // (a modal, toast, etc.) can be shown and removed entirely within the
  // span of a few steps — a spec-level "scan after everything finishes"
  // config can never catch it, since by definition it's gone by then. A
  // step-level scan, inserted right after the step that reveals the
  // element, catches it immediately instead.
  const html =
    "<html><body><button id=openBtn>Open</button>" +
    "<div id=modal style='display:none;min-height:50px'><img id=modalImg src=x.png style='width:40px;height:40px'></div>" +
    "<script>document.getElementById('openBtn').addEventListener('click', function() {" +
    "document.getElementById('modal').style.display = 'block';" +
    "setTimeout(function() { document.getElementById('modal').remove(); }, 3000);" +
    "});</script></body></html>";
  const url = 'data:text/html,' + encodeURIComponent(html);

  const output = runSpecs([
    {
      id: 'spa_timing_test',
      name: 'SPA transient element timing test',
      collectionId: 'default',
      baseUrl: url,
      steps: [
        { action: 'click', locator: { type: 'css', value: '#openBtn' } },
        {
          action: 'accessibilityScan',
          includeSelectors: '#modal',
          excludeSelectors: '',
          tags: '',
          failOnViolations: 'true',
        },
      ],
    },
  ]);
  if (!output.includes('1 failed')) {
    throw new Error(`expected the step-based scan to catch the image-alt violation on the transient modal; got:\n${output}`);
  }
  if (!output.includes('Accessibility scan found')) throw new Error('expected the violation-count error message');
  if (!output.includes('step-2-accessibility-report.html')) {
    throw new Error('expected a step-numbered HTML report attachment (distinguishing it from any other scan in the same test)');
  }
});

console.log(`\n=== Results: ${passed} passed, ${failed} failed ===`);
if (failed > 0) {
  console.log('\nFailures:');
  for (const f of failures) console.log(`  - ${f.name}: ${f.err.message}`);
  process.exitCode = 1;
}
