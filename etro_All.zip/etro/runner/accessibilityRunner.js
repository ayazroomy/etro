const AxeBuilder = require('@axe-core/playwright').default;

/**
 * Runs the actual axe-core scan and returns raw results — no test.step
 * wrapping, no attaching, no pass/fail decision. Shared by both the
 * spec-level "scan after all steps" config and the insertable
 * "Accessibility Scan" step, which each wrap this differently (different
 * step titles/labels, but identical scanning logic).
 *
 * @param {import('@playwright/test').Page} page
 * @param {object} config
 * @param {string[]} [config.includeSelectors] - CSS selectors to scope the scan to; empty/absent scans the whole page
 * @param {string[]} [config.excludeSelectors] - CSS selectors to exclude from the scan
 * @param {string[]} [config.tags] - axe-core rule tags to filter by (e.g. "wcag2aa"); empty/absent runs axe's default rule set
 */
async function performScan(page, config) {
  // Legacy mode runs axe-core directly against the real page, rather than
  // AxeBuilder's newer default behavior of opening an extra internal "blank
  // page" (in the same browser context) to aggregate results. Since video
  // recording is scoped to the whole context in Playwright, that extra page
  // gets its own separate video file recorded and attached — a real,
  // confirmed video-duplication bug (verified directly: video.webm AND
  // video-1.webm both showed up for the same test) when video capture is
  // enabled. Legacy mode's tradeoff is weaker handling of complex
  // cross-origin iframe scanning, an edge case most specs won't hit;
  // avoiding duplicate videos on every accessibility-enabled run matters
  // more.
  let builder = new AxeBuilder({ page }).setLegacyMode(true);

  for (const sel of config.includeSelectors || []) {
    if (sel && sel.trim()) builder = builder.include(sel.trim());
  }
  for (const sel of config.excludeSelectors || []) {
    if (sel && sel.trim()) builder = builder.exclude(sel.trim());
  }
  if (config.tags && config.tags.length) {
    builder = builder.withTags(config.tags);
  }

  return builder.analyze();
}

/**
 * Attaches scan results to the report (an HTML page for humans, a raw JSON
 * dump for anyone who wants the full data) and, unless failOnViolations is
 * explicitly false, throws if violations were found — the caller is
 * expected to be inside a `test.step()` already.
 *
 * @param {import('@playwright/test').TestInfo} testInfo
 * @param {object} results - axe-core AxeResults, from performScan()
 * @param {boolean} [failOnViolations] - defaults to true
 * @param {string} [attachmentPrefix] - distinguishes attachments when multiple scans run in one test (e.g. several "Accessibility Scan" steps)
 */
async function reportResults(testInfo, results, failOnViolations, attachmentPrefix) {
  const prefix = attachmentPrefix ? `${attachmentPrefix}-` : '';

  await testInfo.attach(`${prefix}accessibility-report.html`, {
    body: formatHtmlReport(results),
    contentType: 'text/html',
  });
  await testInfo.attach(`${prefix}accessibility-scan-full.json`, {
    body: JSON.stringify(results, null, 2),
    contentType: 'application/json',
  });

  const shouldFail = failOnViolations !== false; // default true
  if (shouldFail && results.violations.length > 0) {
    throw new Error(
      `Accessibility scan found ${results.violations.length} violation(s): ` +
        `${results.violations.map((v) => `${v.id} (${v.impact || 'unknown'})`).join(', ')}. ` +
        `See the "${prefix}accessibility-report.html" attachment for details.`
    );
  }
}

/**
 * Spec-level entry point: runs after all of a spec's normal steps complete,
 * scanning whatever the page looks like at that point. Wrapped in its own
 * test.step so it shows up in the live run log like a normal step, not just
 * in the report afterward.
 *
 * @param {object} opts
 * @param {import('@playwright/test').Page} opts.page
 * @param {import('@playwright/test').TestInfo} opts.testInfo
 * @param {typeof import('@playwright/test').test} opts.test
 * @param {object} opts.config - spec.accessibility (see performScan/reportResults for fields)
 */
async function runAccessibilityCheck({ page, testInfo, test, config }) {
  await test.step('Accessibility scan', async () => {
    const results = await performScan(page, config);
    await reportResults(testInfo, results, config.failOnViolations);
  });
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatHtmlReport(results) {
  const impactColor = { critical: '#c0392b', serious: '#e67e22', moderate: '#d4ac0d', minor: '#7f8c8d' };
  const violationsHtml = results.violations
    .map((v) => {
      const color = impactColor[v.impact] || '#7f8c8d';
      const nodesHtml = v.nodes
        .slice(0, 20)
        .map(
          (n) =>
            `<li><code>${escapeHtml((n.target || []).join(' '))}</code>` +
            (n.failureSummary ? `<div class="failure-summary">${escapeHtml(n.failureSummary)}</div>` : '') +
            `</li>`
        )
        .join('');
      const moreNodes = v.nodes.length > 20 ? `<li>...and ${v.nodes.length - 20} more</li>` : '';
      return `
        <div class="violation" style="border-left-color:${color}">
          <h3>${escapeHtml(v.id)} <span class="impact-badge" style="background:${color}">${escapeHtml(v.impact || 'unknown')}</span></h3>
          <p>${escapeHtml(v.help)}</p>
          <p><a href="${escapeHtml(v.helpUrl)}" target="_blank" rel="noopener">${escapeHtml(v.helpUrl)}</a></p>
          <p class="affected-label">Affected elements (${v.nodes.length}):</p>
          <ul>${nodesHtml}${moreNodes}</ul>
        </div>`;
    })
    .join('');

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Accessibility Scan Report</title>
<style>
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 900px; margin: 0 auto; padding: 24px; color: #222; background: #fff; }
  h1 { font-size: 20px; margin-bottom: 4px; }
  h3 { font-size: 14px; margin: 0 0 6px; }
  .summary { color: #555; margin-bottom: 20px; font-size: 13px; }
  .violation { border: 1px solid #ddd; border-left-width: 4px; border-radius: 6px; padding: 12px 16px; margin-bottom: 12px; }
  .impact-badge { font-size: 10px; text-transform: uppercase; color: #fff; border-radius: 4px; padding: 2px 7px; margin-left: 8px; vertical-align: middle; }
  .affected-label { font-size: 12px; font-weight: 600; margin: 10px 0 4px; }
  code { background: #f5f5f5; padding: 1px 5px; border-radius: 3px; font-size: 12px; }
  .failure-summary { font-size: 11px; color: #666; white-space: pre-wrap; margin: 2px 0 6px 4px; }
  ul { margin: 0; padding-left: 18px; font-size: 12px; }
  li { margin-bottom: 6px; }
  a { color: #2563eb; }
  .none { color: #2f9e44; font-size: 13px; }
</style>
</head>
<body>
  <h1>Accessibility Scan Report</h1>
  <p class="summary">
    ${results.violations.length} violation(s), ${results.passes.length} rule(s) passed, ${results.incomplete.length} incomplete.
  </p>
  ${violationsHtml || '<p class="none">No violations found for the configured rules/scope.</p>'}
</body>
</html>`;
}

module.exports = { runAccessibilityCheck, performScan, reportResults };
