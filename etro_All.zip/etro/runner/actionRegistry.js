const { resolveLocator } = require('./locatorResolver');
const { getPath } = require('./interpolate');
const { saveSession } = require('./sessionStore');

/**
 * Every entry here is `(page, step, expect, ctx) => Promise<void>`.
 * `ctx.variables` is a plain mutable object shared across all steps of the
 * current test — actions that extract data (apiRequest, extractText,
 * extractLocalStorage, setVariable) write into it; runner/interpolate.js
 * substitutes `{{name}}` placeholders from it into every step's fields
 * before the handler for that step runs.
 * `step.locator` (when present) is resolved against `page` by default,
 * or against a previously-captured frame/locator if step.within is used.
 *
 * This table IS the test DSL. Extend it here — never in generic-runner.spec.js.
 */
const actionRegistry = {
  // ---- Navigation ----
  goto: async (page, step) => {
    await page.goto(step.value, { waitUntil: step.waitUntil || 'load' });
  },
  goBack: async (page) => {
    await page.goBack();
  },
  goForward: async (page) => {
    await page.goForward();
  },
  reload: async (page) => {
    await page.reload();
  },

  // ---- Interactions ----
  click: async (page, step) => {
    await resolveLocator(page, step.locator).click({
      button: step.button || 'left',
      clickCount: step.clickCount || 1,
      force: !!step.force,
    });
  },
  dblclick: async (page, step) => {
    await resolveLocator(page, step.locator).dblclick();
  },
  fill: async (page, step) => {
    await resolveLocator(page, step.locator).fill(step.value ?? '');
  },
  type: async (page, step) => {
    await resolveLocator(page, step.locator).pressSequentially(step.value ?? '', {
      delay: step.delay || 0,
    });
  },
  press: async (page, step) => {
    await resolveLocator(page, step.locator).press(step.value);
  },
  pressKey: async (page, step) => {
    // Unlike `press` (which requires a locator and focuses that element
    // first), this sends a key straight to whatever currently has focus —
    // exactly what's needed to replay Tab-driven keyboard navigation, where
    // focus moves between elements as a natural side effect of each
    // preceding keypress rather than being explicitly re-targeted each time.
    // Supports Playwright's key combo syntax, e.g. "Tab", "Shift+Tab",
    // "Enter", "ArrowDown", "Control+A".
    await page.keyboard.press(step.value);
  },
  check: async (page, step) => {
    await resolveLocator(page, step.locator).check();
  },
  uncheck: async (page, step) => {
    await resolveLocator(page, step.locator).uncheck();
  },
  selectOption: async (page, step) => {
    await resolveLocator(page, step.locator).selectOption(step.value);
  },
  hover: async (page, step) => {
    await resolveLocator(page, step.locator).hover();
  },
  focus: async (page, step) => {
    await resolveLocator(page, step.locator).focus();
  },
  setInputFiles: async (page, step) => {
    await resolveLocator(page, step.locator).setInputFiles(step.value);
  },
  scrollIntoView: async (page, step) => {
    await resolveLocator(page, step.locator).scrollIntoViewIfNeeded();
  },

  // ---- Waiting ----
  waitForSelector: async (page, step) => {
    await resolveLocator(page, step.locator).waitFor({
      state: step.state || 'visible',
      timeout: step.timeout || undefined,
    });
  },
  waitForTimeout: async (page, step) => {
    await page.waitForTimeout(Number(step.value) || 0);
  },
  waitForUrl: async (page, step) => {
    // Playwright's own glob matching (**, *) for URLs was empirically found
    // to be unreliable in the shipped Playwright version — exact strings and
    // real RegExp objects match reliably, glob patterns often silently don't.
    // Since JSON can't represent a RegExp directly, valueIsRegex lets a step
    // opt into treating `value` as a regex source string instead of relying
    // on Playwright's glob interpretation of a plain string.
    const pattern = step.valueIsRegex === true || step.valueIsRegex === 'true' ? new RegExp(step.value) : step.value;
    await page.waitForURL(pattern, { timeout: step.timeout || undefined });
  },
  waitForLoadState: async (page, step) => {
    await page.waitForLoadState(step.value || 'load');
  },

  // ---- Assertions ----
  assertVisible: async (page, step, expect) => {
    await expect(resolveLocator(page, step.locator)).toBeVisible({
      timeout: step.timeout || undefined,
    });
  },
  assertHidden: async (page, step, expect) => {
    await expect(resolveLocator(page, step.locator)).toBeHidden();
  },
  assertText: async (page, step, expect) => {
    await expect(resolveLocator(page, step.locator)).toHaveText(step.value, {
      timeout: step.timeout || undefined,
    });
  },
  assertContainsText: async (page, step, expect) => {
    await expect(resolveLocator(page, step.locator)).toContainText(step.value);
  },
  assertValue: async (page, step, expect) => {
    await expect(resolveLocator(page, step.locator)).toHaveValue(step.value);
  },
  assertCount: async (page, step, expect) => {
    // Explicitly opts out of the "resolve to first match" default (see
    // locatorResolver.js) — this action's whole purpose is checking how many
    // elements actually match, so it needs the real, unrestricted locator.
    await expect(resolveLocator(page, step.locator, { first: false })).toHaveCount(Number(step.value));
  },
  assertEnabled: async (page, step, expect) => {
    await expect(resolveLocator(page, step.locator)).toBeEnabled();
  },
  assertDisabled: async (page, step, expect) => {
    await expect(resolveLocator(page, step.locator)).toBeDisabled();
  },
  assertChecked: async (page, step, expect) => {
    await expect(resolveLocator(page, step.locator)).toBeChecked();
  },
  assertUrl: async (page, step, expect) => {
    // See the comment on waitForUrl above — same reasoning applies here.
    const pattern = step.valueIsRegex === true || step.valueIsRegex === 'true' ? new RegExp(step.value) : step.value;
    await expect(page).toHaveURL(pattern);
  },
  assertTitle: async (page, step, expect) => {
    await expect(page).toHaveTitle(step.value);
  },

  // ---- Misc ----
  screenshot: async (page, step) => {
    await page.screenshot({ path: step.value, fullPage: !!step.fullPage });
  },
  evaluate: async (page, step) => {
    // eslint-disable-next-line no-new-func
    const fn = new Function('return (' + step.value + ')')();
    await fn(page);
  },

  // ---- Data / variables / sessions ----
  // These are the actions that make step data flow possible: apiRequest and
  // extractText/extractLocalStorage populate ctx.variables; setVariable seeds
  // a value by hand; saveSession persists cookies+localStorage to disk so a
  // *later, separate* test run can start already logged in (see spec.sessionKey
  // in generic-runner.spec.js — Playwright only supports loading storageState
  // at context-creation time, so a saved session applies at the start of a
  // whole test, not mid-test).
  apiRequest: async (page, step, expect, ctx) => {
    if (!step.url) throw new Error('apiRequest step is missing a URL');
    const method = (step.method || 'GET').toUpperCase();
    const options = { method, failOnStatusCode: false };

    if (step.headers) {
      try {
        options.headers =
          typeof step.headers === 'string' ? JSON.parse(step.headers) : step.headers;
      } catch (err) {
        throw new Error(`apiRequest: headers must be valid JSON — ${err.message}`);
      }
    }
    if (step.body) {
      options.data = step.body;
    }

    // page.context().request shares the browser context's cookies, so a
    // logged-in page and an apiRequest step naturally share auth state.
    const response = await page.context().request.fetch(step.url, options);
    const status = response.status();

    // Always read the raw text first (a Response body can only be consumed
    // once) so regex extraction has the exact bytes to match against,
    // regardless of whether the body also happens to be valid JSON.
    const rawText = await response.text().catch(() => '');
    let parsedJson = null;
    try {
      parsedJson = JSON.parse(rawText);
    } catch (err) {
      parsedJson = null; // not JSON — extractPath won't apply, extractRegex still can
    }

    if (step.saveAs) {
      let value;

      // Step 1: if extractPath is set, narrow down to that field's value first.
      // Anything that isn't already a string (an object, number, etc.) gets
      // stringified so a regex can still run against it in step 2.
      let narrowed = rawText;
      let pathValue;
      let pathApplied = false;
      if (step.extractPath) {
        pathValue = getPath(parsedJson ?? {}, step.extractPath);
        pathApplied = true;
        narrowed = typeof pathValue === 'string' ? pathValue : JSON.stringify(pathValue ?? '');
      }

      // Step 2: if extractRegex is also set, it runs against the narrowed
      // value from step 1 (or the whole raw response body, if no path was
      // given) — so "extractPath: data.collections" + "extractRegex: ..."
      // means "go to data.collections, then regex within that field's text".
      if (step.extractRegex) {
        let regex;
        try {
          regex = new RegExp(step.extractRegex, step.extractRegexFlags || '');
        } catch (err) {
          throw new Error(`apiRequest: invalid regex "${step.extractRegex}" — ${err.message}`);
        }
        const match = regex.exec(narrowed);
        // Prefer the first capture group (e.g. `id=(\d+)`); fall back to the
        // whole match if the pattern has no group.
        value = match ? (match[1] !== undefined ? match[1] : match[0]) : undefined;
      } else if (pathApplied) {
        value = pathValue;
      } else {
        value = parsedJson !== null ? parsedJson : rawText;
      }

      ctx.variables[step.saveAs] = value;
    }

    if (!response.ok() && step.expectStatus !== 'ignore') {
      throw new Error(`apiRequest to ${step.url} returned status ${status}`);
    }
  },

  extractText: async (page, step, expect, ctx) => {
    const text = (await resolveLocator(page, step.locator).innerText()).trim();
    if (step.saveAs) ctx.variables[step.saveAs] = text;
  },

  extractLocalStorage: async (page, step, expect, ctx) => {
    const value = await page.evaluate((key) => window.localStorage.getItem(key), step.value);
    if (step.saveAs) ctx.variables[step.saveAs] = value;
  },

  setVariable: async (page, step, expect, ctx) => {
    if (step.saveAs) ctx.variables[step.saveAs] = step.value;
  },

  saveSession: async (page, step) => {
    if (!step.value) throw new Error('saveSession step is missing a session name');
    const storageState = await page.context().storageState();
    saveSession(step.value, storageState);
  },
};

module.exports = { actionRegistry };
