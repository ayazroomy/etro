// Custom Playwright reporter. Emits one JSON object per line on stdout.
// The Electron main process reads this stream and forwards each event to the
// renderer over IPC, so the right-hand log panel updates in real time.
class ElectronReporter {
  emit(event) {
    // A stable prefix makes it trivial (and safe) for the main process to
    // distinguish our structured events from any other stray console output.
    process.stdout.write('__PWD_EVENT__' + JSON.stringify(event) + '\n');
  }

  onBegin(config, suite) {
    this.emit({ type: 'run-start', total: suite.allTests().length });
  }

  onTestBegin(test) {
    this.emit({
      type: 'test-start',
      id: test.id,
      title: test.title,
      project: test.parent && test.parent.project ? test.parent.project().name : undefined,
    });
  }

  onStepBegin(test, result, step) {
    if (step.category !== 'test.step') return;
    this.emit({ type: 'step-start', testId: test.id, title: step.title });
  }

  onStepEnd(test, result, step) {
    if (step.category !== 'test.step') return;
    this.emit({
      type: 'step-end',
      testId: test.id,
      title: step.title,
      durationMs: step.duration,
      error: step.error ? step.error.message : undefined,
    });
  }

  onTestEnd(test, result) {
    this.emit({
      type: 'test-end',
      id: test.id,
      title: test.title,
      status: result.status, // 'passed' | 'failed' | 'timedOut' | 'skipped'
      durationMs: result.duration,
      error: result.error ? result.error.message : undefined,
      attachments: (result.attachments || []).map((a) => ({
        name: a.name,
        contentType: a.contentType,
        path: a.path,
      })),
    });
  }

  onEnd(result) {
    this.emit({ type: 'run-end', status: result.status });
  }

  onError(error) {
    this.emit({ type: 'error', message: error.message || String(error) });
  }
}

module.exports = ElectronReporter;
