/**
 * Resolves a dot/bracket path like "data.items[0].token" against an object.
 * Returns undefined if any segment along the way is missing.
 */
function getPath(obj, pathStr) {
  if (!pathStr) return obj;
  const parts = String(pathStr)
    .replace(/\[(\d+)\]/g, '.$1')
    .split('.')
    .filter(Boolean);
  let cur = obj;
  for (const part of parts) {
    if (cur === null || cur === undefined) return undefined;
    cur = cur[part];
  }
  return cur;
}

/**
 * Replaces every {{variableName}} (dot-path supported, e.g. {{user.id}}) in a
 * string with its value from `variables`. Leaves the placeholder untouched if
 * the variable isn't set, so missing data is obvious in the log instead of
 * silently becoming "undefined".
 */
function interpolate(value, variables) {
  if (typeof value !== 'string') return value;
  return value.replace(/\{\{\s*([\w.[\]]+)\s*\}\}/g, (match, key) => {
    const resolved = getPath(variables, key);
    return resolved === undefined || resolved === null ? match : String(resolved);
  });
}

/** Recursively applies `interpolate` to every string in an object/array. */
function interpolateDeep(input, variables) {
  if (input === null || input === undefined) return input;
  if (typeof input === 'string') return interpolate(input, variables);
  if (Array.isArray(input)) return input.map((v) => interpolateDeep(v, variables));
  if (typeof input === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(input)) out[k] = interpolateDeep(v, variables);
    return out;
  }
  return input;
}

module.exports = { getPath, interpolate, interpolateDeep };
