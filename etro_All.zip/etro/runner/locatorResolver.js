/**
 * Maps a generic, UI-authored locator definition into a real Playwright Locator.
 * This is the single place that knows about Playwright's locator API, so the
 * rest of the app (UI, storage, action registry) can stay Playwright-agnostic.
 *
 * Locator def shape:
 *   { type: 'testid'|'role'|'text'|'label'|'placeholder'|'css'|'xpath'|'altText'|'title', value, role, name, exact }
 */

function resolveLocatorRaw(scope, locator) {
  if (!locator || !locator.type) {
    throw new Error('Step is missing a "locator" definition');
  }

  const { type, value, role, name, exact } = locator;

  switch (type) {
    case 'testid':
      return scope.getByTestId(value);

    case 'role':
      return scope.getByRole(role || value, {
        name: name || undefined,
        exact: exact || false,
      });

    case 'text':
      return scope.getByText(value, { exact: exact || false });

    case 'label':
      return scope.getByLabel(value, { exact: exact || false });

    case 'placeholder':
      return scope.getByPlaceholder(value, { exact: exact || false });

    case 'altText':
      return scope.getByAltText(value, { exact: exact || false });

    case 'title':
      return scope.getByTitle(value, { exact: exact || false });

    case 'css':
      return scope.locator(value);

    case 'xpath':
      return scope.locator(`xpath=${value}`);

    default:
      throw new Error(`Unknown locator type: "${type}"`);
  }
}

/**
 * @param {object} options
 * @param {boolean} [options.first=true] - by default, resolves to the FIRST
 *   matching element rather than Playwright's normal strict-mode behavior
 *   (throwing when a locator matches more than one element). This is a
 *   complete no-op when a locator only ever matches one element — `.first()`
 *   on a single-element locator still targets that same element. Pass
 *   `{ first: false }` for callers that specifically need to see every
 *   match — e.g. `assertCount`, which would otherwise always see a count of
 *   0 or 1 and never be able to verify "there are exactly N of these".
 */
function resolveLocator(scope, locator, options = {}) {
  const { first = true } = options;
  const resolved = resolveLocatorRaw(scope, locator);
  return first ? resolved.first() : resolved;
}

module.exports = { resolveLocator };
