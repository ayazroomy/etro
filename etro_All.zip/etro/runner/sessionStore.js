const fs = require('fs');
const path = require('path');

// Read lazily (a function, not a load-time constant) because the Electron
// main process requires this module — via electron/ipcHandlers.js — before
// app.whenReady() has had a chance to set PWD_SESSIONS_DIR. A cached
// module-level constant would freeze in the wrong (unwritable, once
// packaged) default before the override ever takes effect.
function sessionsDir() {
  return process.env.PWD_SESSIONS_DIR || path.join(__dirname, '..', 'data', 'sessions');
}

function ensureDir() {
  const dir = sessionsDir();
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function safeName(name) {
  return String(name).trim().replace(/[^a-z0-9-_]+/gi, '_');
}

function sessionPath(name) {
  return path.join(sessionsDir(), `${safeName(name)}.json`);
}

/** @param {string} name @param {object} storageState - result of context.storageState() */
function saveSession(name, storageState) {
  ensureDir();
  fs.writeFileSync(sessionPath(name), JSON.stringify(storageState, null, 2));
  return sessionPath(name);
}

/** @returns {object|null} the storage state, or null if no session with this name exists */
function loadSession(name) {
  const p = sessionPath(name);
  if (!fs.existsSync(p)) return null;
  try {
    return JSON.parse(fs.readFileSync(p, 'utf-8'));
  } catch (err) {
    return null;
  }
}

function sessionExists(name) {
  return fs.existsSync(sessionPath(name));
}

function deleteSession(name) {
  const p = sessionPath(name);
  if (fs.existsSync(p)) fs.unlinkSync(p);
}

function listSessions() {
  ensureDir();
  return fs
    .readdirSync(sessionsDir())
    .filter((f) => f.endsWith('.json'))
    .map((f) => f.replace(/\.json$/, ''));
}

module.exports = {
  get SESSIONS_DIR() {
    return sessionsDir();
  },
  sessionPath,
  saveSession,
  loadSession,
  sessionExists,
  deleteSession,
  listSessions,
};
