const fs = require('fs');
const path = require('path');

/**
 * Resolves which spec JSON files to load for this run:
 *  - If SPECS_FILTER_FILE is set (path to a JSON array of absolute file paths),
 *    only those are loaded — this is how the UI runs a single spec / collection.
 *  - Otherwise every *.json file under SPECS_DIR (recursively) is loaded.
 */
function walk(dir) {
  let results = [];
  if (!fs.existsSync(dir)) return results;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results = results.concat(walk(full));
    } else if (entry.isFile() && entry.name.endsWith('.json')) {
      results.push(full);
    }
  }
  return results;
}

function loadSpecs() {
  const specsDir = process.env.SPECS_DIR;
  const filterFile = process.env.SPECS_FILTER_FILE;

  let files;
  if (filterFile && fs.existsSync(filterFile)) {
    files = JSON.parse(fs.readFileSync(filterFile, 'utf-8'));
  } else if (specsDir) {
    files = walk(specsDir);
  } else {
    files = [];
  }

  return files
    .map((filePath) => {
      try {
        const raw = fs.readFileSync(filePath, 'utf-8');
        const spec = JSON.parse(raw);
        spec.__filePath = filePath;
        return spec;
      } catch (err) {
        // Surface a synthetic broken spec rather than crashing the whole run
        return {
          id: path.basename(filePath),
          name: `[Invalid spec] ${path.basename(filePath)}`,
          steps: [],
          __error: err.message,
        };
      }
    })
    .filter(Boolean);
}

module.exports = { loadSpecs };
