const { actionRegistry } = require('./actionRegistry');
const { interpolateDeep } = require('./interpolate');
const { resolveLocator } = require('./locatorResolver');
const { performScan, reportResults } = require('./accessibilityRunner');

async function captureStepScreenshot(page, testInfo, name) {
  try {
    if (page.isClosed()) return;
    const buffer = await page.screenshot({ fullPage: false });
    await testInfo.attach(name, { body: buffer, contentType: 'image/png' });
  } catch (err) {
    // Never let a screenshot-capture failure mask the real test result.
  }
}

/**
 * Evaluates a conditional step's condition against either the page (locator
 * state/text) or a variable from ctx.variables. Never throws for an absent
 * element on a presence-style check — "doesn't exist" is a legitimate,
 * common reason to take the "else" branch, not a test failure.
 */
async function evaluateCondition(page, step, variables) {
  const type = step.conditionType;

  if (type === 'variableEquals') {
    return String(variables[step.conditionVariableName]) === String(step.conditionValue ?? '');
  }
  if (type === 'variableTruthy') {
    const actual = variables[step.conditionVariableName];
    return !!actual && actual !== 'false' && actual !== '0';
  }

  if (!step.conditionLocatorValue) {
    throw new Error(`conditional step: condition type "${type}" needs a locator value`);
  }
  const locator = resolveLocator(page, {
    type: step.conditionLocatorType || 'css',
    value: step.conditionLocatorValue,
  });

  try {
    switch (type) {
      case 'visible':
        return await locator.isVisible();
      case 'hidden':
        return !(await locator.isVisible());
      case 'exists':
        return (await locator.count()) > 0;
      case 'notExists':
        return (await locator.count()) === 0;
      case 'checked':
        return await locator.isChecked();
      case 'unchecked':
        return !(await locator.isChecked());
      case 'enabled':
        return await locator.isEnabled();
      case 'disabled':
        return !(await locator.isEnabled());
      case 'containsText': {
        const text = await locator.innerText();
        return text.includes(step.conditionValue ?? '');
      }
      case 'textEquals': {
        const text = (await locator.innerText()).trim();
        return text === (step.conditionValue ?? '');
      }
      default:
        throw new Error(`conditional step: unknown condition type "${type}"`);
    }
  } catch (err) {
    if (err.message && err.message.startsWith('conditional step:')) throw err;
    // Element not present/attached for a text-reading check (containsText,
    // textEquals, checked, enabled) — treat as false rather than failing the
    // whole test. `exists`/`notExists`/`visible`/`hidden` never throw in the
    // first place (Playwright's count()/isVisible() don't wait or throw).
    return false;
  }
}

/**
 * A conditional step's thenSteps/elseSteps. The visual editor (StepList.jsx)
 * stores these as real arrays of step objects — the natural format. Also
 * accepts a JSON string for backward compatibility with specs saved under
 * an earlier version of this feature that used a JSON-text textarea.
 */
function parseBranch(raw, label, stepNumber) {
  if (Array.isArray(raw)) return raw;
  if (!raw) return [];
  if (typeof raw === 'string') {
    try {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch (err) {
      throw new Error(`conditional step [${stepNumber}]: "${label}" is not valid JSON — ${err.message}`);
    }
  }
  return [];
}

/**
 * Runs a list of steps in order. Used both for a spec's top-level `steps`
 * and recursively for a conditional step's `thenSteps`/`elseSteps` — a
 * branch is just another step list, so nesting conditionals inside
 * conditionals works for free.
 *
 * @param {object} opts
 * @param {import('@playwright/test').Page} opts.page
 * @param {object[]} opts.steps
 * @param {object} opts.variables - mutable variables store, shared across the whole test
 * @param {object} opts.ctx - { variables, testInfo }, passed through to action handlers
 * @param {import('@playwright/test').TestInfo} opts.testInfo
 * @param {typeof import('@playwright/test').test} opts.test
 * @param {typeof import('@playwright/test').expect} opts.expect
 * @param {'off'|'on'|'only-on-failure'} opts.stepScreenshotMode
 * @param {string} [opts.pathPrefix] - step-numbering prefix for nested branches, e.g. "3."
 */
async function runStepList(opts) {
  const { page, steps, variables, ctx, testInfo, test, expect, stepScreenshotMode } = opts;
  const pathPrefix = opts.pathPrefix || '';

  let index = 0;
  for (const rawStep of steps || []) {
    index += 1;
    const stepNumber = `${pathPrefix}${index}`;

    if (rawStep.disabled) {
      // A no-op test.step so the skip is still visible in the log/report,
      // rather than silently vanishing from the step count.
      await test.step(`[${stepNumber}] (disabled — skipped) ${rawStep.action}`, async () => {});
      continue;
    }

    if (rawStep.action === 'accessibilityScan') {
      // Interpolated so {{variables}} can be used in selectors/tags, same as
      // every other step.
      const step = interpolateDeep(rawStep, variables);
      const config = {
        includeSelectors: String(step.includeSelectors || '')
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean),
        excludeSelectors: String(step.excludeSelectors || '')
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean),
        tags: String(step.tags || '')
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean),
      };
      // extraFields render as a <select> in the UI, giving a JS string
      // 'true'/'false' — only 'false' turns off the default fail-on-violations
      // behavior, matching how the equivalent spec-level checkbox behaves.
      const failOnViolations = step.failOnViolations !== 'false';
      const scopeLabel = config.includeSelectors.length ? config.includeSelectors.join(', ') : 'whole page';

      await test.step(`[${stepNumber}] Accessibility scan (${scopeLabel})`, async () => {
        const results = await performScan(page, config);
        await reportResults(testInfo, results, failOnViolations, `step-${stepNumber}`);
      });
      continue;
    }

    if (rawStep.action === 'conditional') {
      // Interpolate the condition's own fields ({{variables}} in a locator
      // value or expected text is meaningful here), but NOT thenSteps/elseSteps
      // — those are (or, for older saved specs, contain JSON text for) nested
      // step objects; interpolating them as a whole here risks a substituted
      // value breaking JSON syntax, or interpolating a step before its turn.
      // Instead they're resolved into plain arrays below, then each nested
      // step gets interpolated individually at its own execution time,
      // exactly like top-level steps already do.
      const conditionStep = interpolateDeep(
        { ...rawStep, thenSteps: undefined, elseSteps: undefined },
        variables
      );

      const thenSteps = parseBranch(rawStep.thenSteps, 'Then Steps', stepNumber);
      const elseSteps = parseBranch(rawStep.elseSteps, 'Else Steps', stepNumber);

      const condDescription = [
        conditionStep.conditionType,
        conditionStep.conditionLocatorValue || conditionStep.conditionVariableName || '',
      ]
        .filter(Boolean)
        .join(' ');

      await test.step(`[${stepNumber}] if ${condDescription}`, async () => {
        const result = await evaluateCondition(page, conditionStep, variables);
        const branchSteps = result ? thenSteps : elseSteps;
        const branchLabel = `${result ? 'TRUE' : 'FALSE'} — running ${branchSteps.length} step(s)`;
        await test.step(branchLabel, async () => {
          await runStepList({
            ...opts,
            steps: branchSteps,
            pathPrefix: `${stepNumber}.`,
          });
        });
      });
      continue;
    }

    const handler = actionRegistry[rawStep.action];
    if (!handler) {
      throw new Error(`Unsupported action "${rawStep.action}". Add it to runner/actionRegistry.js.`);
    }

    // Resolve {{variables}} in every field of this step right before it runs,
    // so data captured by earlier steps (API responses, page text, localStorage)
    // is available to fill/click/assert/etc. steps that reference it.
    const step = interpolateDeep(rawStep, variables);

    const locatorLabel =
      step.locator && (step.locator.value || step.locator.name)
        ? `${step.locator.type}=${step.locator.value ?? step.locator.name ?? ''}`
        : '';
    const label = [
      step.action,
      locatorLabel,
      step.value ? `-> ${step.value}` : '',
      step.saveAs ? `(save as ${step.saveAs})` : '',
    ]
      .filter(Boolean)
      .join(' ');
    const attachmentName = `step-${stepNumber}-${step.action}`;

    await test.step(`[${stepNumber}] ${label || step.action}`, async () => {
      try {
        await handler(page, step, expect, ctx);
        if (step.saveAs && ctx.variables[step.saveAs] !== undefined) {
          await testInfo.attach(`var-${step.saveAs}`, {
            body: Buffer.from(String(ctx.variables[step.saveAs])),
            contentType: 'text/plain',
          });
        }
        if (stepScreenshotMode === 'on') {
          await captureStepScreenshot(page, testInfo, attachmentName);
        }
      } catch (err) {
        if (stepScreenshotMode === 'on' || stepScreenshotMode === 'only-on-failure') {
          await captureStepScreenshot(page, testInfo, `${attachmentName}-FAILED`);
        }
        throw err;
      }
    });
  }
}

module.exports = { runStepList, evaluateCondition, captureStepScreenshot };
