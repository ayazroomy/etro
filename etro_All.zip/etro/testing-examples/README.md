# ETRO Full Feature Test Suite (testing artifacts)

`etro-full-feature-suite.etro-collection.json` — 20 specs covering every action,
locator type, and condition type. Import via **Import Collection…** in the app.

These specs point at `http://localhost:8934`, a local fixture the specs were built
and verified against — included here as `test-fixture-page.html` /
`test-fixture-server.js` so you can reproduce the exact same run:

```bash
cd testing-examples
node test-fixture-server.js   # serves test-fixture-page.html at http://localhost:8934
```

Then import the collection and run it (Settings → headless is fine; browsers must be
installed via Settings → Install Selected Browsers first).

See the README's "Full feature testing pass" section for what was verified and what
was found along the way.
