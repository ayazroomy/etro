const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const PORT = 8934;

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);

  // ---- Mock JSON API endpoints for apiRequest/extractPath/regex testing ----
  if (url.pathname === '/api/user') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      data: {
        user: { id: 42, name: 'Ayaz Test', email: 'ayaz@example.com' },
        collections: 'id=col-101, id=col-202, id=col-303 active-set',
        token: 'auth-token-abc123XYZ',
      },
    }));
    return;
  }
  if (url.pathname === '/api/login') {
    if (req.method !== 'POST') {
      res.writeHead(405);
      res.end('Method not allowed');
      return;
    }
    let body = '';
    req.on('data', (chunk) => (body += chunk));
    req.on('end', () => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, data: { sessionToken: 'session-9988-live' } }));
    });
    return;
  }
  if (url.pathname === '/api/status') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('build-id: rel-2026.08.11 status=healthy');
    return;
  }

  let pathname = url.pathname;
  if (pathname === '/' || pathname === '') pathname = '/test-fixture-page.html';
  let filePath = path.join(ROOT, pathname);
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(data);
  });
});

server.listen(PORT, () => {
  console.log(`Test fixture server running at http://localhost:${PORT}`);
});
