# Responsive Screenshot Tester (Chrome extension)

Captures the current page at multiple device resolutions and saves a Word (.docx) report
with every screenshot, each preceded by a bold label such as:

> **This screenshot is for Mobile device — iPhone 8 / SE 2 — resolution 375 × 667 px**

## Install
1. Unzip this folder.
2. Open `chrome://extensions` and switch on **Developer mode** (top right).
3. Click **Load unpacked** and pick the `responsive-tester` folder.
4. Pin the extension from the puzzle-piece menu.

## Use
1. Open the page you want to test.
2. Click the extension icon. All resolutions are selected by default; untick any you don't want
   (or use the group checkbox to toggle a whole device type).
3. Click **Test**. A yellow "started debugging this browser" bar appears while it runs — that's
   Chrome's normal notice for screenshot capture. Keep the tab open until it finishes.
4. The report is saved to your Downloads folder (`responsive-report_<site>_<date>.docx`).

## Features
- Default set: 5 mobile, 3 tablet, 3 desktop, 2 large desktop sizes.
- **Add a new resolution**: name, device type, width, height, pixel ratio. Remove any with the × button.
- Your selection and custom resolutions are remembered between sessions.
- **Capture options**: full page vs. visible area, wait time after resize, reload at each size,
  real device pixel ratio, JPEG (small file) or PNG (lossless).
- Mobile/tablet sizes are emulated with a touch screen and mobile user agent.
- Long pages are split across Word pages so they stay readable; failures are noted in the report
  rather than stopping the run.

## Notes
- Chrome internal pages (`chrome://`, the Web Store) can't be captured.
- Close DevTools on the tab before testing (Chrome allows only one debugger per tab).
- Very long pages are captured up to 16,000 px tall.
- If a site only changes layout on load (not on resize), turn on **Reload page at each resolution**.

## Files
- `manifest.json` – Manifest V3 config
- `popup.html / popup.css / popup.js` – UI
- `background.js` – resizes and captures via the Chrome DevTools Protocol
- `docx.js` – self-contained Word file writer (no external libraries)
- `defaults.js` – default resolutions and options
