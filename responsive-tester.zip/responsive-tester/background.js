import { buildDocx, PAGE } from './docx.js';
import { MOBILE_TYPES } from './defaults.js';

const MAX_CAPTURE_HEIGHT = 16000; // CSS px; very long pages are truncated to keep Chrome stable
const MOBILE_UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1';
const TABLET_UA = 'Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1';

let running = false;
let cancelRequested = false;

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === 'start') {
    if (running) { sendResponse({ ok: false, error: 'A test is already running.' }); return; }
    runTest(msg).catch(async (e) => {
      await setProgress({ status: 'error', error: e?.message || String(e) });
    });
    sendResponse({ ok: true });
  } else if (msg?.type === 'cancel') {
    cancelRequested = true;
    sendResponse({ ok: true });
  }
});

const setProgress = (p) => chrome.storage.session.set({ run: { ...p, updatedAt: Date.now() } });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function cdp(tabId, method, params = {}) {
  return chrome.debugger.sendCommand({ tabId }, method, params);
}

function waitForEvent(tabId, eventName, timeoutMs) {
  return new Promise((resolve) => {
    const timer = setTimeout(done, timeoutMs);
    function listener(source, method) {
      if (source.tabId === tabId && method === eventName) done();
    }
    function done() {
      clearTimeout(timer);
      chrome.debugger.onEvent.removeListener(listener);
      resolve();
    }
    chrome.debugger.onEvent.addListener(listener);
  });
}

function base64ToBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function bytesToBase64(bytes) {
  let bin = '';
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(bin);
}

// Narrowest a shrunk screenshot may get before we split it instead (inches on the Word page).
const MIN_FIT_WIDTH_IN = 2.2;

/**
 * Size a screenshot for the Word page.
 * 1. Fits as-is            → one image.
 * 2. A bit too tall        → shrink it so the whole screenshot stays on one page.
 * 3. Far too tall to shrink without becoming unreadable → split into EQUAL parts
 *    (never a full page plus a tiny leftover strip).
 */
async function toDocImages(bytes, mime, cssWidth, ext) {
  const bitmap = await createImageBitmap(new Blob([bytes], { type: mime }));
  const { width: pxW, height: pxH } = bitmap;

  // Natural display width: true-ish size at 96 dpi, capped at the printable width.
  const widthIn = Math.min(PAGE.maxWidthIn, cssWidth / PAGE.cssPxPerInch);
  const heightIn = pxH * widthIn / pxW;

  if (heightIn <= PAGE.maxHeightIn) {
    bitmap.close();
    return [{ bytes, ext, widthIn, heightIn }];
  }

  const fitWidthIn = widthIn * PAGE.maxHeightIn / heightIn;
  if (fitWidthIn >= MIN_FIT_WIDTH_IN) {
    bitmap.close();
    return [{ bytes, ext, widthIn: fitWidthIn, heightIn: PAGE.maxHeightIn }];
  }

  // Split at the natural (readable) width into equal-height parts.
  const partWidthIn = widthIn;
  const inPerPx = partWidthIn / pxW;
  const parts = Math.ceil((pxH * inPerPx) / PAGE.maxHeightIn);
  const sliceH = Math.ceil(pxH / parts);

  const images = [];
  for (let y = 0; y < pxH; y += sliceH) {
    const h = Math.min(sliceH, pxH - y);
    const canvas = new OffscreenCanvas(pxW, h);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(bitmap, 0, y, pxW, h, 0, 0, pxW, h);
    const blob = await canvas.convertToBlob(ext === 'png' ? { type: 'image/png' } : { type: 'image/jpeg', quality: 0.9 });
    images.push({ bytes: new Uint8Array(await blob.arrayBuffer()), ext, widthIn: partWidthIn, heightIn: h * inPerPx });
  }
  bitmap.close();
  return images;
}

async function captureOne(tabId, res, options) {
  const isMobile = MOBILE_TYPES.includes(res.type);
  const dpr = options.emulateDpr ? (Number(res.dpr) || 1) : 1;

  await cdp(tabId, 'Emulation.setDeviceMetricsOverride', {
    width: res.width,
    height: res.height,
    deviceScaleFactor: dpr,
    mobile: isMobile,
    screenWidth: res.width,
    screenHeight: res.height
  });
  await cdp(tabId, 'Emulation.setTouchEmulationEnabled',
    isMobile ? { enabled: true, maxTouchPoints: 5 } : { enabled: false });
  await cdp(tabId, 'Emulation.setUserAgentOverride', {
    userAgent: res.type === 'Mobile' ? MOBILE_UA : res.type === 'Tablet' ? TABLET_UA : navigator.userAgent
  });

  if (options.reload) {
    const loaded = waitForEvent(tabId, 'Page.loadEventFired', 30000);
    await cdp(tabId, 'Page.reload', { ignoreCache: false });
    await loaded;
  }

  await cdp(tabId, 'Runtime.evaluate', { expression: 'window.scrollTo(0,0)' });
  await sleep(Math.max(0, Number(options.delayMs) || 0));

  const format = options.imageFormat === 'png' ? 'png' : 'jpeg';
  const shotParams = { format, fromSurface: true };
  if (format === 'jpeg') shotParams.quality = 90;

  if (options.fullPage) {
    const metrics = await cdp(tabId, 'Page.getLayoutMetrics');
    const size = metrics.cssContentSize || metrics.contentSize;
    const fullH = Math.min(Math.max(Math.ceil(size.height), res.height), MAX_CAPTURE_HEIGHT);
    shotParams.captureBeyondViewport = true;
    shotParams.clip = { x: 0, y: 0, width: res.width, height: fullH, scale: 1 };
  }

  const { data } = await cdp(tabId, 'Page.captureScreenshot', shotParams);
  const bytes = base64ToBytes(data);
  const images = await toDocImages(bytes, format === 'png' ? 'image/png' : 'image/jpeg', res.width, format);
  return { dpr, images };
}

async function runTest({ tabId, resolutions, options }) {
  running = true;
  cancelRequested = false;
  const total = resolutions.length;
  let attached = false;

  try {
    const tab = await chrome.tabs.get(tabId);
    if (!/^(https?|file):/i.test(tab.url || '')) {
      throw new Error('This page can\'t be tested. Open a normal web page (http/https) and try again.');
    }

    await setProgress({ status: 'running', done: 0, total, current: 'Attaching to the page…' });
    try {
      await chrome.debugger.attach({ tabId }, '1.3');
      attached = true;
    } catch (e) {
      throw new Error('Could not attach to the tab. Close DevTools for this tab and try again. (' + (e?.message || e) + ')');
    }
    await cdp(tabId, 'Page.enable');
    await cdp(tabId, 'Emulation.setScrollbarsHidden', { hidden: true }).catch(() => {});

    const results = [];
    for (let i = 0; i < resolutions.length; i++) {
      if (cancelRequested) throw new Error('Test cancelled.');
      const res = resolutions[i];
      await setProgress({
        status: 'running', done: i, total,
        current: `${res.type} — ${res.name} (${res.width} × ${res.height})`
      });
      try {
        const { dpr, images } = await captureOne(tabId, res, options);
        results.push({ ...res, dpr, images });
      } catch (e) {
        results.push({ ...res, dpr: 1, images: [], error: e?.message || String(e) });
      }
    }

    await setProgress({ status: 'running', done: total, total, current: 'Creating Word document…' });

    await cdp(tabId, 'Emulation.clearDeviceMetricsOverride').catch(() => {});
    await chrome.debugger.detach({ tabId }).catch(() => {});
    attached = false;
    if (options.reload) chrome.tabs.reload(tabId).catch(() => {});

    const docBytes = buildDocx({
      url: tab.url,
      pageTitle: tab.title || '',
      generatedAt: new Date().toLocaleString(),
      options,
      results
    });

    const host = (() => { try { return new URL(tab.url).hostname || 'page'; } catch { return 'page'; } })();
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    const filename = `responsive-report_${host.replace(/[^a-z0-9.-]/gi, '_')}_${stamp}.docx`;

    const downloadId = await chrome.downloads.download({
      url: 'data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,' + bytesToBase64(docBytes),
      filename,
      saveAs: false
    });

    const failed = results.filter((r) => r.error).length;
    await setProgress({ status: 'done', done: total, total, filename, downloadId, failed });
  } finally {
    if (attached) {
      await cdp(tabId, 'Emulation.clearDeviceMetricsOverride').catch(() => {});
      await chrome.debugger.detach({ tabId }).catch(() => {});
    }
    running = false;
  }
}
