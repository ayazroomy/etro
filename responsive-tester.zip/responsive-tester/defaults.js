// Device types, in the order they appear in the popup and the report.
export const DEVICE_TYPES = ['Mobile', 'Tablet', 'Desktop', 'Large Desktop'];

// Types that are emulated as touch devices with a mobile viewport / user agent.
export const MOBILE_TYPES = ['Mobile', 'Tablet'];

// Default resolutions (CSS pixels). All are selected by default.
export const DEFAULT_RESOLUTIONS = [
  { name: 'iPhone SE (small)',      type: 'Mobile',        width: 320,  height: 568,  dpr: 2 },
  { name: 'iPhone 8 / SE 2',        type: 'Mobile',        width: 375,  height: 667,  dpr: 2 },
  { name: 'iPhone 14 / 15',         type: 'Mobile',        width: 390,  height: 844,  dpr: 3 },
  { name: 'Android (Pixel/Galaxy)', type: 'Mobile',        width: 412,  height: 915,  dpr: 2.625 },
  { name: 'iPhone Pro Max',         type: 'Mobile',        width: 430,  height: 932,  dpr: 3 },
  { name: 'iPad Mini / iPad',       type: 'Tablet',        width: 768,  height: 1024, dpr: 2 },
  { name: 'iPad Air',               type: 'Tablet',        width: 820,  height: 1180, dpr: 2 },
  { name: 'iPad Pro 12.9"',         type: 'Tablet',        width: 1024, height: 1366, dpr: 2 },
  { name: 'Laptop',                 type: 'Desktop',       width: 1280, height: 800,  dpr: 1 },
  { name: 'HD Laptop',              type: 'Desktop',       width: 1366, height: 768,  dpr: 1 },
  { name: 'MacBook Air',            type: 'Desktop',       width: 1440, height: 900,  dpr: 1 },
  { name: 'Full HD',                type: 'Large Desktop', width: 1920, height: 1080, dpr: 1 },
  { name: 'QHD / 2K',               type: 'Large Desktop', width: 2560, height: 1440, dpr: 1 }
].map((r, i) => ({ id: 'default-' + i, selected: true, ...r }));

export const DEFAULT_OPTIONS = {
  fullPage: true,        // capture the whole scrollable page, not just the viewport
  delayMs: 1200,         // wait after resizing so layout/lazy content can settle
  reload: false,         // reload the page at each size (for sites that only adapt on load)
  imageFormat: 'jpeg',   // 'jpeg' keeps the Word file small, 'png' is lossless
  emulateDpr: false      // use each device's pixel ratio (sharper, much larger file)
};
