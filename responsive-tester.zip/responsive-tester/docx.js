// Minimal, dependency-free .docx (Office Open XML) writer.
// Builds a Word document containing a title block, a summary list and,
// for each tested resolution, a bold label followed by its screenshot(s).

const EMU_PER_INCH = 914400;
const enc = new TextEncoder();

// ---------- ZIP (store, no compression) ----------
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(bytes) {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function zip(files) {
  const chunks = [];
  const central = [];
  let offset = 0;
  const dosTime = 0, dosDate = (2020 - 1980) << 9 | 1 << 5 | 1;

  for (const f of files) {
    const name = enc.encode(f.name);
    const data = f.data;
    const crc = crc32(data);

    const local = new DataView(new ArrayBuffer(30));
    local.setUint32(0, 0x04034b50, true);
    local.setUint16(4, 20, true);
    local.setUint16(6, 0x0800, true);          // UTF-8 names
    local.setUint16(8, 0, true);               // stored
    local.setUint16(10, dosTime, true);
    local.setUint16(12, dosDate, true);
    local.setUint32(14, crc, true);
    local.setUint32(18, data.length, true);
    local.setUint32(22, data.length, true);
    local.setUint16(26, name.length, true);
    local.setUint16(28, 0, true);
    chunks.push(new Uint8Array(local.buffer), name, data);

    const cen = new DataView(new ArrayBuffer(46));
    cen.setUint32(0, 0x02014b50, true);
    cen.setUint16(4, 20, true);
    cen.setUint16(6, 20, true);
    cen.setUint16(8, 0x0800, true);
    cen.setUint16(10, 0, true);
    cen.setUint16(12, dosTime, true);
    cen.setUint16(14, dosDate, true);
    cen.setUint32(16, crc, true);
    cen.setUint32(20, data.length, true);
    cen.setUint32(24, data.length, true);
    cen.setUint16(28, name.length, true);
    cen.setUint32(42, offset, true);
    central.push(new Uint8Array(cen.buffer), name);

    offset += 30 + name.length + data.length;
  }

  const cenSize = central.reduce((s, c) => s + c.length, 0);
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true);
  end.setUint16(8, files.length, true);
  end.setUint16(10, files.length, true);
  end.setUint32(12, cenSize, true);
  end.setUint32(16, offset, true);

  const all = [...chunks, ...central, new Uint8Array(end.buffer)];
  const out = new Uint8Array(all.reduce((s, c) => s + c.length, 0));
  let p = 0;
  for (const c of all) { out.set(c, p); p += c.length; }
  return out;
}

// ---------- XML helpers ----------
const esc = (s) => String(s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
  // strip characters that are illegal in XML 1.0
  .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');

function run(text, { bold = false, size, color, italic = false } = {}) {
  const rPr = [
    bold ? '<w:b/><w:bCs/>' : '',
    italic ? '<w:i/>' : '',
    color ? `<w:color w:val="${color}"/>` : '',
    size ? `<w:sz w:val="${size * 2}"/><w:szCs w:val="${size * 2}"/>` : ''
  ].join('');
  return `<w:r>${rPr ? `<w:rPr>${rPr}</w:rPr>` : ''}<w:t xml:space="preserve">${esc(text)}</w:t></w:r>`;
}

function para(runs, { align, pageBreakBefore = false, after = 120, before = 0, keepNext = false, singleLine = false } = {}) {
  const pPr = [
    keepNext ? '<w:keepNext/>' : '',
    pageBreakBefore ? '<w:pageBreakBefore/>' : '',
    `<w:spacing w:before="${before}" w:after="${after}"${singleLine ? ' w:line="240" w:lineRule="auto"' : ''}/>`,
    align ? `<w:jc w:val="${align}"/>` : ''
  ].join('');
  return `<w:p><w:pPr>${pPr}</w:pPr>${Array.isArray(runs) ? runs.join('') : runs}</w:p>`;
}

function picture(relId, docPrId, cx, cy, name) {
  return `<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">` +
    `<wp:extent cx="${cx}" cy="${cy}"/><wp:effectExtent l="0" t="0" r="0" b="0"/>` +
    `<wp:docPr id="${docPrId}" name="${esc(name)}"/>` +
    `<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr>` +
    `<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">` +
    `<pic:pic><pic:nvPicPr><pic:cNvPr id="${docPrId}" name="${esc(name)}"/><pic:cNvPicPr/></pic:nvPicPr>` +
    `<pic:blipFill><a:blip r:embed="${relId}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>` +
    `<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm>` +
    `<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>` +
    `<a:ln w="6350"><a:solidFill><a:srgbClr val="BFBFBF"/></a:solidFill></a:ln></pic:spPr>` +
    `</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>`;
}

// ---------- Public API ----------
/**
 * @param {object} report
 * @param {string} report.url
 * @param {string} report.pageTitle
 * @param {string} report.generatedAt  human-readable date
 * @param {object} report.options      { fullPage, imageFormat }
 * @param {Array}  report.results      [{ name, type, width, height, dpr, error?,
 *                                        images: [{ bytes: Uint8Array, ext: 'png'|'jpeg', widthIn, heightIn }] }]
 * @returns {Uint8Array} .docx file bytes
 */
export function buildDocx(report) {
  const media = [];
  const rels = [];
  let docPrId = 1;
  const body = [];

  // Title block
  body.push(para(run('Responsive Screenshot Report', { bold: true, size: 22, color: '1F3864' }), { after: 200 }));
  body.push(para([run('Page URL: ', { bold: true }), run(report.url)]));
  if (report.pageTitle) body.push(para([run('Page title: ', { bold: true }), run(report.pageTitle)]));
  body.push(para([run('Generated: ', { bold: true }), run(report.generatedAt)]));
  body.push(para([run('Capture mode: ', { bold: true }),
    run(report.options?.fullPage ? 'Full page' : 'Visible viewport only')]));
  body.push(para([run('Resolutions tested: ', { bold: true }), run(String(report.results.length))], { after: 240 }));

  body.push(para(run('Summary', { bold: true, size: 14, color: '1F3864' }), { before: 120, after: 120, keepNext: true }));
  report.results.forEach((r, i) => {
    body.push(para([
      run(`${i + 1}.  `),
      run(`${r.type}`, { bold: true }),
      run(` — ${r.name} — ${r.width} × ${r.height} px`),
      r.error ? run('  (failed)', { color: 'C00000' }) : ''
    ], { after: 60 }));
  });

  // One section per resolution, each starting on a new page
  report.results.forEach((r, i) => {
    body.push(para(
      run(`This screenshot is for ${r.type} device — ${r.name} — resolution ${r.width} × ${r.height} px`,
        { bold: true, size: 14 }),
      { pageBreakBefore: true, after: 80, keepNext: true }
    ));
    const parts = r.images?.length || 0;
    const meta = [`Device type: ${r.type}`, `Viewport: ${r.width} × ${r.height} px`, `Pixel ratio: ${r.dpr}`];
    if (parts > 1) meta.push(`Long page split into ${parts} parts`);
    body.push(para(run(meta.join('   ·   '), { size: 9, color: '595959' }), { after: 160, keepNext: true }));

    if (r.error) {
      body.push(para(run(`Capture failed: ${r.error}`, { color: 'C00000' })));
      return;
    }

    r.images.forEach((img, j) => {
      const n = media.length + 1;
      const ext = img.ext === 'png' ? 'png' : 'jpeg';
      const file = `image${n}.${ext}`;
      const relId = `rIdImg${n}`;
      media.push({ name: `word/media/${file}`, data: img.bytes });
      rels.push(`<Relationship Id="${relId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${file}"/>`);
      const cx = Math.round(img.widthIn * EMU_PER_INCH);
      const cy = Math.round(img.heightIn * EMU_PER_INCH);
      body.push(para(picture(relId, docPrId++, cx, cy, `${r.type} ${r.width}x${r.height} part ${j + 1}`),
        { align: 'center', after: 0, singleLine: true }));
    });
  });

  const documentXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" ` +
    `xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" ` +
    `xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" ` +
    `xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" ` +
    `xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">` +
    `<w:body>${body.join('')}` +
    `<w:sectPr><w:pgSz w:w="12240" w:h="15840"/>` +
    `<w:pgMar w:top="1080" w:right="1080" w:bottom="1080" w:left="1080" w:header="540" w:footer="540" w:gutter="0"/>` +
    `</w:sectPr></w:body></w:document>`;

  const stylesXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">` +
    `<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Calibri" w:cs="Calibri"/>` +
    `<w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="en-US"/></w:rPr></w:rPrDefault>` +
    `<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="259" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>` +
    `<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>` +
    `</w:styles>`;

  const contentTypes =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
    `<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>` +
    `<Default Extension="xml" ContentType="application/xml"/>` +
    `<Default Extension="png" ContentType="image/png"/>` +
    `<Default Extension="jpeg" ContentType="image/jpeg"/>` +
    `<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>` +
    `<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>` +
    `<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>` +
    `</Types>`;

  const rootRels =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>` +
    `<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>` +
    `</Relationships>`;

  const docRels =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    `<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>` +
    rels.join('') + `</Relationships>`;

  const now = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
  const coreXml =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" ` +
    `xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" ` +
    `xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">` +
    `<dc:title>${esc('Responsive Screenshot Report - ' + (report.pageTitle || report.url))}</dc:title>` +
    `<dc:creator>Responsive Screenshot Tester</dc:creator>` +
    `<dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created>` +
    `<dcterms:modified xsi:type="dcterms:W3CDTF">${now}</dcterms:modified>` +
    `</cp:coreProperties>`;

  return zip([
    { name: '[Content_Types].xml', data: enc.encode(contentTypes) },
    { name: '_rels/.rels', data: enc.encode(rootRels) },
    { name: 'docProps/core.xml', data: enc.encode(coreXml) },
    { name: 'word/document.xml', data: enc.encode(documentXml) },
    { name: 'word/styles.xml', data: enc.encode(stylesXml) },
    { name: 'word/_rels/document.xml.rels', data: enc.encode(docRels) },
    ...media
  ]);
}

// Page geometry used by the capture code to size/slice images (Letter, 0.75" margins).
export const PAGE = {
  maxWidthIn: 7.0,     // printable width
  maxHeightIn: 8.4,    // printable height minus room for the label
  cssPxPerInch: 96
};
