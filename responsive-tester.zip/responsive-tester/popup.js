import { DEFAULT_RESOLUTIONS, DEFAULT_OPTIONS, DEVICE_TYPES } from './defaults.js';

const $ = (id) => document.getElementById(id);
let resolutions = [];
let options = { ...DEFAULT_OPTIONS };
let activeTab = null;

// ---------- storage ----------
async function load() {
  const data = await chrome.storage.local.get(['resolutions', 'options']);
  resolutions = Array.isArray(data.resolutions) ? data.resolutions : structuredClone(DEFAULT_RESOLUTIONS);
  options = { ...DEFAULT_OPTIONS, ...(data.options || {}) };
}
const saveResolutions = () => chrome.storage.local.set({ resolutions });
const saveOptions = () => chrome.storage.local.set({ options });

// ---------- rendering ----------
function render() {
  const list = $('list');
  list.textContent = '';
  const types = [...DEVICE_TYPES, ...new Set(resolutions.map((r) => r.type).filter((t) => !DEVICE_TYPES.includes(t)))];

  for (const type of types) {
    const items = resolutions.filter((r) => r.type === type);
    if (!items.length) continue;

    const group = document.createElement('div');
    group.className = 'group';

    const head = document.createElement('label');
    head.className = 'group-head';
    const groupBox = document.createElement('input');
    groupBox.type = 'checkbox';
    const selectedCount = items.filter((r) => r.selected).length;
    groupBox.checked = selectedCount === items.length;
    groupBox.indeterminate = selectedCount > 0 && selectedCount < items.length;
    groupBox.addEventListener('change', () => {
      items.forEach((r) => (r.selected = groupBox.checked));
      saveResolutions(); render();
    });
    head.append(groupBox, document.createTextNode(`${type} (${items.length})`));
    group.append(head);

    for (const r of items) {
      const row = document.createElement('div');
      row.className = 'item';

      const label = document.createElement('label');
      const box = document.createElement('input');
      box.type = 'checkbox';
      box.checked = !!r.selected;
      box.addEventListener('change', () => { r.selected = box.checked; saveResolutions(); render(); });
      const name = document.createElement('span');
      name.className = 'name';
      name.textContent = r.name;
      const dims = document.createElement('span');
      dims.className = 'dims';
      dims.textContent = `${r.width} × ${r.height}`;
      label.append(box, name, dims);

      const remove = document.createElement('button');
      remove.className = 'remove';
      remove.title = `Remove ${r.name}`;
      remove.textContent = '×';
      remove.addEventListener('click', () => {
        resolutions = resolutions.filter((x) => x.id !== r.id);
        saveResolutions(); render();
      });

      row.append(label, remove);
      group.append(row);
    }
    list.append(group);
  }

  if (!resolutions.length) {
    list.innerHTML = '<p style="padding:8px;color:var(--muted)">No resolutions. Add one below or restore the defaults.</p>';
  }

  const n = resolutions.filter((r) => r.selected).length;
  $('count').textContent = `${n} of ${resolutions.length} selected`;
  updateButtons();
}

function renderOptions() {
  $('optFullPage').checked = options.fullPage;
  $('optReload').checked = options.reload;
  $('optDpr').checked = options.emulateDpr;
  $('optDelay').value = options.delayMs;
  $('optFormat').value = options.imageFormat;
}

let isRunning = false;
function updateButtons() {
  const n = resolutions.filter((r) => r.selected).length;
  const testable = activeTab && /^(https?|file):/i.test(activeTab.url || '');
  $('testBtn').disabled = isRunning || n === 0 || !testable;
  $('testBtn').textContent = isRunning ? 'Testing…' : n ? `Test ${n} resolution${n > 1 ? 's' : ''}` : 'Test';
  $('cancelBtn').hidden = !isRunning;
}

function renderProgress(run) {
  const box = $('progress');
  const text = $('progressText');
  if (!run) { box.hidden = true; isRunning = false; updateButtons(); return; }
  // Treat a stale "running" state (e.g. the browser was restarted mid-test) as finished.
  const stale = run.status === 'running' && Date.now() - (run.updatedAt || 0) > 120000;
  isRunning = run.status === 'running' && !stale;
  box.hidden = false;
  text.className = 'status';
  const pct = run.total ? Math.round((run.done / run.total) * 100) : 0;
  $('progressFill').style.width = (run.status === 'done' ? 100 : pct) + '%';

  if (isRunning) {
    text.textContent = `${run.done} / ${run.total} — ${run.current || ''}`;
  } else if (run.status === 'done') {
    text.className = 'status ok';
    text.textContent = `Report saved to Downloads: ${run.filename}` +
      (run.failed ? ` (${run.failed} resolution${run.failed > 1 ? 's' : ''} failed — see document)` : '');
    if (run.downloadId != null) {
      const open = document.createElement('button');
      open.className = 'link';
      open.style.marginLeft = '6px';
      open.textContent = 'Show file';
      open.addEventListener('click', () => chrome.downloads.show(run.downloadId));
      text.append(open);
    }
  } else if (run.status === 'error') {
    text.className = 'status err';
    text.textContent = run.error;
  } else {
    box.hidden = true;
  }
  updateButtons();
}

// ---------- events ----------
$('selectAll').addEventListener('click', () => { resolutions.forEach((r) => (r.selected = true)); saveResolutions(); render(); });
$('selectNone').addEventListener('click', () => { resolutions.forEach((r) => (r.selected = false)); saveResolutions(); render(); });

$('resetDefaults').addEventListener('click', () => {
  if (!confirm('Restore the default resolutions? Custom resolutions you added will be removed.')) return;
  resolutions = structuredClone(DEFAULT_RESOLUTIONS);
  saveResolutions(); render();
});

$('addForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const name = $('addName').value.trim();
  const type = $('addType').value;
  const width = parseInt($('addWidth').value, 10);
  const height = parseInt($('addHeight').value, 10);
  const dpr = parseFloat($('addDpr').value) || 1;
  const err = $('addError');

  if (!name) return (err.textContent = 'Enter a name.');
  if (!(width >= 200 && width <= 7680)) return (err.textContent = 'Width must be 200–7680 px.');
  if (!(height >= 200 && height <= 4320)) return (err.textContent = 'Height must be 200–4320 px.');
  if (resolutions.some((r) => r.width === width && r.height === height && r.type === type)) {
    return (err.textContent = `${type} ${width} × ${height} already exists.`);
  }
  err.textContent = '';
  resolutions.push({ id: 'custom-' + Date.now(), name, type, width, height, dpr, selected: true });
  saveResolutions(); render();
  e.target.reset();
  $('addDpr').value = 1;
  $('addType').value = type;
});

$('optFullPage').addEventListener('change', (e) => { options.fullPage = e.target.checked; saveOptions(); });
$('optReload').addEventListener('change', (e) => { options.reload = e.target.checked; saveOptions(); });
$('optDpr').addEventListener('change', (e) => { options.emulateDpr = e.target.checked; saveOptions(); });
$('optDelay').addEventListener('change', (e) => {
  options.delayMs = Math.min(15000, Math.max(0, parseInt(e.target.value, 10) || 0));
  e.target.value = options.delayMs; saveOptions();
});
$('optFormat').addEventListener('change', (e) => { options.imageFormat = e.target.value; saveOptions(); });

$('testBtn').addEventListener('click', async () => {
  const selected = resolutions.filter((r) => r.selected);
  if (!selected.length || !activeTab) return;
  isRunning = true;
  renderProgress({ status: 'running', done: 0, total: selected.length, current: 'Starting…', updatedAt: Date.now() });
  const resp = await chrome.runtime.sendMessage({ type: 'start', tabId: activeTab.id, resolutions: selected, options });
  if (!resp?.ok) renderProgress({ status: 'error', error: resp?.error || 'Could not start the test.' });
});

$('cancelBtn').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'cancel' }));

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'session' && changes.run) renderProgress(changes.run.newValue);
});

// ---------- init ----------
(async () => {
  await load();
  [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const pageEl = $('pageUrl');
  if (activeTab && /^(https?|file):/i.test(activeTab.url || '')) {
    pageEl.textContent = activeTab.url;
    pageEl.title = activeTab.title || activeTab.url;
  } else {
    pageEl.textContent = 'This page can\'t be tested — open a normal website first.';
  }
  render();
  renderOptions();
  const { run } = await chrome.storage.session.get('run');
  renderProgress(run);
})();
